##########################################################################################################
# Name Of File: QueueProcessor.py									 #
# Author: Vinayak Wagh                                                                                   #
# Purpose Of File: Find Matching Test Beds & Devices for Test Record in Queue				 #
##########################################################################################################
# History:                                                                                               #
# Date                   Author                  Changes                                                 #
# 19/03/2016             Vinayak Wagh            Initial Creation                                        #
##############################################################################f############################
import DeviceFarmInfo
import sys,json,os
from lockfile import LockFile

with open(os.environ['PYTHONPATH'].split(":")[0]+'/config.json')as json_data:
		Config = json.load(json_data)
sys.path.insert(0, (Config['CONFIG_PATH']+"/code/db"))

import DB_Interface
import unicodedata
sys.path.insert(0, (Config['CONFIG_PATH']+"/code/jenkins_job"))

import StartJob, JobPreSetup, time
import LogDictUtility
logger=LogDictUtility.LogGenerate()
import CLMEmailNotification
import datetime
import urllib
import urllib2
from datetime import datetime
import StartSystemJob

#########################################################################################################
# SYNOPSIS:												#
# 1. Get Test Data from Queue, to find Matching Test Bed & Devices					#
# 2. If Match not found then, let the Test Data in Queue						#
#########################################################################################################
class Process():
        global logger
	#########################################################################################################
	# SYNOPSIS:												#
    	# Empty Constructor											#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:	
	# NA											#
    	# Init Function													#
    	#########################################################################################################
	def __init__(self):
                self.nodeNames=[]
		self.testQueue=None
		self.deviceFarm=None
		self.testRun = None
		self.lock=LockFile(Config['CONFIG_PATH']+"/lockfiles/lock.txt")
		self.email = CLMEmailNotification.EmailNotification()
		self.subject = Config['E-mail_Subject']


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# 1. Insert Test Record into Running Test Record's Table along with JobName				#
    	# 2. Put flash_status & test_status for corresponding JobName						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dictRecord	Dictionary	Test Record to put into Running Test Jobs Table				#
    	# jobName	String		Test Record's corresponding Job Name					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def insertIntoRunningJob(self, dictRecord, jobName):
		
		try:
			record={}
			record=dictRecord

			record['job_name']=jobName
			logger.log(1,"[QueueProcessor_insertIntoRunningJob] job_name:"+str(jobName),"I")
			if record.get('build_xml_location')!='NA' and record.get('device_required').lower()=='true':
				record['flash_status']="IN_PROGRESS"
				record['test_status']="NOT_STARTED"
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				logger.log(1,"[QueueProcessor_starting_timestamp] job_name:starting_timestamp"+str(starting_timestamp),"D")
				record['starting_timestamp']=str(starting_timestamp)
				logger.log(1,"[QueueProcessor_starting_timestamp] job_name:in record"+str(starting_timestamp),"I")

			elif record.get('build_xml_location')!='NA' and record.get('device_required').lower()=='false':
				record['flash_status']="NO_FLASH"
				record['test_status']="IN_PROGRESS"
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				logger.log(1,"[QueueProcessor_starting_timestamp] job_name:starting_timestamp"+str(starting_timestamp),"D")
				record['starting_timestamp']=str(starting_timestamp)
				logger.log(1,"[QueueProcessor_starting_timestamp] job_name:in record"+str(starting_timestamp),"I")
			elif record.get('build_xml_location')=='NA':
				record['flash_status']="NO_FLASH"
				record['test_status']="IN_PROGRESS"
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				logger.log(1,"[QueueProcessor_starting_timestamp] :test_status:job_name:starting_timestamp"+str(starting_timestamp),"D")
				record['starting_timestamp']=str(starting_timestamp)
				logger.log(1,"[QueueProcessor_starting_timestamp] :test_status:job_name:starting_timestamp:in record"+str(starting_timestamp),"I")
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			self.testRun.insert(record)
			#time.sleep(3)###Analyse impact
			self.testRun.close()
			logger.log(1,"[QueueProcessor_insertIntoRunningJob]insert record","I")
			return True
		except Exception, e:
			
			logger.log(1,"[QueueProcessor_insertIntoRunningJob]EXCEPTION"+str(e),"E")
			return False

		#finally:
			#self.testRun.close()

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match Device Serial ID with Device ID required for Test Job						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceSerial	String		Device Serial number								#
    	# recordList	List		List of serial numbers to be compared to					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def matchDeviceSerialId(self, deviceSerial, recordList):
		try:
			
			for serial in recordList:
				if deviceSerial.strip(" ,")==serial.strip(" ,"):
					logger.log(1,"Match found","D")
					return True
			return False
		except Exception, e:
			
			logger.log(1,"matchDeviceSerialId:exception"+str(e),"E")
			return False

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Convert Test Record format from Tuple to Dictionary							#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	Tuple		Test Record Tuple	
	# osName	string		OS Details						#
    	#########################################################################################################
	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	Dictionary	Test Record Dictionary							#
	# None		Object		Negative Return								#
    	#########################################################################################################
	def convertToDictionary(self, tupleData, osName):
		try:
			if osName==None:
				osData=tupleData[4]
			else:
				osData=osName
			record={
				'build_mode':tupleData[0],
				'build_kind':tupleData[1],
				'build_number':tupleData[2],
				'product':tupleData[3],
				'os':osData,
				'component':tupleData[5],
				'tag':tupleData[6],
				'test_plan':tupleData[7],
				'selected_tc_ids':tupleData[8],
				'selected_tc_titles':tupleData[9],
				'script_file':tupleData[10],
				'sw_cap':tupleData[11],
				'hw_cap':tupleData[12],
				'est_runtime':tupleData[13],
				'support_device_count':tupleData[14],
				'mode':tupleData[15],
				'location':tupleData[16],
				'test_bed_name':tupleData[17],
				'devices':tupleData[18],
				'build_xml_location':tupleData[19],
				'user':tupleData[20],
				'creation_timestamp':tupleData[21],
				'starting_timestamp':tupleData[22],
				'flash':tupleData[23],
				'email_status':tupleData[24],
				'email_reason':tupleData[25],
				'build_variant':tupleData[26],
				'scrum_name':tupleData[27],
				'priority':tupleData[28],
				'pilot_tested':tupleData[29],
				'device_required':tupleData[30],
				'wantechnology':tupleData[31],
				'hardwarerev':tupleData[32],
				'scan_engine':tupleData[33],
				'uniquejob_name':tupleData[34]
				 }

			return record
		except Exception, e:
			
			logger.log(1,"convertToDictionary:EXCEPTION:"+str(e),"E")
			return None

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Convert devicefarm db data from tuple to dictionary format					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	Tuple		Tuple of devicefarm data					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	dictionary	Dictionary output for tuple input							#
    	#########################################################################################################

	def devfarmconvertToDictionary(self, tupleData):
		try:

			record={
				'nodename':tupleData[0],
				'nodeip':tupleData[1],
				'nodeos':tupleData[2],
				'nodestatus':tupleData[3],
				'requestedby':tupleData[4],
				'requestcomments':tupleData[5],
				'softwares':tupleData[6],
				'friendlyname':tupleData[7],
				'location':tupleData[8],
				'parallelexec':tupleData[9],
				'macaddress':tupleData[10],
				'nodeonlinestatus':tupleData[11],
				'locked':tupleData[12],
				'nodejenkinsonlinestatus':tupleData[13],
				'hardwares':tupleData[14],
				'manualgit':tupleData[15],
				'scheduledgit':tupleData[16],
				'Branchname':tupleData[17],
				'manualgitstarttime':tupleData[18],
				'jobname':tupleData[19],
				'scrumteam':tupleData[20],
				'systemlock':tupleData[21]
				 	 }

			return record
		except Exception, e:
			
			logger.log(1,"devfarmconvertToDictionary:EXCEPTION:"+str(e),"E")
			return None


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match HW Capabilties of Device with Test Jobs HW Capabilities						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsHw		List		Test Record's HW Capabilities		 				#
    	# nodehwCap	List		Test Bed's HW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################

	def findHWCap(self, tsHw, nodehwCap):
		try:
			hwCapCount=len(tsHw)
			counter=0
			logger.log(1,"tshw cap"+str(tsHw),"I")
			
			logger.log(1,"[QueueProcessor_findHWCap] External HW Dependencies Matching","I")
			if tsHw[0] =='NA': ####Check what happens when hw cap is empty
				logger.log(1,"Test job requires no external hardware","D")
				return 0
			if len(tsHw)!= 0:
				logger.log(1,"Test job requires atleast 1 external hardware","D")
				for i in tsHw:
					
					if len(nodehwCap)!= 0:
						logger.log(1,"Node has atleast 1 external hardware capacity","D")
						for j in nodehwCap:
							logger.log(1,"i"+str(i.strip(' ')),"I")
							
							logger.log(1,"j"+str(j.encode('ascii', 'ignore')),"I")
							if i.strip(' ')==j.encode('ascii', 'ignore'):
								counter=counter+1
								
								break
					else:
						logger.log(1,"Node does not support atleast 1 external hardware capacity, but job requires it","D")
						return 2

				if counter==hwCapCount:
					
					logger.log(1,"[QueueProcessor_findHWCap] All HW Capabilities Matched","D")
					return 0


				elif counter< hwCapCount and counter!=0 :
					logger.log(1,"[QueueProcessor_findHWCap] Few HW Capabilities Matched","D")
					return 1


				elif counter==0:
					logger.log(1,"[QueueProcessor_findHWCap] No matching  HW Capabilities found","D")
					return 2

			else:
				logger.log(1,"Test job requires no external hardware","D")
				return 0
		except Exception, e:
			
			logger.log(1,"findHWCap:exception:"+str(e),"E")
			return 2

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match SW Capabilties of Test Bed with Test Jobs SW Capabilities					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsSW		List		Test Record's SW Capabilities		 				#
    	# nodeSW	List		Test Bed's SW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################
	def findSWCap(self, tsSW, nodeSW):
		try:
			count=len(tsSW)
			finalCount=0
			for i in tsSW:
				
				for j in nodeSW:
					
					if i.strip(' ')==j.encode('ascii', 'ignore'):
						finalCount=finalCount+1
						
						break
			if finalCount==count and finalCount!=0:
				return 0
			elif finalCount<count and finalCount!=0:
				return 1
			elif finalCount==0:
				return 2
		except Exception, e:
			logger.log(1,"[QueueProcessor_:findSWCap:]EXCEPTION:"+str(e),"E")
	#########################################################################################################
	# SYNOPSIS:												#
    	# Lock device with Device serial number						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialnoString		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################


	def lockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"QueueProcessor_Lock Function Server Side","I")
			logger.log(1,"[QueueProcessor_LockDevices Server Side] Locking Device: "+str(deviceserialno),"I")
			lockResult=self.deviceFarm.reserve_device(operation='reserve_device', serialno=str(deviceserialno))

			logger.log(1,lockResult,"I")
			if lockResult.get('reservationStatus')=='success' and lockResult.get('result')=='ok':
				
				logger.log(1,"[QueueProcessor_LockDevices Server Side] Successfully Locked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			

			logger.log(1,"[QueueProcessor_LockDevices Server Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False
#############################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check the queue records for job with highest priority with all matching capabilities					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# Queuerecord	Tuple		Tuple of jobs in queue
	# node 		Dictionary	Node details
	# secdevicelist	List		List of secondary devices available								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data				Type			Note									#
	# selectedrecord		Dictionary		Job record with highest priority 								#
								#
    	#########################################################################################################
	def checknewrecord(self, Queuerecord, node,secdevicelist):

		logger.log(1,"Started checkNewrecord","I")
		logger.log(1,"Queue record"+str(Queuerecord),"I")
		logger.log(1,"Node"+str(node.get('friendlyname')),"I")
		logger.log(1,"Sec devices"+str(secdevicelist),"I")
		if str(secdevicelist) == "None":
			logger.log(1,"No sec devices available","D")
			noOfSec = 0
		else:
			noOfSec = len(secdevicelist)
		creationtime= ""
		script = ""
		selectedrecord = None
		foundlowest = False
		nodeFound = False
		x=0
		y=0
		z=0
		role_id = 0
		for record in Queuerecord:
			logger.log(1,"Record="+str(record[6]),"I")
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(record[14])
			logger.log(1,"User name="+str(user_name),"I")
			if record[6]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			
			if record[13]== "NA":
				if int(role_id) != 1:
					if node.get('scrumteam')== "ALL":
						nodeFound = True
				else:
					nodeFound = True
			else:
				if node.get('scrumteam')== "ALL" or record[13] == node.get('scrumteam') or record[13]== "NA":
					nodeFound= True
			if nodeFound == True:	
				if (record[9] == "NA" or record[9]== node.get('location')) and (record[10] =="NA" or record[10]== node.get('friendlyname')):
					x = self.findSWCap(record[2].split(","),node.get('softwares').split(","))
					logger.log(1,"X="+str(x),"I")
					y = self.findHWCap(record[3].split(","),node.get('hardwares').split(","))
					logger.log(1,"Y="+str(y),"I")
					logger.log(1,"Value of record","I")
					if (noOfSec >= (record[4]-1)):
						z=1
						logger.log(1,"Z="+str(z),"I")

					else:
						z=0
					if (x==0 and y==0 and z== 1):
						#foundlowest = True

						if record[6]=="Manual":
							if record[8]!="NA":
								buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record[7]+"'"
								pilottested= buildInfo.execute(Query, "SELECT")
								buildInfo.close()
								if pilottested[0]=="YES":
									foundlowest = True
									creationtime = record[1]
									script = record[0]
									selectedrecord = record
									logger.log(1,"Found record:"+str(selectedrecord),"I")
									break

								else:

									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_number="'+record[7]+'"AND flash_status="IN_PROGRESS"';
									checkrecord=self.testRun.execute(query1,"SELECT");
									self.testRun.close()
									if record[9]=='NA' and record[10]=='NA' and record[11]!='NA':
										if checkrecord[0]<1:
											foundlowest = True
											creationtime = record[1]
											script = record[0]
											selectedrecord = record
											logger.log(1,"Found record:"+str(selectedrecord),"I")
											break

										elif checkrecord[0]!=0:

											if record[12]=="YES":
												foundlowest = True
												creationtime = record[1]
												script = record[0]
												selectedrecord = record
												logger.log(1,"Found record:"+str(selectedrecord),"I")
												break

			

											else:
												logger.log(1,"[checknewrecord] Record is not pilot tested So let the testrecord in queue only","D")
												foundlowest =False

									else:
										if checkrecord[0]==0:
											foundlowest = True
											creationtime = record[1]
											script = record[0]
											selectedrecord = record
											logger.log(1,"Found record:"+str(selectedrecord),"I")
											break
										elif checkrecord[0]!=0:
									
											if record[12]=="YES":
												foundlowest = True
												creationtime = record[1]
												script = record[0]
												selectedrecord = record
												logger.log(1,"Found record:"+str(selectedrecord),"I")
												break

		

											else:
												logger.log(1,"[checknewrecord] Record is not pilot tested So let the testrecord in queue only","D")
												foundlowest =False
										



							else:
								foundlowest = True
								creationtime = record[1]
								script = record[0]
								selectedrecord = record
								logger.log(1,"Found record:"+str(selectedrecord),"I")
								break



						else:
							self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_xml_location="'+record[8]+'"';
							checkrecord=self.testRun.execute(query1,"SELECT");
							logger.log(1,"[checknewrecord]  checkrecord "+str(checkrecord),"I")
							self.testRun.close()
							if record[9]=='NA' and record[10]=='NA' and record[11]!='NA':
								if checkrecord[0]<=1:
									foundlowest = True
									creationtime = record[1]
									script = record[0]
									selectedrecord = record
									logger.log(1,"Found record:"+str(selectedrecord),"I")
									break

								elif checkrecord[0]>1:
									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									query2='SELECT flash_status FROM TBL_RUNNING_TEST where build_xml_location="'+record[8]+'" ORDER BY id DESC';
									flashstatus=self.testRun.execute(query2,"SELECT");
									self.testRun.close()
									l=len(flashstatus)
									if record[12]=="YES":
										foundlowest = True
										creationtime = record[1]
										script = record[0]
										selectedrecord = record
										logger.log(1,"Found record:"+str(selectedrecord),"I")
										break
									elif flashstatus[l-1]== "FAIL-TIMEOUT"  or flashstatus[l-1]=="STOPPED-NetworkFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure_OR_NetworkFailure"  or flashstatus[l-1]=="STOPPED-CLM_JOB_TIMED_OUT":
										foundlowest = True
										creationtime = record[1]
										script = record[0]
										selectedrecord = record
										logger.log(1,"Found record:"+str(selectedrecord),"I")
										#time.sleep(5)
										break
									else:
										foundlowest = False

							else:
								if checkrecord[0]==0:
									foundlowest = True
									creationtime = record[1]
									script = record[0]
									selectedrecord = record
									logger.log(1,"Found record:"+str(selectedrecord),"I")
									break



								elif checkrecord[0]!=0:
									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									query2='SELECT flash_status FROM TBL_RUNNING_TEST where build_xml_location="'+record[8]+'" ORDER BY id DESC';
									flashstatus=self.testRun.execute(query2,"SELECT");
									self.testRun.close()
									l=len(flashstatus)

									if record[12]=="YES":
										foundlowest = True
										creationtime = record[1]
										script = record[0]
										selectedrecord = record
										logger.log(1,"Found record:"+str(selectedrecord),"I")
										break

									elif flashstatus[l-1]== "FAIL-TIMEOUT"  or flashstatus[l-1]=="STOPPED-NetworkFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure_OR_NetworkFailure"  or flashstatus[l-1]=="STOPPED-CLM_JOB_TIMED_OUT":
										foundlowest = True
										creationtime = record[1]
										script = record[0]
										selectedrecord = record
										logger.log(1,"Found record:"+str(selectedrecord),"I")
										#time.sleep(5)
										break


									else:
										logger.log(1,"[checknewrecord] Record is not pilot tested So let the testrecord in queue only","D")
										foundlowest = False


					else:
						foundlowest = False
						logger.log(1,"Not all capabilities matching","I")

		if 	foundlowest == True:
			return selectedrecord
		else:
			return None
###############################################################################################################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to UnLocked on Server Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialno String		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################

	def unlockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"QueueProcessor_Unlock Function Server Side","I")
			logger.log(1,"[QueueProcessor_UnlockDevices Server Side] Unlocking Device: "+str(deviceserialno),"I")
			unlockResult=self.deviceFarm.release_device(operation='release_device', serialno= str(deviceserialno))

			if unlockResult.get('releaseStatus')=='success' and unlockResult.get('result')=='ok':
				
				logger.log(1,"[QueueProcessor_UnlockDevices Server Side] Successfully unlocked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			

			logger.log(1,"[QueueProcessor_UnlockDevices Server Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False


########################################################################################################
	# SYNOPSIS:												#
    	# Return the product details	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test record for the job	
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# returnstr		String	Details of product
												#
    	#########################################################################################################
	def checkproduct(self,testRecord):	

		try:
			logger.log(1,"Inside checkproduct function","I")
			logger.log(1,"TestRecord for product:"+str(testRecord),"I")	
			logger.log(1,"WanTechnology required for product:"+str(testRecord[31]),"I")
			logger.log(1,"Hardwarerev required for product:"+str(testRecord[32]),"I")	
			logger.log(1,"Scan engine required for product:"+str(testRecord[33]),"I")
			returnstr = ""
			if str(testRecord[31])!= "Any":
				returnstr= returnstr+ " WanTechnology required for product:"+str(testRecord[31])+"\n"
			if str(testRecord[32])!= "Any":
				returnstr= returnstr+ " Hardwarerev required for product:"+str(testRecord[32])+"\n"
			if str(testRecord[33])!= "Any":
				returnstr= returnstr+ " Scan engine required for product:"+str(testRecord[33])+"\n"
			logger.log(1,"Return string="+str(returnstr),"I")
			return returnstr

		except:
			return "None"
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Locked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	
	def lock_device(self, **dataparam):
		try:
			logger.log(1,"QueueProcessor_Lock Function Node Side","I")
			logger.log(1,"[QueueProcessor_LockDevices Node Side] Locking Device: "+str(dataparam['serialno']),"I")
			logger.log(1,"Dataparam : "+str(dataparam),"I")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			#nodeServerUrl = 'http://' + '10.20.8.56' + '/interface'
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data : "+str(json_data),"I")
			if json_data['result'] == 'ok':
				lockresult = self.lockDevices(dataparam['serialno'])
				logger.log(1,"[QueueProcessor_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"I")
				return lockresult
			else:
				logger.log(1,"[QueueProcessor_LockDevices Node Side] Unsuccessful locking Device: "+str(dataparam['serialno']),"D")
				logger.log(1,"[QueueProcessor_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno']),"D")
				time.sleep(5)
				noofretry=0
				while noofretry!=3:
					noofretry=noofretry+1
					params = urllib.urlencode(dataparam)
			
					response = urllib2.urlopen(nodeServerUrl, params).read()
			
					json_data = json.loads(response)
					if json_data['result'] == 'ok':
						lockresult = self.lockDevices(dataparam['serialno'])
						logger.log(1,"[QueueProcessor_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"D")
						noofretry=3
						return lockresult
					else:
						logger.log(1,"[QueueProcessor_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno'])+"retrying attempt"+str(noofretry),"D")
						if noofretry==3:
							return False

					time.sleep(5)
		except Exception, e:
			

			logger.log(1,"[QueueProcessor_LockDevices Node Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Unlocked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	#Change the Device Lock Status to UnLocked on Node Side
	def unlock_device(self, **dataparam):
		try:
			logger.log(1,"QueueProcessor_Unlock Function Node Side","I")
			logger.log(1,"[QueueProcessor_UnlockDevices Node Side] Unlocking Device: "+str(dataparam['serialno']),"I")
			logger.log(1,"Dataparam : "+str(dataparam),"I")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data: "+str(json_data),"I")
			if json_data['result'] == 'ok':
				unlockresult = self.unlockDevices(dataparam['serialno'])
				logger.log(1,"[QueueProcessor_UnlockDevices Node Side] Successfully Unlocked Device: "+str(dataparam['serialno']),"I")
				return unlockresult
			else:
				logger.log(1,"[QueueProcessor_UnlockDevices Node Side] Unsuccessful Unlocking Device: "+str(dataparam['serialno']),"D")
				return False
		except Exception, e:
			

			logger.log(1,"[QueueProcessor_UnlockDevices Node Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False
####################################################################################################################################################
#########################################################################################################
	# SYNOPSIS:												#
    	# Change if any jobs are there in queue for unlocked devices avaialble				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA							#
    	#########################################################################################################
	def checkQueue_unlockeddevices(self):

		while True:
			try:

				pdtlist = []
				oslist = []
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				QUERY='SELECT distinct device_required FROM TBL_TEST_QUEUE'
				device_required=self.testQueue.execute(QUERY, "SELECT")
				trgger_check_queue=False

				
				if len(device_required) != 0:


					for j in device_required:

						if j[0]=='false':
							logger.log(1,"job in queue server side","D")

							trgger_check_queue=True

						elif j[0]=='true' :
							
							QUERY='SELECT distinct name from devicefarm.devicefarmalldevices,scheduler_db.TBL_TEST_QUEUE where locked = "false" and status = "online" and nodeonlinestatus = "online" and product=name ORDER BY priority;'
						
							Product_name =self.testQueue.execute(QUERY, "SELECT")
						

							if len(Product_name) != 0:
								for i in Product_name:
									logger.log(1,"job in queue","D")
									pdtlist.append(i)
									
									trgger_check_queue=True

							else:
								logger.log(1,"No job in queue","D")

					if trgger_check_queue:
						self.testQueue.close()
						self.checkQueueTable()
					else:
						self.testQueue.close()


				else:
					self.testQueue.close()
					time.sleep(5)



			except  Exception, e:

				logger.log(1,"Exception in checkQueue_unlockeddevices"+str(e),"E")
				time.sleep(3)

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Continuously check Queue table for incomming Data to be processed					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def checkQueueTable(self):


		try:
		
				if True:
					
					#Create Instance for Test Detail DB Interface
					
					self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
					
					QUERY='SELECT * FROM TBL_TEST_QUEUE ORDER BY priority;'
					print QUERY
					
					QueueRecord=self.testQueue.execute(QUERY, "SELECT")
					self.testQueue.close()
					
					if len(QueueRecord)>0:
						
						logger.log(1,"[QueueProcessor_checkQueueTable] Record is there in Jobs Queue Table","D")
						count=1
						for record in QueueRecord:
							if record[30]=="true":
								self.devicefarmdb = DB_Interface.devicefarm()
								unlockdevcount= self.devicefarmdb.getunlockeddevicescount(record[3])
								self.devicefarmdb.close()
								if unlockdevcount >=1:
									
									logger.log(1,"[QueueProcessor_checkQueueTable] Queue Record "+str(count),"D")
									
									logger.log(1,record,"I")
									logger.log(1,"[QueueProcessor_checkQueueTable] Queue Record "+str(record[15])+str(record[16])+str(record[17])+str(record[18])+str(record[31]),"I")
									
									if record[15]=="Manual" and record[30]=="true":
										if record[16]=='NA' and record[17]=='NA' and record[18]=='NA':
												
												logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Test Bed & Device for this Test Job in Manual Queue; So QueueProcessor will find Test Bed & Device for it","D")
												if record[19]!="NA":
													buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record[2]+"'"
													pilottested= buildInfo.execute(Query, "SELECT")
													buildInfo.close()
													if pilottested[0]=="YES":
														self.startProcess_NothingSelected(record)

													else:

														self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_number="'+record[2]+'"AND flash_status="IN_PROGRESS"'
														checkrecord=self.testRun.execute(query1,"SELECT");
														self.testRun.close()
														if checkrecord[0]==0:
															self.startProcess_NothingSelected(record)
														elif checkrecord[0]!=0:
															
															if record[29]=="YES":
																self.startProcess_NothingSelected(record)


															else:
																logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")




												else:
													self.startProcess_NothingSelected(record)


										elif record[16]!='NA' and record[17]!='NA' and record[18]=='NA':
												
												logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Device for this Test Job in Manual Queue; So QueueProcessor will find Device from select Test Bed for it","D")
												if record[19]!="NA":
													buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record[2]+"'"
													pilottested= buildInfo.execute(Query, "SELECT")
													buildInfo.close()
													if pilottested[0]=="YES":
														self.startProcess_TestBedSelected(record)
													else:
														self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_number="'+record[2]+'"AND flash_status="IN_PROGRESS"'
														checkrecord=self.testRun.execute(query1,"SELECT");
														self.testRun.close()
														if checkrecord[0]==0:
															self.startProcess_TestBedSelected(record)

														elif checkrecord[0]!=0:
															

															if record[29]=="YES":
																self.startProcess_TestBedSelected(record)

															else:
																logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")





												else:
													self.startProcess_TestBedSelected(record)

										elif record[16]!='NA' and record[17]!='NA' and record[18]!='NA':
										
												logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Device for this Test Job in Manual Queue; So QueueProcessor will find Device from select Test Bed for it","D")
												if record[19]!="NA":
													buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record[2]+"'"
													pilottested= buildInfo.execute(Query, "SELECT")
													buildInfo.close()
													if pilottested[0]=="YES":
														self.startProcess_TestBed_AND_DeviceSelected(record)
													else:
														self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_number="'+record[2]+'"AND flash_status="IN_PROGRESS"'
														checkrecord=self.testRun.execute(query1,"SELECT");
														self.testRun.close()
														if checkrecord[0]==0:
															self.startProcess_TestBed_AND_DeviceSelected(record)

														elif checkrecord[0]!=0:
															
															if record[29]=="YES":
																self.startProcess_TestBed_AND_DeviceSelected(record)

															else:
																logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")





												else:
													self.startProcess_TestBed_AND_DeviceSelected(record)


										elif record[16]=='NA' and record[17]=='NA' and record[18]!='NA':
												
												logger.log(1,"[QueueProcessor_checkQueueTable] From Error handler","D")

												if record[19]!="NA":
													buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record[2]+"'"
													pilottested= buildInfo.execute(Query, "SELECT")
													buildInfo.close()
													if pilottested[0]=="YES":
														self.startProcess_Error_handler(record)
													else:

														self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_number="'+record[2]+'"AND flash_status="IN_PROGRESS"'
														checkrecord=self.testRun.execute(query1,"SELECT");
														self.testRun.close()
														if checkrecord[0]<1:
															self.startProcess_Error_handler(record)

														elif checkrecord[0]>1:
															
															if record[29]=="YES":
																self.startProcess_Error_handler(record)
		
															else:
																logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")



												else:
													self.startProcess_Error_handler(record)



									elif record[15]=="Auto" and record[30]=="true":
										self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										query1='SELECT count(*) FROM TBL_RUNNING_TEST where build_xml_location="'+record[19]+'"';
										checkrecord=self.testRun.execute(query1,"SELECT");
										logger.log(1,"[QueueProcessor_checkQueueTable]  checkrecord "+str(checkrecord),"I")
										self.testRun.close()
										if record[16]=='NA' and record[17]=='NA' and record[18]!='NA':
											
											if checkrecord[0]<=1:
												logger.log(1,"[QueueProcessor_checkQueueTable] Error_handler","D")
												self.startProcess_Error_handler(record)


											elif checkrecord[0]>1:
													self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													query2='SELECT flash_status FROM TBL_RUNNING_TEST where build_xml_location="'+record[19]+'" ORDER BY id DESC';
													flashstatus=self.testRun.execute(query2,"SELECT");
													self.testRun.close()
													l=len(flashstatus)
													if record[29]=="YES":
														self.startProcess_Error_handler(record)
													elif flashstatus[l-1]== "FAIL-TIMEOUT"  or flashstatus[l-1]=="STOPPED-NetworkFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure_OR_NetworkFailure"  or flashstatus[l-1]=="STOPPED-CLM_JOB_TIMED_OUT":
														self.startProcess_Error_handler(record)
														
													else:
														logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")

											else:
												logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")

										elif checkrecord[0]==0:

											if record[16]=='NA' and record[17]=='NA' and record[18]=='NA':
												
												logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Test Bed & Device for this Test Job in Auto Queue; So QueueProcessor will find Test Bed & Device for it","D")
												self.startProcess_NothingSelected(record)
											elif record[16]!='NA' and record[17]!='NA' and record[18]=='NA':
												
												logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Device for this Test Job in Auto Queue; So QueueProcessor will find Device from select Test Bed for it","D")
												self.startProcess_TestBedSelected(record)

										elif checkrecord[0]!=0:
											self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											query2='SELECT flash_status FROM TBL_RUNNING_TEST where build_xml_location="'+record[19]+'" ORDER BY id DESC';
											flashstatus=self.testRun.execute(query2,"SELECT");
											self.testRun.close()
											l=len(flashstatus)

											if record[29]=="YES":

												if record[16]=='NA' and record[17]=='NA' and record[18]=='NA':
													
													logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Test Bed & Device for this Test Job in Auto Queue; So QueueProcessor will find Test Bed & Device for it","D")
													self.startProcess_NothingSelected(record)
												elif record[16]!='NA' and record[17]!='NA' and record[18]=='NA':
													
													logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Device for this Test Job in Auto Queue; So QueueProcessor will find Device from select Test Bed for it","D")
													self.startProcess_TestBedSelected(record)

											elif flashstatus[l-1]== "FAIL-TIMEOUT"  or flashstatus[l-1]=="STOPPED-NetworkFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure"  or flashstatus[l-1]=="STOPPED-jenkinsFailure_OR_NetworkFailure"  or flashstatus[l-1]=="STOPPED-CLM_JOB_TIMED_OUT":

												if record[16]=='NA' and record[17]=='NA' and record[18]=='NA':
													
													logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Test Bed & Device for this Test Job in Auto Queue; So QueueProcessor will find Test Bed & Device for it","D")
													self.startProcess_NothingSelected(record)
													
												elif record[16]!='NA' and record[17]!='NA' and record[18]=='NA':
													
													logger.log(1,"[QueueProcessor_checkQueueTable] User has not selected Device for this Test Job in Auto Queue; So QueueProcessor will find Device from select Test Bed for it","I")
													self.startProcess_TestBedSelected(record)
													


											else:
												logger.log(1,"[QueueProcessor_checkQueueTable] Record is not pilot tested So let the testrecord in queue only","D")

							elif record[15]=="Auto" and record[30]=="false":
								logger.log(1,"[QueueProcessor_checkQueueTable] Auto sysytem job","D")
								if record[16]=='NA' and record[17]=='NA':
									logger.log(1,"[QueueProcessor_checkQueueTable] Auto sysytem job system not selected","D")
									self.startProcess_System_not_Selected(record)

								elif record[16]!='NA' and record[17]!='NA':
									logger.log(1,"[QueueProcessor_checkQueueTable] Auto sysytem job system selected","D")
									self.startProcess_SystemSelected(record)

							elif record[15]=="Manual" and record[30]=="false":
								logger.log(1,"[QueueProcessor_checkQueueTable] Manaul sysytem job","D")
								if record[16]!='NA' and record[17]!='NA':
									logger.log(1,"[QueueProcessor_checkQueueTable] Manaul sysytem job system selected","D")
									self.startProcess_SystemSelected(record)
								elif record[16]=='NA' and record[17]=='NA':
									logger.log(1,"[QueueProcessor_checkQueueTable] MAnual sysytem job system not selected","D")
									self.startProcess_System_not_Selected(record)

							else:
								pass
							count=count+1
							
						logger.log(1,"[QueueProcessor_checkQueueTable] One Test Detail Processed","I")
					else:
						
						logger.log(1,"[QueueProcessor_checkQueueTable] No Record in  Jobs Queue Table","D")

				time.sleep(5)


		except Exception, e:
			

			logger.log(1,"[Queue Processor] checkQueueTable:EXCEPTION"+str(e),"E")

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check for emails to eb sent from queue. Check if email is sent only once per job					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	# subject	String		Subject of email
	# script_file	String		Script file in queue for which email is to be sent
	# creation_time	String		Creation time for Script file in queue for which email is to be sent
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################


	def Queue_email(self, subject,message,script_file,creation_time):

		self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		
		email_status = self.testQueue.checkEmailstatus(script_file, creation_time)
		email_reason = self.testQueue.checkEmailReason(script_file,creation_time)
		logger.log(1,"Email status from Queue email:"+email_status,"I")
		logger.log(1,"Email reason from Queue email:"+email_reason,"I")
		logger.log(1,"Subject from Queue email:"+str(subject),"I")
		if (email_status =="Not Sent" or email_status =="Sent") and email_reason != str(subject):
			logger.log(1,"Entered mail sending","D")
			self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+subject,message+'\n\n',[])
			email_status = "Sent"
			email_reason = str(subject)
			logger.log(1,"Email status from Queue email_1:"+email_status,"I")
			logger.log(1,"Email reason from Queue email_1:"+email_reason,"I")
			QUERY = "UPDATE TBL_TEST_QUEUE SET email_status='"+str(email_status)+"'"+","+"email_reason='"+str(email_reason)+"' where script_file='"+script_file+ "' and creation_timestamp='"+creation_time+"'"
			logger.log(1,"Query:"+str(QUERY),"I")

			if self.testQueue.execute(QUERY, "UPDATE")==1:
				self.testQueue.commit()

		else:
			pass
		self.testQueue.close()

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	# expectedcount		Integer		Expected count of secondary devices for the job # 		#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicelist		List	List of available secobdary devices 												
    	#########################################################################################################
	##############################################################################################################################################


	def lookforSecondarydevices(self,node,expectedcount):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicelist=[]
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		if expectedcount >=1:
			onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
			logger.log(1,"Online sec devices:","I")
			logger.log(1,str(onlineSecDevices),"I")
			for device in onlineSecDevices.get('devices'):
				if device.get('locked')=='true':
					lockedsecdevices.append(device)
				else:
					unlockedsecdevices.append(device)

		if len(unlockedsecdevices)>= expectedcount:
			i = 0
			while i< expectedcount:
					secdevicelist.append(unlockedsecdevices[i])
					i =i+1

		logger.log(1,"Available secondary devices:"+str(secdevicelist),"I")
		return secdevicelist
###################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicecount	Integer		Count of available secobdary devices 												
    	#########################################################################################################

	def getSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		secdevicecount = len(onlineSecDevices.get('devices'))
		logger.log(1,"total count of locked and unlocked secondary device from node:"+str(secdevicecount),"I")
		return secdevicecount


##########################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# unlockedsecdevicecount	Integer		Count of available unlocked secobdary devices 												
    	#########################################################################################################

	def getunlockedSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		unlockedsecdevicecount = len(unlockedsecdevices)
		logger.log(1,"count of unlocked secondary device from node:"+str(unlockedsecdevicecount),"I")
		return unlockedsecdevicecount


#######################################################################################################################################################



#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for which User has provided Test Bed & Device for execution		#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_TestBed_AND_DeviceSelected(self, queueRecord=None):
		
		try:

			self.lock.acquire()
			logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Lock Locking","I")
			#Create Instance for Queue DB Interface
			
			osName=None
			nodeWithAllSWCap=[]
			nodeWithAllCap = []
			nodeWithFewHWCap =[]
			nodeWithAllHWCap=[]
			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
			#Number of Devices Required
			totalSupportDeviceCount=int(queueRecord[14])
			PrimaryDeviceCount = 1
			
			logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Total Device Count: "+str(totalSupportDeviceCount),"I")

#######################################################################################################################################################

			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			# Variable initialisations
			flag=False
			lockflag = False
			nodeOnline = False
			locksecflag = False
			unlockedSecDevices = 0
			seclockedcount = 0
			countofSupportDevices = 0
			expectedDevicecount = 0
			deviceserialno= ""
			matchedDeviceCounter=0
			matchedSecDeviceCounter = 0
			nodeOnline= False
			inUseDevices = 0
			onlineCounter=0
			secjoblist=[]
			seclistjob =[]
			nodeavail = "false"
			#inUseHardware = []
			lockflagHw = 'false'
			foundAllCapNode=False
			foundFewCapNode=False
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			nodestobechecked =[]
			nodewithlocked = []
			nodeWithPri = []
			nodeWithSec=[]
			OnlineSecDevices = 0
			self.devicefarmdb.close()
			devavail = False
			lockResultsec = False
			lockResult = False
			foundnode = False
			unlockResultsec = False
			unlockResult = False
			# For scrum master-all nodes to be checked
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					
					logger.log(1,"Node="+str(node.get('friendlyname')),"I")
					
					swCap=node.get('softwares').split(',')
					hwCap = node.get('hardwares').split(',')
					
					logger.log(1,"Record testbedname:"+str(queueRecord[17]),"I")
					if str(node.get('friendlyname')) == str(queueRecord[17]) and str(node.get('location')) == str(queueRecord[16]) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online' :
						foundnode = True

						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							testJobDevices=[]
							if "," in queueRecord[18]:
								testJobDevices=queueRecord[18].split(",")
							else:
								testJobDevices.append(queueRecord[18])

							logger.log(1,"Test job devices:","I")
							logger.log(1,testJobDevices,"I")
							onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))

							countOfDevices=len(onlineDevices.get('devices'))
							#Maintain Device Info for Scheduling purpose
							deviceList=[]
							secdeviceList =[]
							supportDev = []
							if countOfDevices==0:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

							logger.log(1,"Online devices:"+str(onlineDevices),"I")
							for device in onlineDevices.get('devices'):
									logger.log(1,"Device="+str(device),"I")
									if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':


											if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):

												nodestobechecked.append(node)
												logger.log(1,"Nodes to be checked:"+str(nodestobechecked),"I")
												devavail = True
											else:
												continue

									elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
										
										if int(queueRecord[14])>1:
											OnlineSecDevices= self.getSecondaryDevicecount(node)
										logger.log(1,"Devices locked. Testjob will remain in queue","I")
										if self.matchDeviceSerialId(device.get('serialno'), testJobDevices) and OnlineSecDevices >= int(queueRecord[14])-1:
											nodewithlocked.append(node)


									else:
										continue
				if devavail!= True and foundnode== False:
							logger.log(1,"Send mail since node not present","I")
							message= "Dear admin,\n\n Requested node:"+str(queueRecord[17])+" not available for execution. Job "+str(queueRecord[10])+" will remain in queue"
							self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
			# For users other than scrummaster
			else:

				logger.log(1,"Prionodes="+str(prionodes),"D")
				if prionodes!= None:
						x = len(prionodes)
				else:
						x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				# Check in available priority nodes
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(queueRecord[27]),"D")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						logger.log(1,"Node="+str(node.get('friendlyname')),"I")
						logger.log(1,"Node type="+str(type(node)),"I")
						swCap=node.get('softwares').split(',')
						hwCap = node.get('hardwares').split(',')
						if node.get('friendlyname') == queueRecord[17] and node.get('location') == queueRecord[16]:
							foundnode = True
						logger.log(1,"Found node status:"+str(foundnode),"I")
						if foundnode == True:

							nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
							logger.log(1,"Node avail="+str(nodeavail[0]),"I")
							if nodeavail[0] == "true":

								testJobDevices=[]
								if "," in queueRecord[18]:
									testJobDevices=queueRecord[18].split(",")
								else:
									testJobDevices.append(queueRecord[18])

								logger.log(1,"Test job devices:"+str(testJobDevices),"D")
								
								onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))

								countOfDevices=len(onlineDevices.get('devices'))
								#Maintain Device Info for Scheduling purpose

								if countOfDevices==0:
									
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

								for device in onlineDevices.get('devices'):
										if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':


												if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):

													nodestobechecked.append(node)
													devavail = True
												else:
													continue

										elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
											if int(queueRecord[14]) > 1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
											if self.matchDeviceSerialId(device.get('serialno'), testJobDevices) and OnlineSecDevices >= int(queueRecord[14])-1:
												nodewithlocked.append(node)
												logger.log(1,"Devices locked. Testjob will remain in queue","I")


										else:
											continue

					if devavail!= True and foundnode== False:
							if commonnodes!= None:
									y = len(commonnodes)
							else:
									y = 0
							if y!= 0:
								for j in commonnodes:
										node= self.devfarmconvertToDictionary(j)
										
										swCap=node.get('softwares').split(',')
										hwCap = node.get('hardwares').split(',')
										if node.get('friendlyname') == queueRecord[17] and node.get('location') == queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
											foundnode = True
										if foundnode == True:

											nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
											logger.log(1,"Node avail="+str(nodeavail[0]),"I")
											if nodeavail[0] == "true":

												testJobDevices=[]
												if "," in queueRecord[18]:
													testJobDevices=queueRecord[18].split(",")
												else:
													testJobDevices.append(queueRecord[18])

												logger.log(1,"Test job devices:"+str(testJobDevices),"D")
												onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
												if int(queueRecord[14])>1:
													OnlineSecDevices= self.getSecondaryDevicecount(node)

												countOfDevices=len(onlineDevices.get('devices'))
												#Maintain Device Info for Scheduling purpose

												if countOfDevices==0:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

												for device in onlineDevices.get('devices'):
														if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':


																if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):

																	nodestobechecked.append(node)
																	devavail = True
																else:
																	continue

														elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
															logger.log(1,"Devices locked. Testjob will remain in queue","D")
															if self.matchDeviceSerialId(device.get('serialno'), testJobDevices) and  OnlineSecDevices >= int(queueRecord[14])-1:
																nodewithlocked.append(node)


														else:
															logger.log(1,"Send mail since node doesnt have devices required","D")
															
															break

								if foundnode == False:
									logger.log(1,"Send mail since node not present","D")
									

							else:
								if len(nodewithlocked)==0:
									logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")

				else:
					
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","D")
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y = 0
					logger.log(1,"Length of Commonnodes="+str(y),"I")
					if y!= 0:
							for j in commonnodes:
									node= self.devfarmconvertToDictionary(j)
									
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									if node.get('friendlyname') == queueRecord[17] and node.get('location') == queueRecord[16]:
										foundnode = True
									if foundnode == True:

										nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
										logger.log(1,"Node avail="+str(nodeavail[0]),"I")
										if nodeavail[0] == "true":

											testJobDevices=[]
											if "," in queueRecord[18]:
												testJobDevices=queueRecord[18].split(",")
											else:
												testJobDevices.append(queueRecord[18])

											logger.log(1,"Test job devices:","I")
											logger.log(1,testJobDevices,"I")
											onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
											if int(queueRecord[14])> 1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)

											countOfDevices=len(onlineDevices.get('devices'))
											#Maintain Device Info for Scheduling purpose

											if countOfDevices==0:
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

											for device in onlineDevices.get('devices'):
													if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':


															if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):

																nodestobechecked.append(node)
																devavail = True
															else:
																continue

													elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':

														if self.matchDeviceSerialId(device.get('serialno'), testJobDevices) and  OnlineSecDevices >= int(queueRecord[14])-1:
															nodewithlocked.append(node)
															logger.log(1,"No unlocked devices available. Job will remain in queue","I")

													else:
														logger.log(1,"Send mail since node doesnt have devices required","D")
														
														break

							if foundnode == False:
								logger.log(1,"Send mail since node not present","D")
								
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
						



			gitStatus = False
			if len(nodestobechecked)== 0:
					for node in allNodes.get('nodes'):
						'''parallelnodestatus = (node.get('parallelexec')).lower()
						print "Parallel execution status=",parallelnodestatus'''
						matchedDeviceCounter=0
						matchedSecDeviceCounter = 0
						inUseDevices = 0
						onlineCounter=0
						secjoblist=[]
						seclistjob =[]
						
						lockflagHw = 'false'
						foundAllCapNode=False
						foundFewCapNode=False
						
						logger.log(1,node,"I")
						if node.get('location')==queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
							
							logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Location Matched","D")
							if node.get('friendlyname')==queueRecord[17]:
								parrallelnodestatus=(node.get('parallelexec')).lower()
								systemlocked='false'
								if parrallelnodestatus=='false' and node.get('systemlock')=='true':
									systemlocked='true'
								if node.get('locked')!='True' and node.get('manualgit')!='True' and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
									parallelnodestatus = (node.get('parallelexec')).lower()
									logger.log(1,"Parallel execution status="+str(parallelnodestatus),"I")
									swCap = node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									logger.log(1,"External hwcap:"+str(hwCap),"I")
									unlockedSecDevices = 0
									seclockedcount = 0
									countofSupportDevices = 0
									expectedDevicecount = 0
									matchedDeviceCounter=0
									matchedSecDeviceCounter = 0
									inUseDevices = 0
									
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Bed Name Matched: "+ str(node.get('friendlyname')),"I")
									result=self.findSWCap(queueRecord[11].split(','), swCap)
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]: Result of SwCap: "+str(result),"I")

									hwresult=self.findHWCap(queueRecord[12].split(','), hwCap)
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]: Result of HwCap: "+str(hwresult),"I")

									noofunlocked = self.checkunlockeddevices(queueRecord[3],queueRecord[4], node['friendlyname'],queueRecord)
									logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
									if int(queueRecord[14]) >1:
											noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
											if noofavailsecdev >= int(queueRecord[14])-1:
												nodeWithSec.append(node)
												secresult = True
											else:
												secresult = False
									else:
										secresult = True
									if secresult == True:
										nodeWithSec.append(node)


										if result==0 and hwresult!= 0:
														#Put Node in nodeWithFewSWCap
														
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
														nodeWithFewHWCap.append(node)
														nodeWithAllSWCap.append(node)
										elif result!=0 and hwresult== 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithAllHWCap.append(node)
										elif result!=0 and hwresult!= 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithFewHWCap.append(node)
										elif result == 0 and hwresult==0:
											#Put Node in nodeWithAllSWCap
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
											
											nodeWithAllHWCap.append(node)
											nodeWithAllSWCap.append(node)
											if noofunlocked[0] >= 1:
												priavail= True
											else:
												priavail = False
											if priavail == True:
													nodeWithPri.append(node)


											else:
												logger.log(1,"No primary devices available","D")

												#nodeWithNoSec.append(node)
									else:
										logger.log(1,"Sufficient secondary dev not available","D")
										
								else:
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]Manual git is in progress","D")
									gitStatus = True

							else:
									
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]Test Bed Name not Matching","D")
									continue

						else:
							logger.log(1,"Test location not matching/ requested node not online","D")

					if gitStatus != True:
						logger.log(1,"Nodes with sec:"+str(nodeWithSec),"D")
						logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
						logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
						logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
						if len(nodeWithSec)== 0:
								message= "Dear admin,\n\n There is no testbed with required number of secondary devices available for execution for the scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue. \n Number of support devices required:"+str(queueRecord[14]-1)
								self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
								logger.log(1,"Required number of secondary devices not available","I")							



						else:

								if len(nodeWithAllSWCap)==0  and nodeOnline ==True:
										#Send EMAIL notification to Device Farm Admin
										
										message = "Dear user,\n\n Software capabilities not matching in any node for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
										print message
										
										self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))

										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")


								elif len(nodeWithAllHWCap)==0 and nodeOnline==True:
										message = "Dear user,\n\n Hardware capabilities not matching in any node for testsuite:"+str(queueRecord[10])+"\nExpected hardware capabilities:"+str(queueRecord[12]+'\n\n')
										print message

										self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")

										pass
								elif len(nodeWithPri)== 0:
									productresult = self.checkproduct(queueRecord)
									logger.log(1,"Primary device not available"+str(productresult),"I")
									message= "Dear admin,\n\n There is no testbed with primary devices available for execution for the testsuite:"+str(queueRecord[10])+ " for scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue.Primary device required:\n Product:"+str(queueRecord[3])+"\n OS:"+str(queueRecord[4])+"\n "+str(productresult)
									self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
									


			if len(nodestobechecked)!= 0:

					
					logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Found Nodes with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
					for node in nodestobechecked:

						lockflagHw = self.inUseHardware_nothingSelected(node.get('friendlyname'),queueRecord[12].split(","))

						if lockflagHw== 'true':
							logger.log(1,"Matching External HW in use for node. lET Test job remain in Queue","D")
							break


						
						parrallelnodestatus=(node.get('parallelexec')).lower()
						systemlocked='false'
						if parrallelnodestatus=='false' and node.get('systemlock')=='true':
							systemlocked='true'

						if lockflagHw != 'true' and node.get('locked')!='True' and node.get('manualgit')!='True' and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':


							if (node.get('location')==queueRecord[16] and node.get('friendlyname')==queueRecord[17]) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':

									matchedDeviceCounter=0
									matchedSecDeviceCounter = 0
									inUseDevices = 0
									onlineCounter=0
									onlineSecDevices=0
									countofSupportDevices =0
									unlockedSecDevices = 0

									secjoblist=[]
									seclistjob =[]
									parallelnodestatus = (node.get('parallelexec')).lower()
									
									lockflagHw = 'false'
									foundFewCapNode=False
									foundAllCapNode = True
									
									onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
									if int(queueRecord[14])>1:
										onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
										countofSupportDevices= self.getSecondaryDevicecount(node)
										unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)

									
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Online Devices: ","I")
									
									logger.log(1,onlineDevices,"I")
									countOfDevices=len(onlineDevices.get('devices'))
									logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Count of Online devices List from Device Farm"+str(countOfDevices),"I")
									
									#Maintain Device Info for Scheduling purpose
									deviceList=[]
									secdeviceList = []
									seclistjob=[]


									seclockedcount = int(countofSupportDevices) - int(unlockedSecDevices)
									logger.log(1,"Unlocked sec devices:"+str(unlockedSecDevices),"I")
									logger.log(1,"locked sec devices:"+str(seclockedcount),"I")

									if countOfDevices==0:
										
										logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")
									for device in onlineDevices.get('devices'):
										
										logger.log(1,device,"I")
										if device.get('status')=='online'  and device.get('locked')=='false' and device.get('secondary')=='false':
											onlineCounter=onlineCounter+1
											logger.log(1,"Dev serial no:"+str(device.get('serialno')),"I")
											logger.log(1,"Dev record list:"+str(queueRecord[18].split(",")),"I")
											if self.matchDeviceSerialId(device.get('serialno'), queueRecord[18].split(",")) :
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Primary Device Serial Number Matched","D")
												matchedDeviceCounter=matchedDeviceCounter+1
												deviceList.append(device)
												deviceserialno=str(device.get('serialno'))

												pass
											else:
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Device Serial Number Not Matched","D")
												pass


										elif device.get('flash_status')=='true' or device.get('locked')=='true':
											if device.get('secondary')=='false':
												inUseDevices=inUseDevices+1
												
												lockflag=True
												logger.log(1,"In use devices:"+str(inUseDevices),"I")



#######################################################################################################################################################
									totalSupportDeviceCount = int(queueRecord[14])
									logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
									if totalSupportDeviceCount <= 1:
										expectedDevicecount = 0
									else:
										expectedDevicecount = totalSupportDeviceCount - 1

									logger.log(1,"matchedSecDeviceCounter"+str(countofSupportDevices),"I")
									logger.log(1,"Expected sec dev count"+str(expectedDevicecount),"I")
									logger.log(1,"matched DeviceCounter"+str(matchedDeviceCounter),"I")
									logger.log(1,"Primary dev count"+str(PrimaryDeviceCount),"I")
									matchedSecDeviceCounter = countofSupportDevices

									if (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices>= expectedDevicecount):
											
											logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Found Exact Number of Devices required for Execution on Node: "+str(node.get('friendlyname')),"D")
											#Check if Node is parallel execution capable
											if parallelnodestatus =='true':
												#Lock the Devices
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Locking Devices before Starting Test Job","D")
												if deviceList != None:

													for device in deviceList:


														
														if device.get('secondary')=='false':
															logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Locking Device: "+str(device.get('serialno')),"D")
															#lockResult=self.lockDevices(device.get('serialno'))
															lockResult = self.lock_device(nodeip=device.get('node'), serialno=device.get('serialno'), user=queueRecord[20], operation='lock_device', lockingTool='CLM')
															logger.log(1,lockResult,"I")
															if lockResult!= False:

																lockflag = True


															if queueRecord[19]!='NA':
																flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=device.get('serialno'))

																if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																	

																	logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Successfully Set flash status as true","D")

															else:

																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))

												if expectedDevicecount >=1:
													secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
													if len(secdeviceList) != 0:
															i = 0

															while i < expectedDevicecount:
																seclistjob.append(secdeviceList[i].get('serialno'))
																
																lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=queueRecord[20], operation='lock_device', lockingTool='CLM')
																locksecflag = True
																i=i+1
												else:
													lockResultsec = True
												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												QUERY='SELECT script_file,creation_timestamp,sw_cap,hw_cap,support_device_count,priority,mode,build_number,build_xml_location,location,test_bed_name,devices,pilot_tested,scrum_name,user FROM TBL_TEST_QUEUE where test_bed_name="'+node.get('friendlyname')+'" AND devices="' + str(device.get('serialno'))+'" ORDER BY priority'
												NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
												result = self.checknewrecord(NewQueueRecord,node, secdeviceList)
												QUERY1 = 'SELECT * FROM TBL_TEST_QUEUE where script_file ="'+result[0]+ '" and creation_timestamp ="'+result[1]+'"'
												queueRecord=self.testQueue.execute(QUERY1, "SELECT")
												queueRecord = queueRecord[0]
												logger.log(1,"QueueRecord="+str(queueRecord),"I")
												self.testQueue.close()


												#Create Test Job & Trigger it
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Trigger Test Job on Device","I")
												#Create testCase.xml file for Test Job Execution
												setUp=JobPreSetup.SetUp()
												dictRecord=self.convertToDictionary(queueRecord, osName)
												preSetUP=setUp.doPreSetUp(dictRecord)
												if preSetUP[0]==True and lockResult != False and lockResultsec != False:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] TestCases.xml file created","D")
													#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
													job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
													#If Test Job Started; then only remove its corresponding Test Record from Queue
													jobStatus=job.startProcess()
													if jobStatus[0]:
														
														logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Removing Test Record from Manual Jobs Queue","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														if self.testQueue.removeFromQueue(queueRecord):
															
															logger.log(1, "Removed Test Job from Manual Jobs Queue","D")
														self.testQueue.close()
														
														logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Job Name: ","I")
														
														logger.log(1,jobStatus[1],"I")
														dictRecord['support_devices']=",".join(seclistjob)
														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
															
															logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Job put into Running List","D")
														break
													else:
														
														logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
														
														logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Devices after failure in Starting Test Job","I")
														if deviceList != None:
															for device in deviceList:
																
																logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Device: "+ str(device.get('serialno')),"D")
																lockflag = False

																unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
																print unLockResult
																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))


														if seclistjob!= None:


																	j = 0

																	while j < expectedDevicecount:
																		logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Secondary Device: "+str(seclistjob[j]),"D")
																		#unLockResult=self.unlockDevices(seclistjob[j])
																		unLockResultsec = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
																		
																		logger.log(1,unLockResultsec,"I")
																		j=j+1

																	locksecflag = False
														else:
															unLockResultsec = True
															if unLockResultsec == False or unLockResult == False:
																logger.log(1,"Error in unlocking device","D")
												else:
													logger.log(1," Error in locking device. Job will remain in queue","D")
											else:
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Node is not Parallel Execution Capable; So Check if there is already ongoing execution","D")
												#Check if there is already ongoing execution
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] countOfDevices: "+str(countOfDevices),"I")
												
												logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] countOfinuseDevices: "+str(inUseDevices),"I")
												
												if inUseDevices==0:
													
													logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] There is no ongoing execution on any Device of this Node; So Start Execution","D")
													#Lock the Devices
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Locking Devices before Starting Test Job","I")
													if deviceList != None:
														for device in deviceList:

															logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Locking Device: "+str(device.get('serialno')),"D")
															
															lockResult = self.lock_device(nodeip=device.get('node'), serialno=device.get('serialno'), user=queueRecord[20], operation='lock_device', lockingTool='CLM')
															logger.log(1,lockResult,"I")
															if lockResult!= False:

																lockflag = True
															if queueRecord[19]!='NA':

																flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=device.get('serialno'))

																if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																	

																	logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Successfully Set flash status as true","D")

															else:
																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))

													if expectedDevicecount >= 1:
														secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)

														if len(secdeviceList) != 0:

																i = 0

																while i < expectedDevicecount:
																	seclistjob.append(secdeviceList[i].get('serialno'))
																	
																	lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=queueRecord[20], operation='lock_device', lockingTool='CLM')
																	i = i+1
																locksecflag = True
													else:
														lockResultsec= True
														
													#Create Test Job & Trigger it
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Trigger Test Job on Device","I")
													#Create testCase.xml file for Test Job Execution
													setUp=JobPreSetup.SetUp()
													dictRecord=self.convertToDictionary(queueRecord, osName)
													preSetUP=setUp.doPreSetUp(dictRecord)
													if preSetUP[0]==True and lockResult != False and lockResultsec != False:
														
														logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] TestCases.xml file created","D")
														#Pass the TestCases.xml file name, Node & record to Jenkins Job Creation Module
														job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
														#If Test Job Started; then only remove its corresponding Test Record from Queue
														jobStatus=job.startProcess()
														if jobStatus[0]:
															
															logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Removing Test Record from Manual Jobs Queue","D")
															self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
															if self.testQueue.removeFromQueue(queueRecord):
																
																logger.log(1, "Removed Test Job from Manual Jobs Queue","D")
															self.testQueue.close()
															
															logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Job Name: ","I")
															
															logger.log(1,jobStatus[1],"I")
															dictRecord['support_devices']=",".join(seclistjob)
															if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
																
																logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Job put into Running List","D")
															break
														else:
															
															logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
															
															logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Devices after failure in Starting Test Job","I")

															if deviceList != None:
																for device in deviceList:
																	
																	logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Device: "+str(device.get('serialno')),"D")
																	lockflag = False
																	
																	unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
																	
																	flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))


															if seclistjob!= None:


																	j = 0

																	while j < expectedDevicecount:
																		logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] UnLocking Secondary Device: "+str(seclistjob[j]),"I")
																		
																		unLockResultsec = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
																	
																		logger.log(1,unLockResultsec,"I")
																		j=j+1

																	locksecflag = True
															else:
																unLockResultsec = True
															if unLockResultsec == False or unLockResult == False:
																logger.log(1,"Error in unlocking device","D")
													else:
														logger.log(1," Error in locking device. Job will remain in queue","D")

	#######################################################################################################################################################
												else:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] else block countOfDevices: "+str(countOfDevices),"D")
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] else block onlineCounter: "+str(onlineCounter),"I")
													
													logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] There is Already ongoing execution on this Node; SO let the Test Job in Manual Jobs Queue","I")
													pass
	#######################################################################################################################################################
									elif (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices< expectedDevicecount and seclockedcount!=0):
											logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] No sufficient Unlocked Sec Device Count for execution; So let the Test Job in Manual Jobs Queue","D")


									elif (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices < expectedDevicecount) and seclockedcount==0:
											logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] There are no sufficient support Devices for execution on User Selected Node; Send email to admin" ,"I")
											
											message= "Dear user,\n\n No sufficient Secondary Device for execution found in requested testbed:"+str(queueRecord[16])+" for testsuite:"+str(queueRecord[10])+"\n"+'\n\n'
											self.Queue_email(self.subject['No_sufficient_device'],message,str(queueRecord[10]),str(queueRecord[21]))



									else:
											
											logger.log(1, "[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] No sufficient Unlocked Device Count for execution; So let the Test Job in Manual Jobs Queue","D")
											if lockflag!= True:
												message= "Dear user,\n\n No sufficient Unlocked Primary Device for execution found in requested testbed :"+str(queueRecord[16])+" for testsuite:"+str(queueRecord[10])+"\nExpected device:"+str(queueRecord[18])+'\n\n'
												self.Queue_email(self.subject['No_sufficient_device'],message,str(queueRecord[10]),str(queueRecord[21]))


#######################################################################################################################################################

							elif (node.get('location')== queueRecord[16] and node.get('friendlyname')==queueRecord[17]) and (node.get('nodejenkinsonlinestatus')!='online' or node.get('nodeonlinestatus')!='online'):
								message = "Dear user,\n\n Requested node has gone offline.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
								print message

								self.Queue_email(self.subject['Requested_node_offline'],message,str(queueRecord[10]),str(queueRecord[21]))
								logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]: Requested node has gone offline. Send EMAIL notification to Device Farm Admin","I")


							else:
								
								logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Test Bed Location not Matching/Requested node not online","D")

#######################################################################################################################################################

			
#######################################################################################################################################################
		except Exception, e:
			
			logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected]:exception:"+str(e),"E")
			return False

		finally:
			
			self.lock.release()
			logger.log(1,"[QueueProcessor_startProcess_TestBed_AND_DeviceSelected] Lock Releasing","I")

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for which User has provided only Test Bed for execution			#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_TestBedSelected(self, queueRecord=None):
		
		try:
			self.lock.acquire()
			logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Lock Locking","I")
			#Create Instance for Queue Database
			

			osName=None

			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			self.ScrumDetails.close()
			#Number of Devices Required
			totalSupportDeviceCount=int(queueRecord[14])
			
			logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Total Device Count: "+str(totalSupportDeviceCount),"I")
			nodeWithAllSWCap =[]
			lockflag = False
			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			
			flag=False
			email_status = "Not Sent"
			email_reason = "None"
			nodeWithFewHWCap = []
			nodeWithAllCap = []
			nodeWithAllHWCap=[]
			nodeWithAllSWCap=[]
			nodeWithFewSWCap = []
			nodeWithFewHWCap=[]
			unlockedSecDevices = 0
			seclockedcount = 0
			unlockedDevices=0
			expectedDevicecount = 0
			matchedSecDeviceCounter = 0
			foundAllHWCapNode = False
			devavail = False
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			
			self.devicefarmdb.close()
			nodestobechecked =[]
			nodewithlocked = []
			nodeWithPri=[]
			nodeWithSec=[]
			nodeOnline = False
			nodeavail = "false"
			lockeddev = 0
			OnlineSecDevices=0
			foundNode = False
			lockResult = False
			unLockResult = False
			lockResultsec = False
			unLockResultsec = False
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					
					swCap=node.get('softwares').split(',')
					hwCap = node.get('hardwares').split(',')
					
					if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						foundnode = True
						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
					if nodeavail[0]== "true" and foundnode == True:
						nodestobechecked.append(node)
						devavail = True
					elif nodeavail[0]!= "SW-HW cap not matching":
							if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
								if int(queueRecord[14])>1:
									OnlineSecDevices= self.getSecondaryDevicecount(node)
								lockeddev = nodeavail[2]
							if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
								nodewithlocked.append(node)
							else:
								continue

			else:
				
				if prionodes!= None:
							x = len(prionodes)
				else:
							x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(queueRecord[27]),"D")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						hwCap = node.get('hardwares').split(',')
						
						if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
							foundNode = True
							nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
							logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0]== "true" and foundNode == True:
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
								if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
									if int(queueRecord[14])> 1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									lockeddev = nodeavail[2]
									if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
										nodewithlocked.append(node)
								else:
									continue
					if devavail!= True and foundNode == False:
						if commonnodes!= None:
							y = len(commonnodes)
						else:
							y = 0
						if y != 0:
							for j in commonnodes:
									node= self.devfarmconvertToDictionary(j)
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
										foundNode = True
										nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
									if nodeavail[0]== "true" and foundNode == True:
										nodestobechecked.append(node)
										logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
										devavail = True
									elif nodeavail[0]!= "SW-HW cap not matching":
										if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
											lockeddev = nodeavail[2]
											if int(queueRecord[14]) >1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
										if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
											nodewithlocked.append(node)
										else:
											pass
							if len(nodestobechecked)== 0:
								if len(nodewithlocked) != 0:
									logger.log(1,"Nodes available with locked devices. Job will remain in queue","I")

								else:
									logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
									
						else:
							if len(nodewithlocked)==0:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								

					else:
						if len(nodewithlocked)==0:
							logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
							

				else:
					
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
					if commonnodes!= None:
							y = len(commonnodes)
					else:
							y = 0

					logger.log(1,"Length of Commonnodes="+str(y),"I")
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								hwCap = node.get('hardwares').split(',')
								if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
									nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
									logger.log(1,"Node avail="+str(nodeavail[0]),"I")
									foundNode= True
								if nodeavail[0]== "true" and foundNode== True :
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
									devavail = True

								else:
									continue

								if devavail != True and nodeavail[0]!= "SW-HW cap not matching":
									if node.get('friendlyname')== queueRecord[17] and node.get('location') == queueRecord[16]:
										lockeddev = self.checklockeddevices(queueRecord[3],queueRecord[4], node.get('friendlyname'))
										if int(queueRecord[14])>1:
											OnlineSecDevices= self.getSecondaryDevicecount(node)
										if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
											nodewithlocked.append(node)
									else:
										pass
						if len(nodestobechecked)== 0:

							
							if len(nodewithlocked) != 0:
								logger.log(1,"Testbeds available for execution in locked testbeds. The job will remain in queue","D")
								
							else:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
						
#######################################################################################################################################################
			gitStatus = False
			if len(nodestobechecked)== 0:
						if len(nodewithlocked) != 0:
							logger.log(1,"Testbeds available for execution in locked testbeds. The job will remain in queue","D")
						else:
							for node in allNodes.get('nodes'):

									matchedDeviceCounter=0
									matchedSecDeviceCounter=0
									lockflag = False
									locksecflag = False
									lockflagHw = 'false'
									product = ""
									os_version= ""
									noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
									noofunlocked = self.checkunlockeddevices(queueRecord[3],queueRecord[4], node['friendlyname'],queueRecord)
									logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")

									
									logger.log(1,node,"I")
									PrimaryDeviceCount=1
									if node.get('location')==queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online':
											
											logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Location Matched","D")

											if node.get('friendlyname')==queueRecord[17] and node.get('location') == queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
													parrallelnodestatus=(node.get('parallelexec')).lower()
													systemlocked='false'
													if parrallelnodestatus=='false' and node.get('systemlock')=='true':
														systemlocked='true'
													if node.get('locked')!='True' and node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED' and systemlocked=='false':
															nodeOnline = True
															if int(queueRecord[14]) >1:
																noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
																if noofavailsecdev >= int(queueRecord[14])-1:
																	nodeWithSec.append(node)
																	secresult = True
																else:
																	secresult = False
															else:
																secresult = True
															if secresult == True:
																nodeWithSec.append(node)
																swCap=node.get('softwares').split(',')
																hwCap = node.get('hardwares').split(',')
																logger.log(1,"External hwcap:"+str(hwCap),"I")
																matchedDeviceCounter=0
																matchedSecDeviceCounter=0

																result=self.findSWCap(queueRecord[11].split(','), swCap)
																logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Result of SwCap: "+str(result),"I")
																hwresult=self.findHWCap(queueRecord[12].split(','), hwCap)
																logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Result of HwCap: "+str(hwresult),"I")

																if result==0 and hwresult!= 0:
																	#Put Node in nodeWithFewSWCap
																	
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Few Test Suite HW Capabilities Found in this Node","D")
																	nodeWithFewHWCap.append(node)
																	nodeWithAllSWCap.append(node)
																elif result!=0 and hwresult== 0:
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Few Test Suite SW Capabilities Found in this Node","D")
																	nodeWithFewSWCap.append(node)
																	nodeWithAllHWCap.append(node)
																elif result!=0 and hwresult!= 0:
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
																	nodeWithFewSWCap.append(node)
																	nodeWithFewHWCap.append(node)
																elif result == 0 and hwresult==0:
																	#Put Node in nodeWithAllSWCap
																	
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] All Test Suite HW Capabilities Found in this Node","D")
																	#nodeWithAllCap.append(node)
																	nodeWithAllHWCap.append(node)
																	nodeWithAllSWCap.append(node)
																	if noofunlocked[0] >= 1:
																		priavail= True
																	else:
																		priavail = False
																	if priavail == True:
																			nodeWithPri.append(node)


																	else:
																		logger.log(1,"No primary devices available","D")

																		
															else:
																logger.log(1,"Sufficient secondary dev not available","D")
																
													else:
															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Manual git is in progress","D")
															gitStatus= True

											else:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Bed Location not Matched/ Requested test node not online","D")
													continue

							if gitStatus!= True:
								logger.log(1,"Nodes with sec:"+str(nodeWithSec),"D")
								logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
								logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
								logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
								if len(nodeWithSec)== 0:
										message= "Dear admin,\n\n There is no testbed with required number of secondary devices available for execution for the scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue. \n Number of support devices required:"+str(queueRecord[14]-1)
										self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
										


								else:

										if len(nodeWithAllSWCap)==0  and nodeOnline ==True:
												#Send EMAIL notification to Device Farm Admin
												
												message = "Dear user,\n\n Software  capabilities not matching in any node for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
												print message
												
												self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))

												logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")


										elif len(nodeWithAllHWCap)==0 and nodeOnline==True:
												message = "Dear user,\n\n Hardware capabilities not matching in any node for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
												
												self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
												
												logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")

												pass
										elif len(nodeWithPri)== 0 and nodeOnline==True:
											productresult = self.checkproduct(queueRecord)
											logger.log(1,"Primary device not available"+str(productresult),"I")
											message= "Dear admin,\n\n There is no testbed with primary devices available for execution for the testsuite:"+str(queueRecord[10])+ " for scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue.Primary device required:\n Product:"+str(queueRecord[3])+"\n OS:"+str(queueRecord[4])+"\n "+str(productresult)
											self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
											


			else:
					logger.log(1,"Queue Processor here","D")

					for node in nodestobechecked:
						parrallelnodestatus=(node.get('parallelexec')).lower()
						systemlocked='false'
						if parrallelnodestatus=='false' and node.get('systemlock')=='true':
							systemlocked='true'
						
						logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Found Nodes with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","I")

						if node.get('friendlyname')==queueRecord[17] and node.get('location') == queueRecord[16] and  node.get('locked')!='True' and node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED' and systemlocked=='false' :
							matchedDeviceCounter=0
							matchedSecDeviceCounter=0
							lockflag = False
							locksecflag = False
							lockflagHw = 'false'
							product = ""
							os_version= ""
							lockflagHw = self.inUseHardware_nothingSelected(node.get('friendlyname'),queueRecord[12].split(","))

							if lockflagHw== 'true':
								logger.log(1,"Matching External HW in use for node. lET Test job remain in Queue","D")
								break


							logger.log(1,"Node with both HW and SW capability:"+str(nodestobechecked),"D")


							if lockflagHw != 'true':
								
									if node.get('friendlyname')==queueRecord[17] and node.get('location') == queueRecord[16]:
										
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Bed Name Matched: "+str(node.get('friendlyname')),"I")
										result=self.findSWCap(queueRecord[11].split(','), swCap)
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Result of SwCap: "+str(result),"D")

										#Unlocked Devices Counter
										unlockedDevices=0
										unlockedSecDevices=0
										
										logger.log(1,node,"I")

										onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
										inUseDevices = 0

										parallelnodestatus = (node.get('parallelexec')).lower()
										print "Parallel execution status=",parallelnodestatus
										logger.log(1,"Parallel execution status="+str(parallelnodestatus),"I")

										
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] All Devices for this Node: ","I")
										
										foundAllHWCapDevice=False
										foundFewHWCapDevice=False
										logger.log(1,onlineDevices.get('devices'),"I")
										countOfDevices=len(onlineDevices.get('devices'))
										#Maintain Device Info for Scheduling purposon new:(('Requested Node not having matching SW Capabie
										deviceList=[]
										secdeviceList=[]
										seclistjob = []
										inUseSecDevices=0
										
										matchDevices=0
										matchSecDevices=0
										matchedSecDeviceCounter=0
										unlockedSecDevices=0

										if int(queueRecord[14])>1:
											matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
											unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
										seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)

										for device in onlineDevices.get('devices'):
											
											logger.log(1,device,"I")
											if device.get('status')=='online' and device.get('locked')=='false':
												#Get Product & OS Information for all selected Online Devices from above step &
												#Select only those Devices, which have matching Product &
												#OS info mentioned in record['product'] & record['os']
												
												logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Matching Product & OS","D")
												OS_MAP=None
												osFlag=False
												if str(queueRecord[15])=="Manual":
													
													for osIter in queueRecord[4].split(","):
														
														logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] OS: "+str(osIter.strip(" '")),"D")
														if str(device.get('version')).split("-")[1] == str(osIter.strip(" '")):
															
															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] OS Version Matched: "+str(osIter.strip(" '")),"D")
															osFlag=True
															osName=osIter.strip(" '")
															break

												elif str(queueRecord[15])=="Auto":
													for osIter in queueRecord[4].split(" "):
														logger.log(1,"OsIter="+str(osIter),"D")

														if str(str(device.get('version')).split("-")[1]) == str(osIter):

															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] OS Version Matched: "+str(osIter),"D")
															osFlag = True

												
												logger.log(1,str(device.get('version')).split("-")[1]+queueRecord[4],"I")

												logger.log(1,device.get('name')+queueRecord[3],"I")
												

												#if device.get('name')==queueRecord[3] and device.get('version')==queueRecord[4].split(" ")[1]:Uncomment It*******************************************************************************************************************************
												
												result1=self.checkfordevice(queueRecord,device)
												if result1 and osFlag == True:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Device Product, OS Matched","D")
													product = str(device.get('name'))
													os_version = str(device.get('version')).split("-")[1]
													#Get Devices which has all HW Capabilities mentioned in 									#record ['hw_cap']
													#If there is no Device found in any Node, then send EMAIL to Device
													#Farm Admin; Else Continue next Step
													
													if device.get('secondary') == 'false':
															
															deviceList.append(device)
															foundAllHWCapNode=True
															foundAllHWCapDevice=True
															unlockedDevices=unlockedDevices+1


											elif device.get('locked')=='true' or device.get('flash_status')=='true':
												if device.get('secondary')=='false':
													inUseDevices=inUseDevices+1
													lockflag= True

											else:
												lockflag= False
												logger.log(1,"Device offline","I")
				#######################################################################################################################################################
									totalSupportDeviceCount = int(queueRecord[14])
									logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
									if totalSupportDeviceCount <= 1:
										expectedDevicecount = 0
									else:
										expectedDevicecount = totalSupportDeviceCount - 1



									logger.log(1,"Matched sec devices:"+str(matchedSecDeviceCounter),"I")

									logger.log(1,"Expected device count:"+str(expectedDevicecount),"I")

									logger.log(1,"Status of HW cap:"+str(foundAllHWCapDevice),"I")
									if foundAllHWCapDevice == True and (matchedSecDeviceCounter>= expectedDevicecount):
										
										logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] Unlocked Devices: "+ str(unlockedDevices),"D")
										
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")
										
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] locked Secondary Device count: "+ str(seclockedcount),"I")


										
										logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Required Devices for Test Execution: "+str(expectedDevicecount),"I")
										#Check testRecord['support_device_count'] info & verify whether Node has sufficient
										#device count for execution
										if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
											
											logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Node has sufficient Device Count for Execution","D")
											

											logger.log(1,"Parallel execution status="+str(parallelnodestatus),"I")
											#######################################################################################################################################################
											secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											QUERY='SELECT script_file,creation_timestamp,sw_cap,hw_cap,support_device_count,priority,mode,build_number,build_xml_location,location,test_bed_name,devices,pilot_tested,scrum_name,user FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" AND test_bed_name="'+node.get('friendlyname')+'" ORDER BY priority;'
											NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
											result = self.checknewrecord(NewQueueRecord,node, secdeviceList)
											QUERY1 = 'SELECT * FROM TBL_TEST_QUEUE where script_file ="'+result[0]+ '" and creation_timestamp ="'+result[1]+'"'
											queueRecord=self.testQueue.execute(QUERY1, "SELECT")
											queueRecord = queueRecord[0]
											logger.log(1,"QueueRecord="+str(queueRecord),"I")
											self.testQueue.close()

											if parallelnodestatus =='true':
												
												logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] Node is Parallel Execution Capable; So Remove Record from Manual Job Queue, Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")

												
												#Create Test Job & Trigger it
												
												logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Trigger Test Job on Device","I")

												#Create testCase.xml file for Test Job Execution
												setUp=JobPreSetup.SetUp()
												dictRecord=self.convertToDictionary(queueRecord, osName)
												preSetUP=setUp.doPreSetUp(dictRecord)
												if preSetUP[0]==True:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] TestCases.xml file created","D")
													#Pass thi TestCases.xml file name, Node & record to Jenkins Job Creation Module
													job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
													#If Test Job Started; then only remove its corresponding Test Record from Queue
													#jobStatus=job.startProcess()
													#if jobStatus[0]:
													if True:
														

														logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Job Name: ","D")
														
														

														
														logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Locking Devices before Starting Test Job","I")
														
														if deviceList!= None:

															
															lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															logger.log(1,lockResult,"I")

															if queueRecord[19]!='NA':
																flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))

																if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																	
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Successfully Set flash status as true","D")

															else:
																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))

														if expectedDevicecount >=1:
															if len(secdeviceList)!= 0:
																i = 0
																seclistjob = []
																while i < expectedDevicecount:
																	seclistjob.append(secdeviceList[i].get('serialno'))
																	logger.log(1,"Sec job list:"+str(seclistjob),"I")
																	
																	lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																	logger.log(1,lockResultsec,"I")

																	i = i+1

														else:
															lockResultsec = True

														#Add Test Bed & Device Data to Test Record (For Auto Mode)
														
														logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Putting Test Bed & Device Details: ","I")
														
														logger.log(1,deviceList[0].get('serialno'),"I")
														dictRecord['devices']=deviceList[0].get('serialno')
														dictRecord['support_devices']=",".join(seclistjob)
														if lockResultsec != False and lockResult != False:

															jobStatus=job.startProcess()
															if jobStatus[0]:
																logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Removing Test Record from Manual Jobs Queue","D")
																self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
																if self.testQueue.removeFromQueue(queueRecord):
																
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Removed Test Job from  Jobs Queue","D")
															
																self.testQueue.close()

																if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
																
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Job put into Running List","D")
																break
															else:

																logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
														
																logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","I")
														
																lockflag = False
																locksecflag = False
														
																#logger.log(1,unLockResult,"I")
																break

														else:
															logger.log(1,"Error in locking the device. Job will remain in queue","D")
															#job.removefromjenkins(str(jobStatus[1]),str(node.get('friendlyname')))
															logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
													else:
														
														logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
														
														logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","I")
														
														lockflag = False
														locksecflag = False
														
														logger.log(1,unLockResult,"I")


				#######################################################################################################################################################

											else:
												
												logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Node is not Parallel Execution Capable","D")
												#Check whether there is any already ongoing execution on Test Bed
												#If no Ongoing execution then Schedule test Job
												#& trigger it on Test Bed
												#Else put Test Job in Queue
												logger.log(1,"count of devices"+str(countOfDevices),"I")
												logger.log(1,"unlockedDevices"+str(unlockedDevices),"I")
												logger.log(1,"matchedDevices"+str(matchDevices),"I")
												
												logger.log(1,"in use devices"+str(node.get('inUseDevices')),"I")
												if inUseDevices==0:
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")
													
													#Create Jenkins Job for this Test Job &
													#Trigger it on Test Bed
													#Create Test Job & Trigger it
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Trigger Test Job on Device","I")
													#Create testCase.xml file for Test Job Execution
													secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
													setUp=JobPreSetup.SetUp()
													dictRecord=self.convertToDictionary(queueRecord, osName)
													preSetUP=setUp.doPreSetUp(dictRecord)
													if preSetUP[0]==True:
														
														logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] TestCases.xml file created","D")
														#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
														job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
														#If Test Job Started; then only remove its corresponding Test Record from Queue
														#jobStatus=job.startProcess()
														#if jobStatus[0]:
														if True:
															

															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Job Name: ","D")
															
															

															
															if deviceList!= None:
																#lockResult=self.lockDevices(deviceList[0].get('serialno'))
																lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																
																logger.log(1,lockResult,"I")
																if queueRecord[19]!='NA':
																	flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))

																	if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																		

																		logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Successfully Set flash status as true","D")

																else:
																	flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))

																lockflag = True
															if expectedDevicecount>=1:
																if len(secdeviceList)!= 0:
																	i =0

																	while i < expectedDevicecount:
																			seclistjob.append(secdeviceList[i].get('serialno'))

																			
																			lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																			logger.log(1,lockResultsec,"I")
																			i=i+1

																	locksecflag = True
															else:
																lockResultsec = True
															#Add Test Bed & Device Data to Test Record (For Auto Mode)
															
															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Putting Test Bed & Device Details: ","I")
															
															logger.log(1,deviceList[0].get('serialno'),"I")
															dictRecord['devices']=deviceList[0].get('serialno')
															dictRecord['support_devices']=",".join(seclistjob)

															if lockResult != False and lockResultsec != False:
																jobStatus=job.startProcess()
																if jobStatus[0]: 	
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Removing Test Record from Manual Jobs Queue","D")
																	self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
																	if self.testQueue.removeFromQueue(queueRecord):
																	
																		logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Removed Test Job from  Jobs Queue","D")
																
																	self.testQueue.close()
																	if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
																	
																		logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Job put into Running List","D")
																	break
																else:
																	logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
																	lockflag = False
															
																	logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","I")
																	break
															else:
																logger.log(1,"Error in locking device. Job will remain in queue","D")
																#job.removefromjenkins(str(jobStatus[1]),str(node.get('friendlyname')))
																logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")													
														else:
															
															logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
															lockflag = False
															
															logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","I")
															


												else:
													#Put Test Job in Queue
													
													logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So Let the Test Job in Queue","D")
													pass
										elif unlockedSecDevices< expectedDevicecount and seclockedcount!=0:
											logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] No unlocked Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")

										elif unlockedSecDevices< expectedDevicecount and seclockedcount==0:
											logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] No Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")


											if locksecflag!=True:
												message = "Dear user,\n\n Requested node does not have sufficient number of support devices with matching HW capability.Testsuite:"+str(queueRecord[10])+" will remain in queue.\n Expected number of support devices:"+str(expectedDevicecount)+" \nExpected hardware capabilities:"+str(queueRecord[12])+"\nExpected product:"+str(queueRecord[3])+"\nExpected OS version:"+str(queueRecord[4])+"\n\n"
												print message

												self.Queue_email(self.subject['No_sufficient_supportdevice'],message,str(queueRecord[10]),str(queueRecord[21]))



									else:
										
										logger.log(1, "[QueueProcessor_startProcess_TestBedSelected] No Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")

										if lockflag!=True:
											message = "Dear user,\n\n Requested node has no device with matching HW capability.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected hardware capabilities:"+str(queueRecord[12])+"\nExpected product:"+str(queueRecord[3])+"\nExpected OS version:"+str(queueRecord[4])+"\n\n"
											print message

											self.Queue_email(self.subject['No_sufficient_device'],message,str(queueRecord[10]),str(queueRecord[21]))

			#######################################################################################################################################################


						elif (node.get('location')==queueRecord[16] and node.get('friendlyname')==queueRecord[17]) and (node.get('nodejenkinsonlinestatus')!='online' or node.get('nodeonlinestatus')!='online'):
							message = "Dear user,\n\n Requested node has gone offline.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
							print message

							self.Queue_email(self.subject['Requested_node_offline'],message,str(queueRecord[10]),str(queueRecord[21]))
							logger.log(1,"[QueueProcessor_startProcess_TestBedSelected]: Requested node has gone offline. Send EMAIL notification to Device Farm Admin","I")

						else:
							
							logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Bed Location not Matched/Requested node not online","D")


#######################################################################################################################################################

			
#######################################################################################################################################################
		except Exception, e:
		

			logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Exception"+str(e),"E")
			return False

		finally:
			
			self.lock.release()
			logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Lock Releasing and testRun db connection closed","I")





#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check if teh hardware is in use for the node selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# nodename		String		Node name	
	# hwCap			String		Hardware capability to be checked						#
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################

	def inUseHardware_nothingSelected(self, nodename, hwCap):

		self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		lockflagHw = 'false'
		inUseHardware = self.testRun.inUseHwCap(nodename)
		self.testRun.close()
		inUseHardware = str(inUseHardware)
		inUseHardware = inUseHardware.replace("(","")
		inUseHardware = inUseHardware.replace(")","")
		inUseHardware = inUseHardware.replace("'","")
		logger.log(1,"In use hardware:"+str(inUseHardware),"I")

		if inUseHardware.split(",")[0] == "NA":
			logger.log(1,"No hardware required","D")
			return lockflagHw

		else:
			for a in hwCap:
				
					j= 0
					if len(inUseHardware)!=0:
							if "," in inUseHardware:
								inUseHardware = inUseHardware.split(",")

								logger.log(1,"New in use hardware:"+str(inUseHardware),"I")
							for j in inUseHardware:
									logger.log(1,"a"+str(a.strip(' ')),"I")
									
									if a.strip(' ')==j.encode('ascii', 'ignore'):
										logger.log(1, "Found match with in use hardware","D")
										lockflagHw = 'true'
										
										break

			return lockflagHw


	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of unlocked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked
    	# os	string			OS version to be checked
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# unlockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################

	def checkunlockeddevices(self, product,os,nodename,queueRecord):
		logger.log(1,"Inside unlocked devices","I")
		unlockedcount = 0
		lockedcount = 0
		resultarray = []
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices=  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		
		for device in devices['devices']:
			
			result1=self.checkfordevice(queueRecord,device)
			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os and device.get('secondary')=='false' and result1==True:
					logger.log(1,"Locked status="+str(device.get('locked').lower()),"D")
					if str(device.get('locked').lower()) != "true":
						unlockedcount=unlockedcount+1
						logger.log(1,"Found unlocked device="+str(device.get('name')),"I")
					else:
						lockedcount=lockedcount+1

		resultarray.append(unlockedcount)
		resultarray.append(lockedcount)
		return resultarray

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of locked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked
    	# os	string			OS version to be checked
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# lockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################

	def checklockeddevices(self, product,os,nodename):

		lockedcount = 0
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices =  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		for device in devices['devices']:
			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os:
					if str(device.get('locked').lower()) == 'true':
						lockedcount=lockedcount+1
					else:
						pass
		return lockedcount

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find nodes with unlocked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	dictionary	Record to be checked
    	# node	    dictionary  Node to be checked
    	# 						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# lockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################

	def checknode(self, record,swcap,hwcap,node={}):
		checknode = None
		logger.log(1,"Inside checknode","I")
		logger.log(1,"Inside checknode TESTBED"+str(node['friendlyname']),"I")
		
		noofdevices = self.checkunlockeddevices(record[3],record[4], node['friendlyname'],record)
		noofunlocked = noofdevices[0]
		nooflocked = noofdevices[1]
		resultarray=[]
		logger.log(1,"No of unlocked device:"+str(noofunlocked)+" No of locked=" +str(nooflocked),"I")

		result=self.findSWCap(record[11].split(','), swcap)
		hwresult=self.findHWCap(record[12].split(','), hwcap)
		if result == 0 and hwresult==0:
			if noofunlocked >= 1:
				if int(record[14]) >1:
					noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
					if noofavailsecdev >= int(record[14])-1:
						checknode = "true"
					else:
						logger.log(1,"Required secondary devices not available","D")
						checknode = "Sec_unavail"
				else:
					checknode = "true"
			else:
				checknode = "Pri_unavail"
		else:

			checknode = "SW-HW cap not matching"
		logger.log(1,"Checknode return value:"+str(checknode),"I")
		resultarray.append(checknode)
		resultarray.append(noofunlocked)
		resultarray.append(nooflocked)
		return resultarray


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for which User has not provided Test Bed & Device for execution		#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_NothingSelected(self, queueRecord=None):
		
		try:
			self.lock.acquire()
			logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Lock Locking","I")
			#Create Instance for Queue DB Interface
			

			osName=None

			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()

			
			logger.log(1,queueRecord[11],"I")

			#List of Nodes which have all SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithAllSWCap=[]

			#List of Nodes which have few SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithFewSWCap=[]

			nodeWithFewHWCap = []
			nodeWithAllHWCap=[]
			nodeWithAllCap = []
			nodeWithPri=[]
			nodeWithSec=[]
			unlockedSecDevices = 0
			seclockedcount = 0
			expectedDevicecount = 0
			matchedSecDeviceCounter = 0
			product = ""
			os_version= ""
			role_id = 0
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()

#######################################################################################################################################################

			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			if allNodes==None:
				
				logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Negative Response from Device Farm","D")
				return False
			
			logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: SW Capabilities of All Online Nodes: ","I")
			nodeOnline = False
			nodeOffline = False
			email_status = "Not Sent"
			email_reason = "None"
			matchedSecDeviceCounter = 0
			foundAllHWCapNode = False
			foundReqSec = False
			devavail = False
			nodeavail = "false"
			lockeddev = 0
			dictRecord=self.convertToDictionary(queueRecord, osName)
			logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Email from dictrecord: "+dictRecord['email_status'],"I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			nodestobechecked = []
			nodewithlocked = []
			OnlineSecDevices = 0
			lockResultsec= False
			lockResult = False
			unLockResultsec= False
			unLockResult = False

			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					if node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[QueueProcessor_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(queueRecord[14])>1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
									nodewithlocked.append(node)
							else:
									continue
				if len(nodestobechecked)==0:
					if len(nodewithlocked)==0:
						logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","I")
						
			else:
				logger.log(1,"Prionodes="+str(prionodes),"I")
				if prionodes!= None:
						x = len(prionodes)
				else:
						x = 0

				logger.log(1,"Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(queueRecord[27]),"I")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						logger.log(1,"Node="+str(node),"I")
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[QueueProcessor_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							if node['locked']!='True' and  node['manualgit']!='True' and node['scheduledgit']!='IN_PROGRESS' and node['scheduledgit']!='INITIATED': 
								parallelnodestatus = (node['parallelexec']).lower()
								if parallelnodestatus=='false':
									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									testbed_in_progress=self.testRun.checkInprogress_on_testbed(node['friendlyname'])
									self.testRun.close()
									systemlocked='false'
									if  node['systemlock']=='true' or  testbed_in_progress:
										nodewithlocked.append(node)
								
									else:
										nodestobechecked.append(node)
										devavail = True
									
								else:
									nodestobechecked.append(node)
									devavail = True
							else:
								nodewithlocked.append(node)
						elif nodeavail[0]!= "SW-HW cap not matching":
								lockeddev = nodeavail[2]
								if int(queueRecord[14])>1:
									OnlineSecDevices= self.getSecondaryDevicecount(node)
								if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
									nodewithlocked.append(node)
								else:
									continue
					if devavail!= True:
							if commonnodes!= None:
									y = len(commonnodes)
							else:
									y = 0
							if y != 0:
								for j in commonnodes:
										node= self.devfarmconvertToDictionary(j)
										swCap=node.get('softwares').split(',')
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
										hwCap = node.get('hardwares').split(',')
										nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
										if nodeavail[0] == "true":
											nodestobechecked.append(node)
											logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
											devavail = True
										else:
											lockeddev = nodeavail[2]
											if lockeddev >= 1:
												nodewithlocked.append(node)
											else:
												pass
								logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
								if len(nodestobechecked)== 0:

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										logger.log(1,"testbeds available for execution in locked testbeds. The job will remain in queue","I")
										


									else:


											logger.log(1,"No node available required for execution.Send mail to admin","I")
											
							else:
									if len(nodestobechecked)== 0:
										if len(nodewithlocked) != 0:
											logger.log(1,"Locked devices are available.Jobs will remain in queue","I")
										else:
											logger.log(1,"No node available required for execution.Send mail to admin","I")
											


				else:
					
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","D")
					if commonnodes!= None:
								y = len(commonnodes)
					else:
								y = 0
					logger.log(1,"Length of Commonnodes="+str(y),"I")
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								
								logger.log(1,"[QueueProcessor_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
								hwCap = node.get('hardwares').split(',')
								logger.log(1,"External hwcap:"+str(hwCap),"I")
								nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
								logger.log(1,"Node avail="+str(nodeavail[0]),"I")
								if nodeavail[0] == "true":
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
									devavail = True


								if devavail != True and nodeavail[0]!= "SW-HW cap not matching":
									lockeddev = nodeavail[2]
									if int(queueRecord[14])>1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
										nodewithlocked.append(node)
									else:
										pass
						if len(nodestobechecked)== 0:

							logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
							if len(nodewithlocked) != 0:
								logger.log(1,"testbeds available for execution in locked testbeds. The job will remain in queue","D")
								



					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
						


			if len(nodestobechecked)== 0:
				if len(nodewithlocked) != 0:
					logger.log(1,"testbeds available for execution in locked testbeds. The job will remain in queue","D")
				else:
					for node in allNodes.get('nodes'):
							lockflagHw = 'false'
							#Check only Online Nodes
							
							logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Is it Online: "+str(node.get('nodeonlinestatus')),"I")
							if node.get('nodeonlinestatus')=='online'and node.get('nodejenkinsonlinestatus')=='online':
									nodeOnline = True
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Node: "+str(node.get('friendlyname')),"I")
									parrallelnodestatus=(node.get('parallelexec')).lower()
									systemlocked='false'
									if parrallelnodestatus=='false' and node.get('systemlock')=='true':
										systemlocked='true'
									if node.get('locked')!='True' and node.get('manualgit')!='True' and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
											swCap=node.get('softwares').split(',')
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: SW Capabilities: "+str(swCap),"I")
											hwCap = node.get('hardwares').split(',')
											logger.log(1,"External hwcap:"+str(hwCap),"D")
											lockflagHw = 'false'
											#Logic to Handle SW Capabilities
											result=self.findSWCap(queueRecord[11].split(','), swCap)
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Result of SwCap: "+str(result),"I")
											hwresult=self.findHWCap(queueRecord[12].split(','), hwCap)
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Result of HwCap: "+str(hwresult),"I")
											noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
											noofunlocked = self.checkunlockeddevices(queueRecord[3],queueRecord[4], node['friendlyname'],queueRecord)
											logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
											if int(queueRecord[14]) >1:
													noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
													if noofavailsecdev >= int(queueRecord[14])-1:
														nodeWithSec.append(node)
														secresult = True
													else:
														secresult = False
											else:
												secresult = True
											if secresult == True:
												nodeWithSec.append(node)

												if result==0 and hwresult!= 0:
													#Put Node in nodeWithFewSWCap
													
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
													nodeWithFewHWCap.append(node)
													nodeWithAllSWCap.append(node)
												elif result!=0 and hwresult== 0:
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
													nodeWithFewSWCap.append(node)
													nodeWithAllHWCap.append(node)
												elif result!=0 and hwresult!= 0:
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
													nodeWithFewSWCap.append(node)
													nodeWithFewHWCap.append(node)
												elif result == 0 and hwresult==0:
													#Put Node in nodeWithAllSWCap
													
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
													
													nodeWithAllHWCap.append(node)
													nodeWithAllSWCap.append(node)
													if noofunlocked[0] >= 1:
														priavail= True
													else:
														priavail = False
													if priavail == True:
															nodeWithPri.append(node)


													else:
														logger.log(1,"No primary devices available","D")

														
											else:
												logger.log(1,"Sufficient secondary dev not available","D")
									else:
											logger.log(1,"[QueueProcessor_startProcess_TestBedSelected] Test Bed is locked,manual git is on","D")



							else:
									nodeOffline = False
									nodeOnline = nodeOnline | nodeOffline
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Node has gone offline","I")

#######################################################################################################################################################

					logger.log(1,"Nodes with sec:"+str(nodeWithSec),"I")
					logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
					logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
					logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
					if len(nodeWithSec)== 0 and nodeOnline ==True:
							message= "Dear admin,\n\n There is no testbed with required number of secondary devices available for execution for the scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue. \n Number of support devices required:"+str(queueRecord[14]-1)
							self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
							

					else:

							if len(nodeWithAllSWCap)==0  and nodeOnline ==True:

								message= "Dear admin,\n\n No node has software capability required for execution of job:"+str(queueRecord[10])+"\n Required software capability:"+str(queueRecord[11])
								self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
								

								logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")


							elif len(nodeWithAllHWCap)==0 and nodeOnline==True:
									message= "Dear admin,\n\n No node has hardware capability required for execution of job:"+str(queueRecord[10])+"\n Required hardware capability:"+str(queueRecord[12])
									self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")

									pass
							elif len(nodeWithPri)== 0 and nodeOnline ==True:
								productresult = self.checkproduct(queueRecord)
								logger.log(1,"Primary device not available"+str(productresult),"I")
								message= "Dear admin,\n\n There is no testbed with primary devices available for execution for the testsuite:"+str(queueRecord[10])+ " for scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue.Primary device required:\n Product:"+str(queueRecord[3])+"\n OS:"+str(queueRecord[4])+"\n "+str(productresult)
								self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
								

					if nodeOnline!=True:
							logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: All nodes are offline; Let the Test Job in Queue","D")
							logger.log(1,"Email status="+str(email_status),"I")
							logger.log(1,"Email reason="+str(email_reason),"I")

							message = "Dear user,\n\n All nodes have gone offline.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
							print message

							self.Queue_email(self.subject['ALL_Node_offline'],message,str(queueRecord[10]),str(queueRecord[21]))

							logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: All nodes are offline. Send EMAIL notification to Device Farm Admin","I")


			if len(nodestobechecked)!=0:
				logger.log(1,"Node with all HW and software cap:"+str(nodestobechecked),"D")

				count = 0
				
				logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Found Node with all SW and HW Capabilities; Process Test Job for Scheduling (Continue with next step)","I")
				filteredNodes=[]

				lockflag = False
				locksecflag = False
				#Get all Online Devices from Selected Nodes from above step
				for node in nodestobechecked:

						logger.log(1,"Queue record hw:"+str(queueRecord[12].split(",")),"I")
						logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
						lockflagHw =self.inUseHardware_nothingSelected(node.get('friendlyname'),queueRecord[12].split(","))
						if lockflagHw!= 'true':
							parrallelnodestatus=(node.get('parallelexec')).lower()
							systemlocked='false'
							if parrallelnodestatus=='false' and node.get('systemlock')=='true':
								systemlocked='true'
							if node.get('locked')!='True' and node.get('manualgit')!='True' and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								#Unlocked Devices Counter
								foundAllHWCapNode=True
								unlockedDevices=0
								unlockedSecDevices=0
								inUseDevices=0
								inUseSecDevices=0
								

								onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
								
								logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Online Devices for this Node: ","I")
								
								foundAllHWCapDevice=False
								foundFewHWCapDevice=False
								deviceOSMatch= False
								lockedflag = False
								countOfDevices=len(onlineDevices.get('devices'))
								#Maintain Device Info for Scheduling purpose
								deviceList=[]
								secdeviceList=[]
								seclistjob = []
								deviceCounter=0
								matchedSecDeviceCounter=0
								unlockedSecDevices = 0
								if int(queueRecord[14])>1:
									matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
									unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
								seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)
								for device in onlineDevices.get('devices'):
									deviceCounter=deviceCounter+1
									
									logger.log(1, "[QueueProcessor_startProcess_NothingSelected]: Online Device Count for this Node: "+str(deviceCounter),"I")
									
									logger.log(1,device,"I")
									if device.get('status')=='online' and device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
									#Get Product & OS Information for all selected Online Devices from above step &
									#Select only those Devices, which have matching Product &
									#OS info mentioned in record['product'] & record['os']
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Matching Product & OS","I")
										
										logger.log(1,device.get('name')+queueRecord[3],"I")
										
										modeFlag=None
										if str(queueRecord[15])=="Manual":
											osFlag=False
											for osIter in queueRecord[4].split(","):
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected] OS: "+str(osIter.strip(" '")),"I")
												logger.log(1,(str(device.get('version')).split("-"))[1],"I")
												if (str(device.get('version')).split("-"))[1] == str(osIter.strip(" '")):
													
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected] OS Version Matched: "+str(osIter.strip(" '")),"D")
													osFlag=True
													osName=osIter.strip(" '")
													break

											
											result1=self.checkfordevice(queueRecord,device)
											if result1 and osFlag:
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: It is Manual Mode","D")
												
												logger.log(1,str(str(device.get('version')).split("-")[1])+":"+str(queueRecord[4]),"I")
												modeFlag=True
												deviceOSMatch = True
												product = device.get('name')
												os_version = str(str(device.get('version')).split("-")[1])

										elif str(queueRecord[15])=="Auto":
											logger.log(1,str(str(device.get('version')).split("-")[1])+":"+str(queueRecord[4]),"D")
											result1=self.checkfordevice(queueRecord,device)
											if result1 and str(str(device.get('version')).split("-")[1]) == str(queueRecord[4]):
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: It is Auto Mode","D")
												
												logger.log(1,str(device.get('version')).split("-")[1]+":"+ str(queueRecord[4].strip(" ")),"I")
												product = device.get('name')
												os_version = str(str(device.get('version')).split("-")[1])
												modeFlag=True

										if modeFlag==True:
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Device Product, OS Matched","D")
											deviceOSMatch = True
											#Get Devices which has all HW Capabilities mentioned in 								#record ['hw_cap']
											#If there is no Device found in any Node, then send EMAIL to Device
											#Farm Admin; Else Continue next Step
											
											if device.get('secondary')=='false':
													
													deviceList.append(device)
													product = device.get('name')
													os_version = str(str(device.get('version')).split("-")[1])
													foundAllHWCapDevice=True

													unlockedDevices=unlockedDevices+1
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Device is not secondary device"+str(unlockedDevices),"I")


										else:
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Device Product, OS not Matched","D")
											deviceOSMatch = False
									elif device.get('locked')=='true' or device.get('flash_status')=='true' :
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Device is Locked; So put Device in Locked Devices List","D")
										if device.get('secondary')=='false':
											inUseDevices=inUseDevices+1
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (1) In Use Devices for Node: "+ str(inUseDevices),"I")
											lockflag = True

										foundAllHWCapNode=True
										foundAllHWCapDevice=True

										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (1) In Use Devices for Node: "+ str(inUseDevices),"I")
			#######################################################################################################################################################

								
								logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (2) In Use Devices for Node: "+str(inUseDevices),"I")
								totalSupportDeviceCount = int(queueRecord[14])
								logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
								if totalSupportDeviceCount <= 1:
									expectedDevicecount = 0
								else:
									expectedDevicecount = totalSupportDeviceCount -1



								logger.log(1,"Expected device count:"+str(expectedDevicecount),"I")
								logger.log(1,"Matched sec device count:"+str(matchedSecDeviceCounter),"I")
								if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Unlocked Devices: "+str(unlockedDevices),"I")
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Required Devices for Test Execution: "+ str(queueRecord[14]),"I")
									#Check testRecord['support_device_count'] info & verify whether Node has sufficient
									#device count for execution

									foundReqSec = foundReqSec|True
									logger.log(1,"found required number of support devices","I")

									logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")

									logger.log(1,"[QueueProcessor_startProcess_NothingSelected] locked Secondary Device count: "+ str(seclockedcount),"I")
									secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
									if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):

										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Add Node to filteredNodes; & Continue Processing of Node","D")
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (3) In Use Devices for Node: "+ str(inUseDevices),"I")
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected] In Use Support Devices for Node: "+str(seclockedcount),"I")
										filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicableDevices':unlockedDevices, 'devices':deviceList, 'support_devices': secdeviceList, 'inUseDevices':inUseDevices,'inUseSecDevices':seclockedcount})
									else:
										#Reject Node
										pass

								elif foundAllHWCapDevice==True and (unlockedSecDevices< expectedDevicecount) and seclockedcount!= 0:

										logger.log(1,"[QueueProcessor_startProcess_NothingSelected] No unlocked Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")

										foundReqSec = foundReqSec|True
										logger.log(1,"found required number of support devices in locked devices","I")

								elif foundAllHWCapDevice==True and (unlockedSecDevices< expectedDevicecount) and seclockedcount== 0:
										logger.log(1, "[QueueProcessor_startProcess_NothingSelected] No Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")

										logger.log(1,"Found req support:"+str(foundReqSec),"I")
										foundReqSec = foundReqSec|False
										logger.log(1,"Found req support:"+str(foundReqSec),"I")
										

								else:
									#Reject Node
									
									if lockflag != True:
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: No Devices Found from this Node which has All HW Capabilities","D")
										foundReqSec = foundReqSec|True
							else:
								logger.log(1,"Manual git is true. Check next node","D")
						else:
								logger.log(1,"HW in use for node. Check next node","D")
								count= count +1
								continue
	#######################################################################################################################################################
				logger.log(1,"Count of nodes with HW in use"+str(count),"I")
				if count == len(nodestobechecked):
					logger.log(1,"All external HW in use. Let job remain in Queue","I")



				#If Node found, which has all HW Capabilities
				if foundAllHWCapNode==True:
					#Process Node further
					#If no Node has sufficient Unlocked Devices for execution, then put Test Job in Queue


					if len(filteredNodes)==0:
						#Put Test Job in Queue
						
						logger.log(1,"Required number of support devices status:"+str(foundReqSec),"D")
						if foundReqSec == False and expectedDevicecount != 0:

							message = "Dear user,\n\n No node has sufficient number of support devices .Testsuite:"+str(queueRecord[10])+" will remain in queue. \n Expected number of support devices:"+str(expectedDevicecount)+"\n\n"
							print message
							logger.log(1,"Message:"+str(message),"I")
							self.Queue_email(self.subject['No_sufficient_supportdevice'],message,str(queueRecord[10]),str(queueRecord[21]))

						else:
							logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: No Node has sufficient Unlocked Devices for execution; SO let the Test Job in  Queue","D")
						
						pass
					else:
						
						logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (4) In Use Devices for Node: "+str(inUseDevices),"D")
						#Process Node further
						
						logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Filterred Node: ","I")
						foundParallel=False
						logger.log(1,"Product ="+str(product),"I")
						logger.log(1,"OS version="+str(os_version),"I")
						for node in filteredNodes:
							parallelnodestatus = (node.get('node').get('parallelexec')).lower()
							print "Parallel execution status=",parallelnodestatus
							logger.log(1,"Parallel execution status="+parallelnodestatus,"I")
							
							logger.log(1,node,"I")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							QUERY='SELECT script_file,creation_timestamp,sw_cap,hw_cap,support_device_count,priority,mode,build_number,build_xml_location,location,test_bed_name,devices,pilot_tested,scrum_name,user FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" ORDER BY priority;'
							NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
							result = self.checknewrecord(NewQueueRecord,node.get('node'), node.get('support_devices'))
							QUERY1 = 'SELECT * FROM TBL_TEST_QUEUE where script_file ="'+result[0]+ '" and creation_timestamp ="'+result[1]+'"'
							queueRecord=self.testQueue.execute(QUERY1, "SELECT")
							queueRecord = queueRecord[0]
							logger.log(1,"QueueRecord="+str(queueRecord),"I")
							self.testQueue.close()

#######################################################################################################################################################
							if parallelnodestatus =='true':
								
								logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Node is Parallel Execution Capable; So Remove Record from Manual Job Queue, Create Jenkins Job for this Test Job & Trigger it on Test Bed|||||||||||||||||||||||||","D")
								#Create Jenkins Job for this Test Job & Trigger it on Test Bed
								if str(queueRecord[15])=="Manual":
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Trigger Test Job on Device","D")
									
									#Create Jenkins Job for this Test Job &
									#Trigger it on Test Bed
									#Create Test Job & Trigger it
									#Create testCase.xml file for Test Job Execution
									setUp=JobPreSetup.SetUp()
									dictRecord=self.convertToDictionary(queueRecord, osName)
									preSetUP=setUp.doPreSetUp(dictRecord)
									if preSetUP[0]==True:
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: TestCases.xml file created","D")
										#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
										job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'), node.get('support_devices'),preSetUP[1])
										#If Test Job Started; then only remove its corresponding Test Record from Queue
										#jobStatus=job.startProcess()
										#if jobStatus[0]:
										if True:
											

											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job Started Successfully","D")
											
											
											
											

											#Lock the Devices
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Locking Devices before Starting Test Job","I")
											
											if node.get('devices')!= None:
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Locking Device: "+node.get('devices')[0].get('serialno'),"D")
												
												lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
												lockflag = True
												
												logger.log(1,lockResult,"I")
												if queueRecord[19]!='NA':
													flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
													logger.log(1,flashresult,"D")
													if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
														

														logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Successfully Set flash status as true","D")
												else:
													flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=node.get('devices')[0].get('serialno'))
													logger.log(1,flashresult,"D")

											if expectedDevicecount >=1:
												if len(node.get('support_devices'))!= 0:
													logger.log(1,"Secondary device list:"+str(node.get('support_devices')),"D")
													i = 0
													while i < expectedDevicecount:
														logger.log(1,"Secondary device list:"+str(node.get('support_devices')),"D")
														seclistjob.append(node.get('support_devices')[i].get('serialno'))
														
														lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResultsec,"I")
														i= i+1
														if lockResultsec!= False:
															locksecflag = True
														else:
															locksecflag = True

											else:
												lockResultsec = True

											#Add Test Bed & Device Data to Test Record (For Auto Mode)
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Putting Test Bed & Device Details: ","I")
											
											logger.log(1,node.get('node').get('location'),"I")
											
											logger.log(1,node.get('node').get('friendlyname'),"I")
											
											logger.log(1,node.get('devices')[0].get('serialno'),"I")
											logger.log(1,str(",".join(seclistjob)),"I")
											dictRecord['location']=node.get('node').get('location')
											dictRecord['test_bed_name']=node.get('node').get('friendlyname')
											dictRecord['devices']=node.get('devices')[0].get('serialno')

											dictRecord['support_devices']=",".join(seclistjob)

											if lockResultsec != False and lockResult != False:
												jobStatus=job.startProcess()
												if jobStatus[0]:
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removing Test Record from Manual Jobs Queue","D")
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])

													if self.testQueue.removeFromQueue(queueRecord):
													
														logger.log(1,"Removed Test Job from Manual Jobs Queue","D")
												
													self.testQueue.close()
													if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
													
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job put into Running List","D")
													break


												else:
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","I")
											
													logger.log(1, "[QueueProcessor_startProcess_NothingSelected]: UnLocking Devices after failure in Starting Test Job","I")
											else:
												logger.log(1,"Error in locking device. Job will not be removed from queue","D")
												#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
												logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
										else:
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","I")
											
											logger.log(1, "[QueueProcessor_startProcess_NothingSelected]: UnLocking Devices after failure in Starting Test Job","I")
											


								elif str(queueRecord[15])=="Auto":
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Trigger Test Job on Device","D")

									setUp=JobPreSetup.SetUp()
									dictRecord=self.convertToDictionary(queueRecord, osName)
									preSetUP=setUp.doPreSetUp(dictRecord)
									if preSetUP[0]==True:
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: TestCases.xml file created","D")
										#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
										job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
										#If Test Job Started; then only remove its corresponding Test Record from Queue
										#jobStatus=job.startProcess()
										#if jobStatus[0]:
										if True:
											

											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job Started Successfully","D")
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job Name: ","I")
											
											#logger.log(1,jobStatus[1],"I")

											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Locking Devices before Starting Test Job","I")
											if len(node.get('devices'))!= 0:
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Locking Devices before Starting Test Job","D")

												
												lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
												
												logger.log(1,lockResult,"I")

												flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

												if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
													

													logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Successfully Set flash status as true","D")

											if expectedDevicecount >=1:
												if len(node.get('support_devices'))!= 0:
													logger.log(1,"Sec Device List:"+str(node.get('support_devices')),"D")
													i = 0
													while i < expectedDevicecount:
														seclistjob.append(node.get('support_devices')[i].get('serialno'))

														
														lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														i= i+1

														locksecflag = True
											else:
												lockResultsec= True
												
											#Add Test Bed & Device Data to Test Record (For Auto Mode)
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Putting Test Bed & Device Details: ","D")
											
											logger.log(1,node.get('node').get('location'),"I")
											
											logger.log(1,node.get('node').get('friendlyname'),"I")
											
											logger.log(1,node.get('devices')[0].get('serialno'),"I")
											dictRecord['location']=node.get('node').get('location')
											dictRecord['test_bed_name']=node.get('node').get('friendlyname')
											dictRecord['devices']=node.get('devices')[0].get('serialno')
											dictRecord['support_devices']=",".join(seclistjob)
											if lockResultsec != False and lockResult != False:




												jobStatus=job.startProcess()

												if jobStatus[0]:					
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removing Test Record from Auto Jobs Queue","D")
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													if self.testQueue.removeFromQueue(queueRecord):
													
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removed Test Job from Auto Jobs Queue","D")
												
													self.testQueue.close()
													if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
													
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job put into Running List","D")
													break
												else:
											
													logger.log(1, "[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")



											else:
												logger.log(1,"Error in locking the device. Job will remain in queue","I")
												#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
												logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
										else:
											
											logger.log(1, "[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: UnLocking Devices after failure in Starting Test Job","I")
											

#######################################################################################################################################################
							else:
								
								logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Node is not Parallel Execution Capable","D")
								#Check whether there is any already ongoing execution on Test Bed
								#If no Ongoing execution then Schedule test Job
								#& trigger it on Test Bed
								#Else put Test Job in Queue

								
								if node.get('inUseDevices')==0:
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: (5) In Use Devices for Node: "+str(node.get('inUseDevices')),"D")
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","I")
									#Create Jenkins Job for this Test Job &
									#Trigger it on Test Bed
									
									if str(queueRecord[15])=="Manual":
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Trigger Test Job on Device","D")
										
										#Create Jenkins Job for this Test Job &
										#Trigger it on Test Bed
										#Create Test Job & Trigger it

										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										logger.log(1,"osName="+osName,"I")
										print "Queue Record:"
										print queueRecord
										dictRecord=self.convertToDictionary(queueRecord, osName)
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
											#If Test Job Started; then only remove its corresponding Test Record from Queue
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:

												

												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Locking Devices before Starting Test Job","I")
												if node.get('devices')!= None:
															
															logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Locking Devices before Starting Test Job","I")
															
															lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															
															logger.log(1,lockResult,"I")

															if queueRecord[19]!='NA':
																flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
																logger.log(1,flashresult,"I")
																if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																	

																	logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Successfully Set flash status as true","D")

															else:
																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=node.get('devices')[0].get('serialno'))
																logger.log(1,flashresult,"I")

															lockflag = True
												if expectedDevicecount>=1:
													if len(node.get('support_devices'))!= 0:
															logger.log(1,"Sec Device List:"+str(node.get('support_devices')),"D")
															i = 0
															while i < expectedDevicecount:
																seclistjob.append(node.get('support_devices')[i].get('serialno'))

																
																lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																i= i+1
																locksecflag = True
												else:
													lockResultsec = True
												#Add Test Bed & Device Data to Test Record (For Auto Mode)
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Putting Test Bed & Device Details: ","I")
													
												logger.log(1,node.get('node').get('location'),"I")
												
												logger.log(1,node.get('node').get('friendlyname'),"I")
												
												logger.log(1,node.get('devices')[0].get('serialno'),"I")
												dictRecord['location']=node.get('node').get('location')
												dictRecord['test_bed_name']=node.get('node').get('friendlyname')
												dictRecord['devices']=node.get('devices')[0].get('serialno')
												dictRecord['support_devices']=",".join(seclistjob)
												if lockResult!=False and lockResultsec != False:
													jobStatus=job.startProcess()
													if jobStatus[0]:

														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removing Test Record from Manual Jobs Queue","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														if self.testQueue.removeFromQueue(queueRecord):
														
															logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removed Test Job from Manual Jobs Queue","D")
													
														self.testQueue.close()

														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
														
															logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job put into Running List","D")
														break

													else:
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: UnLocking Devices after failure in Starting Test Job","I")
														break
												else:
													#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
													logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				




											else:
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: UnLocking Devices after failure in Starting Test Job","I")
												
									elif str(queueRecord[15])=="Auto":
										
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Trigger Test Job on Device","D")
										
										#Create Jenkins Job for this Test Job &
										#Trigger it on Test Bed
										#Create Test Job & Trigger it
										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										dictRecord=self.convertToDictionary(queueRecord, osName)
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'), node.get('support_devices'),preSetUP[1])
											#If Test Job Started; then only remove its corresponding Test Record from Queue
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:


												
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Locking Devices before Starting Test Job","I")
												if len(node.get('devices'))!= 0:
												
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Locking Devices before Starting Test Job","D")

													
													lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
													
													logger.log(1,lockResult,"I")

													
													logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Successfully Locked Device","D")
													lockflag = True

												flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

												if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
													

													logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Successfully Set flash status as true","D")
												if expectedDevicecount>=1:
													if len(node.get('support_devices'))!= 0:
														logger.log(1,"Sec Device List:"+str(node.get('support_devices')),"D")
														i = 0
														while i < expectedDevicecount:
															seclistjob.append(node.get('support_devices')[i].get('serialno'))

															#lockResult=self.lockDevices(node.get('support_devices')[i].get('serialno'))
															lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															i= i+1
														locksecflag = True

												else:
													lockResultsec= True
													#record['support_devices']=str(seclistjob)

												if lockResult!=False and lockResultsec != False:
													jobStatus=job.startProcess()
													
													if jobStatus[0]:
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Removing Test Record from Auto Jobs Queue","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])

														if self.testQueue.removeFromQueue(queueRecord):
														
															logger.log(1,"Removed Test Job from Auto Jobs Queue","D")
													
														self.testQueue.close()

														#Add Test Bed & Device Data to Test Record (For Auto Mode)
													
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Putting Test Bed & Device Details: ","I")
													
														logger.log(1,node.get('node').get('location'),"I")
													
														logger.log(1,node.get('node').get('friendlyname'),"I")
													
														logger.log(1,node.get('devices')[0].get('serialno'),"I")
														dictRecord['location']=node.get('node').get('location')
														dictRecord['test_bed_name']=node.get('node').get('friendlyname')
														dictRecord['devices']=node.get('devices')[0].get('serialno')
														dictRecord['support_devices']=",".join(seclistjob)
														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
													
															logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test Job put into Running List","D")
														break
													else:
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												else:
													logger.log(1,"Error in locking the device. Job will remain in queue","I")
													#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
													logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
											else:
												
												logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												

											pass
#######################################################################################################################################################
								else:
									#Let the Test Job in Queue
									
									logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Test bed found, but there is already execution ongoing & it is not parallel execution capable; So Let the Test Job in Queue","D")
									pass
						pass



	#######################################################################################################################################################
				else:
					#Send EMAIL Notification to Device Farm Admin
					
					if lockflag != True and lockflagHw!= 'true':

						message= "Dear admin,\n\nFor script file:"+queueRecord[10]+"\nExpected hardware capabilities:"+str(queueRecord[12])+"\nExpected product:"+str(queueRecord[3])+"\nExpected OS version:"+str(queueRecord[4])+"\n\n"
						self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
						logger.log(1,"No Node found with matching HW Capabilities; Send EMAIL Notification to Device Farm Admin","I")

					else:
						pass
						#if self.testQueue.execute(QUERY, "UPDATE")==1:
							#self.testQueue.commit()

					pass

#######################################################################################################################################################

				#self.testQueue.close()
#######################################################################################################################################################

		except Exception, e:
			
			logger.log(1,"[QueueProcessor_startProcess_NothingSelected]:EXCEPTION"+str(e),"E")
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.testQueue.close()
			return False

		finally:
			#elf.testRun.close()
			#ogger.log(1,"[Queue Processor] startProcess_NothingSelected testRun Db connection closed","I");

			self.lock.release()
			logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Lock Releasing","I")

#######################################################################################################################################################

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Exceute Error 1002 job on another device		#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_Error_handler(self, queueRecord=None):
		
		try:
			self.lock.acquire()
			logger.log(1,"[QueueProcessor_startProcess_Error_handler] Lock Locking","I")
			#Create Instance for Queue DB Interface
			

			osName=None


			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()

			
			logger.log(1,queueRecord[11],"I")

			#List of Nodes which have all SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithAllSWCap=[]

			#List of Nodes which have few SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithFewSWCap=[]
			nodeWithFewHWCap = []
			nodeWithAllCap = []
			nodeWithAllSWCap=[]
			nodeWithAllHWCap=[]
			nodestobechecked = []
			nodewithlocked = []
			nodeWithPri=[]
			nodeWithSec=[]
			product = ""
			os_version= ""
			OnlineSecDevices = 0
			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()

#######################################################################################################################################################

			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			if allNodes==None:
				
				logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Negative Response from Device Farm","D")
				return False
			
			logger.log(1,"[QueueProcessor_startProcess_Error_handler]: SW Capabilities of All Online Nodes: ","I")
			foundAll=False
			foundFew=False
			lockflag = False
			nodeOffline = False
			email_status = "Not Sent"
			email_reason = "None"
			foundAllHWCapNode=False
			matchedSecDeviceCounter = 0
			unlockedSecDevices = 0
			seclockedcount = 0
			nodeOnline = False
			devavail = False
			lockeddev = 0
			nodeavail = "false"
			lockResultsec= False
			lockResult = False
			unLockResultsec= False
			unLockResult = False
			dictRecord=self.convertToDictionary(queueRecord, osName)
			logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Email from dictrecord: "+dictRecord['email_status'],"D")
#######################################################################################################################################################

			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					if node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(queueRecord[14])>1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
									nodewithlocked.append(node)
							else:
									continue
				if len(nodestobechecked)==0:
					if len(nodewithlocked)==0:
						logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","I")
						
			else:
				
				if prionodes!= None:
						x = len(prionodes)
				else:
						x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(queueRecord[27]),"I")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[QueueProcessor_startProcess_Error_handler] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(queueRecord[14])>1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
									nodewithlocked.append(node)
							else:
									continue
					if devavail!= True:
							if len(commonnodes)!= 0:
								for j in commonnodes:
										node= self.devfarmconvertToDictionary(j)
										swCap=node.get('softwares').split(',')
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler] SW Capabilities: "+str(swCap),"I")
										hwCap = node.get('hardwares').split(',')
										nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
										if nodeavail[0] == "true":
											nodestobechecked.append(node)
											logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
											devavail = True
										elif nodeavail[0]!= "SW-HW cap not matching":
											lockeddev = nodeavail[2]
											if int(queueRecord[14]) > 1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
											if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
													nodewithlocked.append(node)
											else:
													continue
								if len(nodestobechecked)== 0:

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"I")
									if len(nodewithlocked) != 0:
										logger.log(1,"testbeds available for execution in locked testbeds . The job will remain in queue","I")
										


							else:

								if len(nodewithlocked)==0:
									logger.log(1,"No node available required for execution.Send mail to admin","I")
									

				else:
					
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
					y = len(commonnodes)
					logger.log(1,"Length of Commonnodes="+str(y),"I")
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								
								logger.log(1,"[QueueProcessor_startProcess_Error_handler] SW Capabilities: "+str(swCap),"I")
								hwCap = node.get('hardwares').split(',')
								logger.log(1,"External hwcap:"+str(hwCap),"D")
								nodeavail = self.checknode(queueRecord,swCap,hwCap,node)
								logger.log(1,"Node avail="+str(nodeavail[0]),"I")
								if nodeavail[0] == "true":
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
									devavail = True
								if devavail != True and nodeavail[0]!= "SW-HW cap not matching":
									lockeddev = nodeavail[2]
									if int(queueRecord[14])>1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									if lockeddev >= 1 and OnlineSecDevices >= int(queueRecord[14])-1:
											nodewithlocked.append(node)
									else:
											continue

						if len(nodestobechecked)== 0:

							logger.log(1,"Nodes with locked ="+str(nodewithlocked),"I")
							if len(nodewithlocked) != 0:
								logger.log(1,"Testbeds available for execution in locked testbeds. The job will remain in queue","I")
								
							else:


								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","I")
								

					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","I")
						

			gitStatus = False
			if len(nodestobechecked)== 0:
					if len(nodewithlocked) != 0:
							logger.log(1,"testbeds available for execution in locked testbeds . The job will remain in queue","I")
					else:
						for node in allNodes.get('nodes'):
								lockflagHw = 'false'
								#Check only Online Nodes
								
								logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Is it Online: "+str(node.get('nodeonlinestatus')),"D")
								if node.get('nodeonlinestatus')=='online' and node.get('nodejenkinsonlinestatus')=='online':
										nodeOnline = True
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Node: "+str(node.get('friendlyname')),"D")
										parrallelnodestatus=(node.get('parallelexec')).lower()
										systemlocked='false'
										if parrallelnodestatus=='false' and node.get('systemlock')=='true':
											systemlocked='true'
										if node.get('locked')!='True' and node.get('manualgit')!='True' and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
												swCap=node.get('softwares').split(',')
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: SW Capabilities: "+str(swCap),"D")
												hwCap = node.get('hardwares').split(',')
												logger.log(1,"External hwcap:"+str(hwCap),"D")
												lockflagHw = 'false'

												#Logic to Handle SW Capabilities
												result=self.findSWCap(queueRecord[11].split(','), swCap)
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Result of SwCap: "+str(result),"D")
												hwresult=self.findHWCap(queueRecord[12].split(','), hwCap)
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Result of HwCap: "+str(hwresult),"D")

												noofunlocked = self.checkunlockeddevices(queueRecord[3],queueRecord[4], node['friendlyname'],queueRecord)
												logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
												if int(queueRecord[14]) >1:
														noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
														if noofavailsecdev >= int(queueRecord[14])-1:
															nodeWithSec.append(node)
															secresult = True
														else:
															secresult = False
												else:
													secresult = True
												if secresult == True:
													nodeWithSec.append(node)
													if result==0 and hwresult!= 0:
														#Put Node in nodeWithFewSWCap
														
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
														nodeWithFewHWCap.append(node)
														nodeWithAllSWCap.append(node)
													elif result!=0 and hwresult== 0:
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
														nodeWithFewSWCap.append(node)
														nodeWithAllHWCap.append(node)
													elif result!=0 and hwresult!= 0:
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
														nodeWithFewSWCap.append(node)
														nodeWithFewHWCap.append(node)
													elif result == 0 and hwresult==0:
														#Put Node in nodeWithAllSWCap
														
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
														
														nodeWithAllHWCap.append(node)
														nodeWithAllSWCap.append(node)
														if noofunlocked[0] >= 1:
															priavail= True
														else:
															priavail = False
														if priavail == True:
																nodeWithPri.append(node)


														else:
															logger.log(1,"No primary devices available","I")

															
												else:
													logger.log(1,"Sufficient secondary dev not available","I")
										else:
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Manual git is in progress","D")
												gitStatus = True



								else:
										nodeOffline = False
										nodeOnline = nodeOnline | nodeOffline
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Node has gone offline","D")

#######################################################################################################################################################

						#Find Nodes which has all SW Capabilities mentioned in testRecord['sw_cap']
						#If all the Nodes do not have any of the SW Cap, then send EMAIL to Device Farm Admin; Else Continue next Step
						#If only Node found which has some of SW Cap mentioned in testRecord['sw_cap'], then put Job in Queue
						#If Node found which has all SW Capabilities mentioned in testRecord['sw_cap'], then Continue next Step

						if gitStatus!= True:
							logger.log(1,"Nodes with sec:"+str(nodeWithSec),"D")
							logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
							logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
							logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
							if len(nodeWithSec)== 0 and nodeOnline ==True:
									message= "Dear admin,\n\n There is no testbed with required number of secondary devices available for execution for the scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue. \n Number of support devices required:"+str(queueRecord[14]-1)
									self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
									
							else:

									if len(nodeWithAllSWCap)==0  and nodeOnline ==True:

										message= "Dear admin,\n\n No node has software capability required for execution of job:"+str(queueRecord[10])+"\n Required software capability:"+str(queueRecord[11])
										self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
										logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")


									elif len(nodeWithAllHWCap)==0 and nodeOnline==True:
											message= "Dear admin,\n\n No node has hardware capability required for execution of job:"+str(queueRecord[10])+"\n Required hardware capability:"+str(queueRecord[12])
											self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))
											logger.log(1,"[QueueProcessor_startProcess_NothingSelected]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")

											pass
									elif len(nodeWithPri)== 0 and nodeOnline ==True:
										productresult = self.checkproduct(queueRecord)
										logger.log(1,"Primary device not available"+str(productresult),"I")
										message= "Dear admin,\n\n There is no testbed with primary devices available for execution for the testsuite:"+str(queueRecord[10])+ " for scrumteam:"+str(queueRecord[27])+ "hence job "+str(queueRecord[10])+ " will remain in queue.Primary device required:\n Product:"+str(queueRecord[3])+"\n OS:"+str(queueRecord[4])+"\n "+str(productresult)
										self.Queue_email(self.subject['Matching_node_unavailable'],message,str(queueRecord[10]),str(queueRecord[21]))

							if nodeOnline!=True:
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: All nodes are offline; Let the Test Job in Queue","D")
									logger.log(1,"Email status="+str(email_status),"I")
									logger.log(1,"Email reason="+str(email_reason),"I")

									message = "Dear user,\n\n All nodes have gone offline.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected software capabilities:"+str(queueRecord[11]+'\n\n')
									print message

									self.Queue_email(self.subject['ALL_Node_offline'],message,str(queueRecord[10]),str(queueRecord[21]))
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: All nodes are offline. Send EMAIL notification to Device Farm Admin","I")

			if len(nodestobechecked)!=0:
					logger.log(1,"Node with all HW and software cap:"+str(nodestobechecked),"D")

					filteredNodes=[]
					#Get all Online Devices from Selected Nodes from above step
					for node in nodestobechecked:
						count = 0
						
						logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Found Node with all SW Capabilities; Process Test Job for Scheduling (Continue with next step)","I")

						deviceOSMatch = False
						lockedflag = False
						lockflagHw =self.inUseHardware_nothingSelected(node.get('friendlyname'),queueRecord[12].split(","))
						if lockflagHw!= 'true':
							parrallelnodestatus=(node.get('parallelexec')).lower()
							systemlocked='false'
							if parrallelnodestatus=='false' and node.get('systemlock')=='true':
								systemlocked='true'
							if node.get('locked')!='True' and node.get('manualgit')!='True'and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								#Unlocked Devices Counter
								foundAllHWCapNode=True
								unlockedDevices=0
								unlockedSecDevices=0
								inUseDevices=0
								inUseSecDevices=0
								
								onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))

								
								logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Online Devices for this Node: ","I")
								
								foundAllHWCapDevice=False
								foundFewHWCapDevice=False
								deviceOSMatch= False
								lockflag = False
								locksecflag = False
								countOfDevices=len(onlineDevices.get('devices'))
								#Maintain Device Info for Scheduling purpose
								deviceList=[]
								secdeviceList=[]
								seclistjob = []
								deviceCounter=0
								matchedSecDeviceCounter=0
								unlockedSecDevices = 0

								if int(queueRecord[14])>1:
									matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
									unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
								seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)

								for device in onlineDevices.get('devices'):
									deviceCounter=deviceCounter+1
									
									logger.log(1, "[QueueProcessor_startProcess_Error_handler]: Online Device Count for this Node: "+str(deviceCounter),"D")
									
									logger.log(1,device,"I")
									if device.get('status')=='online' and device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
									#Get Product & OS Information for all selected Online Devices from above step &
									#Select only those Devices, which have matching Product &
									#OS info mentioned in record['product'] & record['os']
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Matching Product & OS","I")
										
										logger.log(1,device.get('name')+queueRecord[3],"I")
										
										modeFlag=None
										if str(queueRecord[15])=="Manual":
											osFlag=False
											for osIter in queueRecord[4].split(","):
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler] OS: "+str(osIter.strip(" '")),"I")
												if str(str(device.get('version')).split("-")[1]) == str(osIter.strip(" '")):
													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler] OS Version Matched: "+str(osIter.strip(" '")),"D")
													osFlag=True
													osName=osIter.strip(" '")
													break

											
											result1=self.checkfordevice(queueRecord,device)
											if result1 and osFlag and device.get("serialno")!=queueRecord[18]:
												
												logger.log(1,str(str(device.get('version')).split("-")[1])+":"+str(queueRecord[4]),"I")
												deviceOSMatch= True
												modeFlag=True

										elif str(queueRecord[15])=="Auto":
											result1=self.checkfordevice(queueRecord,device)
											if result1 and str(str(device.get('version')).split("-")[1]) == str(queueRecord[4]) and device.get("serialno")!=queueRecord[18]:
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: It is Auto Mode","D")
												
												logger.log(1,str(str(device.get('version')).split("-")[1])+":"+str(queueRecord[4].strip(" ")),"I")
												deviceOSMatch = True
												modeFlag=True

										if modeFlag==True:
											
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Device Product, OS Matched","D")
											#Get Devices which has all HW Capabilities mentioned in 								#record ['hw_cap']
											#If there is no Device found in any Node, then send EMAIL to Device
											#Farm Admin; Else Continue next Step
																			
											if device.get('secondary')=='false':
													
													deviceList.append(device)
													product = device.get('name')
													os_version = str(str(device.get('version')).split("-")[1])
													foundAllHWCapDevice=True
													unlockedDevices=unlockedDevices+1


										else:
											if deviceOSMatch == False:
												logger.log(1,"Device and OS not matched","I")
									elif device.get('flash_status')=='true' or device.get('locked')=='true':
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Device is Locked; So put Device in Locked Devices List","D")
										if device.get('secondary')=='false':
											inUseDevices=inUseDevices+1
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: (1) In Use Devices for Node: "+ str(inUseDevices),"I")
											lockflag= True

										foundAllHWCapNode=True
										foundAllHWCapDevice=True

										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: (1) In Use Devices for Node: "+ str(inUseDevices),"I")
				#######################################################################################################################################################

								
								logger.log(1,"[QueueProcessor_startProcess_Error_handler]: (2) In Use Devices for Node: "+str(inUseDevices),"I")
								totalSupportDeviceCount = int(queueRecord[14])
								logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
								if totalSupportDeviceCount <= 1:
									expectedDevicecount = 0
								else:
									expectedDevicecount = totalSupportDeviceCount - 1



								if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
									
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Unlocked Devices: "+str(unlockedDevices),"D")
									
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Required Devices for Test Execution: "+ str(queueRecord[14]+1),"I")
									#Check testRecord['support_device_count'] info & verify whether Node has sufficient
									#device count for execution

									logger.log(1,"[QueueProcessor_startProcess_Error_handler] locked Secondary Device count: "+ str(seclockedcount),"D")
									secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)

									if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Add Node to filteredNodes; & Continue Processing of Node","D")
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler] In Use Primary Devices for Node: "+str(inUseDevices),"I")
										logger.log(1,"[QueueProcessor_startProcess_Error_handler] In Use Support Devices for Node: "+str(seclockedcount),"I")
										filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicableDevices':unlockedDevices, 'devices':deviceList, 'support_devices': secdeviceList, 'inUseDevices':inUseDevices,'inUseSecDevices':seclockedcount})
									else:
										#Reject Node
										pass


								elif foundAllHWCapDevice==True and (unlockedSecDevices< expectedDevicecount) and seclockedcount != 0:
										logger.log(1, "[QueueProcessor_startProcess_Error_handler] No unlocked Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")

								elif foundAllHWCapDevice==True and (unlockedSecDevices< expectedDevicecount) and seclockedcount == 0:
										logger.log(1, "[QueueProcessor_startProcess_Error_handler] No unlocked Secondary Devices Found from this Node which has All HW Capabilities; so let the Test Job in Queue","D")


										message = "Dear user,\n\n Requested node does not have sufficient number of support devices with matching HW capability.Testsuite:"+str(queueRecord[10])+" will remain in queue. \nExpected number of support devices:"+str(expectedDevicecount)+"\nExpected hardware capabilities:"+str(queueRecord[12])+"\nExpected product:"+str(queueRecord[3])+"\nExpected OS version:"+str(queueRecord[4])+"\n\n"

										logger.log(1,"Message:"+str(message),"D")
										print message

										self.Queue_email(self.subject['No_sufficient_supportdevice'],message,str(queueRecord[10]),str(queueRecord[21]))

								else:
									#Reject Node
									
									if lockflag != True:
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: No Devices Found from this Node which has All HW Capabilities","D")
							else:
								logger.log(1,"Manual git is true. Check next node","D")

						else:
							logger.log(1,"HW in use for node. Check next node","I")
							count= count +1
							continue
	#######################################################################################################################################################
					logger.log(1,"Count of nodes with HW in use"+str(count),"I")
					if count == len(nodestobechecked):
						logger.log(1,"All external HW in use. Put job in Queue","I")
						
						logger.log(1,"All exeternal hw in use. Job will remain in queue","I")


					#If Node found, which has all HW Capabilities
					if foundAllHWCapNode==True:
						#Process Node further
						#If no Node has sufficient Unlocked Devices for execution, then put Test Job in Queue
						if len(filteredNodes)==0:
							#Put Test Job in Queue
							
							logger.log(1,"[QueueProcessor_startProcess_Error_handler]: No Node has sufficient Unlocked Devices for execution; SO let the Test Job in  Queue","D")
							
							pass
						else:
							
							logger.log(1,"[QueueProcessor_startProcess_Error_handler]: (4) In Use Devices for Node: "+str(inUseDevices),"D")
							#Process Node further
							
							logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Filterred Node: ","I")
							foundParallel=False
							for node in filteredNodes:
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								QUERY='SELECT script_file,creation_timestamp,sw_cap,hw_cap,support_device_count,priority,mode,build_number,build_xml_location,location,test_bed_name,devices,pilot_tested,scrum_name,user FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" ORDER BY priority;'
								NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
								logger.log(1,"NewQueueRecord:"+str(NewQueueRecord),"I")
								result = self.checknewrecord(NewQueueRecord,node.get('node'), node.get('support_devices'))
								QUERY1 = 'SELECT * FROM TBL_TEST_QUEUE where script_file ="'+result[0]+ '" and creation_timestamp ="'+result[1]+'"'
								queueRecord=self.testQueue.execute(QUERY1, "SELECT")
								queueRecord = queueRecord[0]
								logger.log(1,"QueueRecord="+str(queueRecord),"I")
								self.testQueue.close()

								parallelnodestatus = (node.get('node').get('parallelexec')).lower()
								print "Parallel execution status=",parallelnodestatus
								logger.log(1,"Parallel execution status="+parallelnodestatus,"I")
								
								logger.log(1,node,"I")
	#######################################################################################################################################################
								if parallelnodestatus =='true':
									
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Node is Parallel Execution Capable; So Remove Record from Manual Job Queue, Create Jenkins Job for this Test Job & Trigger it on Test Bed|||||||||||||||||||||||||","D")
									#Create Jenkins Job for this Test Job & Trigger it on Test Bed
									if str(queueRecord[15])=="Manual":
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Trigger Test Job on Device","D")
										
										#Create Jenkins Job for this Test Job &
										#Trigger it on Test Bed
										#Create Test Job & Trigger it
										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										dictRecord=self.convertToDictionary(queueRecord, osName)
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'), node.get('support_devices'),preSetUP[1])
											#If Test Job Started; then only remove its corresponding Test Record from Queue
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:
												

												

												#Lock the Devices
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Locking Devices before Starting Test Job","I")
												
												if len(node.get('devices'))!= 0:
														logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Locking Device: "+node.get('devices')[0].get('serialno'),"D")
														
														lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
														flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

														lockflag= True
														if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
															

															logger.log(1,"[QueueProcessor_startProcess_NothingSelected] Successfully Set flash status as true","D")
												if expectedDevicecount >=1:
													if len(node.get('support_devices'))!= 0:
														i = 0

														while i < expectedDevicecount:
															seclistjob.append(node.get('support_devices')[i].get('serialno'))
															

															lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															
															logger.log(1,lockResultsec,"I")

															i= i+1
														locksecflag = True
												else:
													lockResultsec = True

												if lockResult != False and lockResultsec != False:
													jobStatus=job.startProcess()
													if jobStatus[0]:
														logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Removing Test Record from Manual Jobs Queue","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														if self.testQueue.removeFromQueue(queueRecord):
														
															logger.log(1,"Removed Test Job from Manual Jobs Queue","D")
													
														self.testQueue.close()
														#Add Test Bed & Device Data to Test Record (For Auto Mode)
													
														logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Putting Test Bed & Device Details: ","I")
													
														logger.log(1,node.get('node').get('location'),"I")
													
														logger.log(1,node.get('node').get('friendlyname'),"I")
													
														logger.log(1,node.get('devices')[0].get('serialno'),"I")
														logger.log(1,str(",".join(seclistjob)),"I")
														dictRecord['location']=node.get('node').get('location')
														dictRecord['test_bed_name']=node.get('node').get('friendlyname')
														dictRecord['devices']=node.get('devices')[0].get('serialno')

														dictRecord['support_devices']=",".join(seclistjob)
														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Test Job put into Running List","D")
														break
													else:
														logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
														logger.log(1, "[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
														break
												else:

													logger.log(1,"error in locking device. Job will remain in queue","I")
													#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
													logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
											else:
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
												logger.log(1, "[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
												


									elif str(queueRecord[15])=="Auto":
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Trigger Test Job on Device","D")
										
										#Create Jenkins Job for this Test Job &
										#Trigger it on Test Bed
										#Create Test Job & Trigger it
										

										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										dictRecord=self.convertToDictionary(queueRecord, osName)
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
											#If Test Job Started; then only remove its corresponding Test Record from Queue
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:
												
									

												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Locking Devices before Starting Test Job","I")
												if len(node.get('devices'))!= 0:
													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler] Locking Devices before Starting Test Job","I")

													
													lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
													
													logger.log(1,lockResult,"I")
													lockflag = True



												flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

												if flashresult.get('flash_status')=='true' and 													flashresult.get('result')=='ok':
													
																							logger.log(1,"[QueueProcessor_startProcess_Error_handler] Successfully Set flash status as true","D")

												if expectedDevicecount>=1:
													if len(node.get('support_devices'))!= 0:
														logger.log(1,"Sec Device List:"+str(secdeviceList),"D")
														i = 0
														while i < expectedDevicecount:
															seclistjob.append(node.get('support_devices')[i].get('serialno'))

															
															lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															i= i+1
														locksecflag = False
												else:
													lockResultsec= True
													

												if lockResult != False and lockResultsec != False:
													jobStatus=job.startProcess()
													
													if jobStatus[0]:
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														if self.testQueue.removeFromQueue(queueRecord):
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Removed Test Job from Auto Jobs Queue","D")
													
														self.testQueue.close()
														#Add Test Bed & Device Data to Test Record (For Auto Mode)
													
														logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Putting Test Bed & Device Details: ","I")
														
														logger.log(1,node.get('node').get('location'),"I")
													
														logger.log(1,node.get('node').get('friendlyname'),"I")
													
														logger.log(1,node.get('devices')[0].get('serialno'),"I")
														dictRecord['location']=node.get('node').get('location')
														dictRecord['test_bed_name']=node.get('node').get('friendlyname')
														dictRecord['devices']=node.get('devices')[0].get('serialno')
														dictRecord['support_devices']=",".join(seclistjob)
														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Test Job put into Running List","D")
														break
													else:
														logger.log(1, "[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
														logger.log(1,"[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
														break
												else:
													logger.log(1,"Error in locking device. Job will remain in queue","I")
													#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
													logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				
													
											else:
												
												logger.log(1, "[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
												

	#######################################################################################################################################################
								else:
									
									logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Node is not Parallel Execution Capable","D")
									#Check whether there is any already ongoing execution on Test Bed
									#If no Ongoing execution then Schedule test Job
									#& trigger it on Test Bed
									#Else put Test Job in Queue

									
									if node.get('inUseDevices')==0:
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: (5) In Use Devices for Node: "+str(node.get('inUseDevices')),"D")
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","I")
										#Create Jenkins Job for this Test Job &
										#Trigger it on Test Bed
										
										if str(queueRecord[15])=="Manual":
											
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Trigger Test Job on Device","D")
											#Lock the Devices????????????????????????????????????????????????????
											

											#Create Jenkins Job for this Test Job &
											#Trigger it on Test Bed
											#Create Test Job & Trigger it

											#Create testCase.xml file for Test Job Execution
											setUp=JobPreSetup.SetUp()
											logger.log(1,"osName="+osName,"I")
											print "Queue Record:"
											print queueRecord
											dictRecord=self.convertToDictionary(queueRecord, osName)
											preSetUP=setUp.doPreSetUp(dictRecord)
											if preSetUP[0]==True:
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: TestCases.xml file created","D")
												#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
												job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
												#If Test Job Started; then only remove its corresponding Test Record from Queue
												#jobStatus=job.startProcess()
												#if jobStatus[0]:
												if True:

													
													
													if len(node.get('devices'))!= 0:
													
														logger.log(1,"[QueueProcessor_startProcess_Error_handler] Locking Devices before Starting Test Job","I")

														
														lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
														lockflag = True
														flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
													if expectedDevicecount >=1:
														if len(node.get('support_devices'))!= 0:
															logger.log(1,"Sec Device List:"+str(node.get('support_devices')),"D")
															i = 0
															while i < expectedDevicecount:
																seclistjob.append(node.get('support_devices')[i].get('serialno').get('serialno'))

																
																lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																i= i+1
															locksecflag = True
													else:
														lockResultsec = True


													if lockResult != False and lockResultsec != False:
														jobStatus=job.startProcess()
														if jobStatus[0]:
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Removing Test Record from Manual Jobs Queue","D")
															self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
															if self.testQueue.removeFromQueue(queueRecord):
															
																logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Removed Test Job from Manual Jobs Queue","D")
															self.testQueue.close()
															#Add Test Bed & Device Data to Test Record (For Auto Mode)
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Putting Test Bed & Device Details: ","I")
															
															logger.log(1,node.get('node').get('location'),"I")
														
															logger.log(1,node.get('node').get('friendlyname'),"I")
														
															logger.log(1,node.get('devices')[0].get('serialno'),"I")
															dictRecord['location']=node.get('node').get('location')
															dictRecord['test_bed_name']=node.get('node').get('friendlyname')
															dictRecord['devices']=node.get('devices')[0].get('serialno')
															dictRecord['support_devices']=",".join(seclistjob)
															if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
															
																logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Test Job put into Running List","D")
															break

														else:
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
													else:
														logger.log(1,"Error in locking device. Job will remain in queue","I")
														#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
														logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")				


												else:
													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler]: UnLocking Devices after failure in Starting Test Job","I")
													
													
										elif str(queueRecord[15])=="Auto":
											
											logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Trigger Test Job on Device","D")
											
											#Create Jenkins Job for this Test Job &
											#Trigger it on Test Bed
											#Create Test Job & Trigger it
											#Create testCase.xml file for Test Job Execution
											setUp=JobPreSetup.SetUp()
											dictRecord=self.convertToDictionary(queueRecord, osName)
											preSetUP=setUp.doPreSetUp(dictRecord)
											if preSetUP[0]==True:
												
												logger.log(1,"[QueueProcessor_startProcess_Error_handler]: TestCases.xml file created","D")
												#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
												job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'), node.get('support_devices'),preSetUP[1])
												#If Test Job Started; then only remove its corresponding Test Record from Queue
												#jobStatus=job.startProcess()
												#if jobStatus[0]:
												if True:
													

													
													

													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Locking Devices before Starting Test Job","I")
													if len(node.get('devices'))!= 0:
															
															logger.log(1,"[QueueProcessor_startProcess_Error_handler] Locking Devices before Starting Test Job","D")

															
															lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															
															logger.log(1,lockResult,"I")
															
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Successfully Locked Device","D")
															lockflag = True

															flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

															if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																

																logger.log(1,"[QueueProcessor_startProcess_Error_handler] Successfully Set flash status as true","D")
													if expectedDevicecount >= 1:
														if len(node.get('support_devices'))!= 0:
															i = 0
															logger.log(1,"Sec Device List:"+str(node.get('support_devices')),"D")
															while i < expectedDevicecount:
																seclistjob.append(node.get('support_devices')[i].get('serialno'))


																lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
																i= i+1
															locksecflag = True

													else:
														lockResultsec = True
													if lockResult != False and lockResultsec !=False:
														jobStatus=job.startProcess()
														if jobStatus[0]:
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Removing Test Record from Auto Jobs Queue","D")
															self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
															if self.testQueue.removeFromQueue(queueRecord):
															
																logger.log(1,"Removed Test Job from Auto Jobs Queue","D")
														
															self.testQueue.close()
															#Add Test Bed & Device Data to Test Record (For Auto Mode)
														
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Putting Test Bed & Device Details: ","I")
														
															logger.log(1,node.get('node').get('location'),"I")
														
															logger.log(1,node.get('node').get('friendlyname'),"I")
														
															logger.log(1,node.get('devices')[0].get('serialno'),"I")
															dictRecord['location']=node.get('node').get('location')
															dictRecord['test_bed_name']=node.get('node').get('friendlyname')
															dictRecord['devices']=node.get('devices')[0].get('serialno')
															dictRecord['support_devices']=",".join(seclistjob)
															if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
															
																logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Test Job put into Running List","D")
															break

														else:
															logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")		
															break	

													else:
														logger.log(1,"Error in locking device. Job will remian in queue kill job from jenkins","I")
																
														#job.removefromjenkins(str(jobStatus[1]),str(node.get('node').get('friendlyname')))
														logger.log(1,"Error in locking device. Job will remian in queue killed job from jenkins","I")

														
																						

												else:
													
													logger.log(1,"[QueueProcessor_startProcess_Error_handler]: There is error in creating & starting Test Job; So let the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													

												pass
#######################################################################################################################################################
									else:
										#Let the Test Job in Queue
										
										logger.log(1,"[QueueProcessor_startProcess_Error_handler]: Test bed found, but there is already execution ongoing & it is not parallel execution capable; So Let the Test Job in Queue","D")
										pass
						pass
#######################################################################################################################################################
					else:
						#Send EMAIL Notification to Device Farm Admin
						
						if lockflag != True and lockflagHw!= 'true':

							message= "Dear admin,\n\nFor script file:"+queueRecord[10]+"\nExpected hardware capabilities:"+str(queueRecord[12])+"\nExpected product:"+str(queueRecord[3])+"\nExpected OS version:"+str(queueRecord[4])+"\n\n"
							self.Queue_email(self.subject['No_HW_Cap'],message,str(queueRecord[10]),str(queueRecord[21]))
							logger.log(1,"[QueueProcessor_startProcess_Error_handler]: No Node found with matching HW Capabilities; Send EMAIL Notification to Device Farm Admin","I")


						pass
#######################################################################################################################################################

			#self.testQueue.close()
#######################################################################################################################################################

		except Exception, e:
			
			logger.log(1,"[QueueProcessor_startProcess_Error_handler]:EXCEPTION"+str(e),"E")
			return False

		finally:
			
			self.lock.release()
			logger.log(1,"[QueueProcessor_startProcess_Error_handler] test run db closed and Lock Releasing","I")
######################################################################################################################################

	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for Non mobile testing for which  which User has provided only Test Bed for#
        #	execution							   				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_SystemSelected(self, queueRecord=None):
		try:
			testRecord=queueRecord
			self.lock.acquire()
			logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Lock Locking","I")
			nodeWithAllSWCap =[]
			nodeWithFewSWCap = []
			nodeWithAllCap =[]
			lockflag='False'
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			jobtriggered=False
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])

			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
			foundincommonNode=False
			nodematchingallswcap='false'
			foundNode=False
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					if node.get('location')==queueRecord[16] and node.get('nodejenkinsonlinestatus')=='online':
						logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Location Matched","D")
						if node.get('friendlyname')==queueRecord[17]:
							if node.get('locked')!='True' and node.get('manualgit')!='True' and node.get('systemlock')!='true' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								swCap=node.get('softwares').split(',')
								result=self.findSWCap(queueRecord[11].split(','), swCap)
								logger.log(1,"[QueueProcessor_startProcess_SystemSelected]: Result of SwCap: "+str(result),"D")
								if result==0:
									#Put Node in nodeWithAllSWCap
									
									logger.log(1,"[QueueProcessor_startProcess_SystemSelected]: All Test Suite SW Capabilities Found in this Node","D")
									foundAll=True
									foundFew=False
									nodeWithAllSWCap.append(node)
									parallelnodestatus = node.get('parallelexec').lower()
									if parallelnodestatus=='true' and jobtriggered==False:
										#trigger job for non mobile testingand remove from queue
										self.systemjobtrigger(queueRecord,node)
										jobtriggered= True
										break
									elif parallelnodestatus=='false' and jobtriggered==False:
										self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
										self.testrun.close()
										if inprogressstatus:
											#job is running on this node so pass

											pass
										else:
											# trigger a job and remove from queue
											self.systemjobtrigger(queueRecord,node)
											jobtriggered= True
											break





								elif result==1:
									#Put Node in nodeWithFewSWCap
									
									logger.log(1,"[QueueProcessor_startProcess_SystemSelected]: Few Test Suite SW Capabilities Found in this Node","D")
									foundFew=True
									#nodeWithFewSWCap.append(node)
								elif result==2:
									foundAll=False
									foundFew=False
									

				if jobtriggered== False:
					message = "Dear user,\n\n Software capabilities not matching in requested testbed for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11])+'\n\n'
					print message

					self.Queue_email(self.subject['No_SW_Cap_reqnode'],message,str(queueRecord[10]),str(queueRecord[21]))
			else:
				logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Prionodes="+str(prionodes),"D")
				if prionodes!= None:
						x = len(prionodes)
				else:
						x = 0

				logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Testbeds have been allocated to the scrum team :"+str(testRecord[14]),"I")#testRecord[14]?
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						if node.get('friendlyname')== testRecord[17] and node.get('location')==testRecord[16]:
							foundNode = True
							nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
							logger.log(1,"Node avail="+str(node.get('friendlyname')),"I")




						if nodematchingallswcap== "true" and foundNode == True:
							nodeWithAllCap.append(node)
						elif nodematchingallswcap== "false" and foundNode == True:
							message = "Dear user,\n\n Software capabilities not matching in requested testbed for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11])+'\n\n'
							print message

							self.Queue_email(self.subject['No_SW_Cap_reqnode'],message,str(queueRecord[10]),str(queueRecord[21]))
							pass


				if x==0 or foundNode==False:
					for i in commonnodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						if node.get('friendlyname')== testRecord[17] and node.get('location')==testRecord[16]:
							foundincommonNode = True
							nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
							logger.log(1,"Node avail="+str(node.get('friendlyname')),"I")




						if nodematchingallswcap== "true" and foundincommonNode == True:
							nodeWithAllCap.append(node)
						elif nodematchingallswcap== "false" and foundincommonNode == True:
							message = "Dear user,\n\n Software capabilities not matching in requested testbed for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11])+'\n\n'
							print message

							self.Queue_email(self.subject['No_SW_Cap_reqnode'],message,str(queueRecord[10]),str(queueRecord[21]))
							pass
				if foundincommonNode==False and foundNode==False:
					logger.log(1,"[QueueProcessor_startProcess_SystemSelected] no Node is found","D")
					pass

				if len(nodeWithAllCap)!=0:
					
					logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Found Nodes with all SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
					for node in nodeWithAllCap:
						logger.log(1,"[QueueProcessor_startProcess_SystemSelected] node"+str(node),"D")
						logger.log(1,"[QueueProcessor_startProcess_SystemSelected] node"+str(node.get('systemlock')),"D")
						if node.get('systemlock')=='true':
							#let the job in queue if test bed is already locked by other job

							lockflag='True'
							break
						else:
							logger.log(1,"[QueueProcessor_startProcess_SystemSelected] Node with all SW capability:"+str(nodeWithAllCap),"D")
							if  lockflag!='True' and node.get('friendlyname')==testRecord[17] and len(nodeWithAllCap)!=0:
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									self.systemjobtrigger(testRecord,node)
									logger.log(1,"[QueueProcessor_startProcess_SystemSelected] job triggered with parrel; exec true ","D")
									pass
									#directly trigger a job on test bed and locked the test bed



								else:
									#parrallel exec is false check whther any job is running on the test bed
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										#job is running on the test bed so put job into queue with email notification

										logger.log(1,"[QueueProcessor_startProcess_SystemSelected] let the job into queue; exec false and job running on test bed: ","D")
									else:
										#no job is running trigger the job.
										self.systemjobtrigger(testRecord,node)
										logger.log(1,"[QueueProcessor_startProcess_SystemSelected] job triggered with parrel; exec false and no job running on test bed: ","D")
										pass








		except Exception, e:
			

			logger.log(1,"QueueProcessor_startProcess_SystemSelected"+str(e),"E")
		finally:
			
			
			self.lock.release()
			logger.log(1,"[QueueProcessor_startProcess_SystemSelected]: Lock Releasing","I")



#######################################################################################################################################

		#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for Non mobile testing for which  which User has provided only Test Bed for#
        #	execution							   				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# queueRecord	Tuple		Test Record								#
    	# mode		String		Mode of execution (Auto, Manual)					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_System_not_Selected(self, queueRecord=None):
		try:
			testRecord=queueRecord
			self.lock.acquire()
			logger.log(1,"[startProcess_System_not_Selected] Lock Locking","I")
			nodeWithAllSWCap =[]
			nodeWithFewSWCap = []
			nodeWithAllCap_prio=[]
			nodeWithAllCap=[]
			nodeWithAllCap_locked=[]
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			jobtriggered=False
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			user_name = str(queueRecord[20])

			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(queueRecord[27])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			if queueRecord[15]!= "Auto":
				role_id = self.ScrumDetails.getroleid(user_name)
			else:
				role_id = 2
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					if  node.get('nodejenkinsonlinestatus')=='online':
						logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Location Matched","D")

						if node.get('locked')!='True' and node.get('manualgit')!='True' and node.get('systemlock')!='true' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								swCap=node.get('softwares').split(',')
								result=self.findSWCap(queueRecord[11].split(','), swCap)
								logger.log(1,"[Queue_processor_startProcess_System_not_Selected]: Result of SwCap: "+str(result),"I")
								if result==0:
									#Put Node in nodeWithAllSWCap
									
									logger.log(1,"[QueueProcessor_startProcess_SystemSelected]: All Test Suite SW Capabilities Found in this Node","D")
									foundAll=True
									foundFew=False
									nodeWithAllSWCap.append(node)
									parallelnodestatus = node.get('parallelexec').lower()
									if parallelnodestatus=='true' and jobtriggered==False:
										#trigger job for non mobile testingand remove from queue
										self.systemjobtrigger(queueRecord,node)
										jobtriggered= True
										break
									elif parallelnodestatus=='false' and jobtriggered==False:
										self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
										self.testrun.close()
										if inprogressstatus:
											#job is running on this node so pass

											pass
										else:
											# trigger a job and remove from queue
											self.systemjobtrigger(queueRecord,node)
											jobtriggered= True
											break





								elif result==1:
									#Put Node in nodeWithFewSWCap
									
									logger.log(1,"[Queue_processor_startProcess_System_not_Selected]: Few Test Suite SW Capabilities Found in this Node","D")
									foundFew=True
									#nodeWithFewSWCap.append(node)
								elif result==2:
									foundAll=False
									foundFew=False


				if jobtriggered== False and len(nodeWithAllSWCap)==0:
					message = "Dear user,\n\n Software capabilities not matching in requested testbed for testsuite:"+str(queueRecord[10])+"\nExpected software capabilities:"+str(queueRecord[11])+'\n\n'
					print message

					self.Queue_email(self.subject['No_SW_Cap_reqnode'],message,str(queueRecord[10]),str(queueRecord[21]))



			else:

				if prionodes!= None:
					x = len(prionodes)
				else:
					x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Testbeds have been allocated to the scrum team :"+str(testRecord[14]),"D")#testRecord[14]?
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						nodematchingallswcap = self.checksystem(testRecord,swCap,node)
						if nodematchingallswcap== "true" :
							nodeWithAllCap_prio.append(node)

					if len(nodeWithAllCap_prio)==0:

						logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Not a single SW Capability found in any Node from prioriy nodes;","D")
					else:

						for node in nodeWithAllCap_prio:
							if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									#trigger the job and check whether test bed is locked or not
									if (str(node.get('systemlock')))!='true':
										self.systemjobtrigger(testRecord,node)
										jobtriggered = True
										break
									else:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))

								else:
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))

									else:
										#trigger the job and check whether test bed is locked or not
										if (str(node.get('systemlock')))!='true':
											self.systemjobtrigger(testRecord,node)
											jobtriggered= True
											break
										else:
											nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							else:
								logger.log(1,"[Queue_processor_startProcess_System_not_Selected]: Node has active manual git ","D")


				if x==0 or jobtriggered==False:
					for i in commonnodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						nodematchingallswcap = self.checksystem(testRecord,swCap,node)
						if nodematchingallswcap== "true" :
							nodeWithAllCap.append(node)

					if len(nodeWithAllCap) ==0 and len(nodeWithAllCap_prio)==0:

						logger.log(1,"[Queue_processor_startProcess_System_not_Selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
					#send email notification
					elif len(nodeWithAllCap)!=0 and jobtriggered==False:
						for node in nodeWithAllCap:
							if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									#trigger the job and check whether test bed is locked or not
									if (str(node.get('systemlock')))!='true':
										self.systemjobtrigger(testRecord,node)
										jobtriggered = True
										break
									else:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))

								else:
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))

									else:
										#trigger the job and check whether test bed is locked or not
										if (str(node.get('systemlock')))!='true':
											self.systemjobtrigger(testRecord,node)
											jobtriggered= True
											break
										else:
											nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							else:
								logger.log(1,"[Queue_processor_startProcess_System_not_Selected]: Node has active manual git ","D")


				if len(nodeWithAllCap_locked)!=0 and jobtriggered==False:

					logger.log(1,"[Queue_processor_startProcess_System_not_Selected]:Nodes are locked put job into queue ","D")
				elif (len(nodeWithAllCap_prio)!=0 or len(nodeWithAllSWCap)!=0) and jobtriggered==False:

					logger.log(1,"[Queue_processor_startProcess_System_not_Selected]:Nodes are locked due to git put job into queue ","D")



		except Exception, e:
			
			logger.log(1,"[Queue_processor_startProcess_System_not_Selected]"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[Queue_processor_startProcess_System_not_Selected]: Lock Releasing","I")



######################################################################################################################################
#################################################################################################################
	# SYNOPSIS:													#
    	# Trigger job for execution of non mobile testing           #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details									#
	#################################################################################################################
    	# OUTPUT DATA:													#
	# True	Positive return
	# False	 Negative return
    	#################################################################################################################	

	def systemjobtrigger(self,queueRecord,node):
		try:
			osName=None
			testRecord=queueRecord
			logger.log(1,"[QueueProcessor_systemjobtrigger] ","I")
			dictRecord=self.convertToDictionary(testRecord,osName)
			print dictRecord,"deict record"
			nodename=str(testRecord[17])
			print nodename
			logger.log(1,"[QueueProcessor_systemjobtrigger] nodename "+str(nodename),"I")
			logger.log(1,"[QueueProcessor_systemjobtrigger] dictRecord "+str(dictRecord),"I")
			setUp=JobPreSetup.SetUp()
			
			preSetUP=setUp.doPreSetUp(dictRecord)
			logger.log(1,"[QueueProcessor_systemjobtrigger] preSetUP "+str(preSetUP),"I")
			print preSetUP
			if preSetUP[0]==True:
				
				logger.log(1,"[QueueProcessor_systemjobtrigger] TestCases.xml file created","D")
				#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
				logger.log(1,"[QueueProcessor_systemjobtrigger] input top start job dictrecord"+str(dictRecord),"I")
				logger.log(1,"[QueueProcessor_systemjobtrigger] input top start job node"+str(node),"I")
				logger.log(1,"[QueueProcessor_systemjobtrigger] input top start preSetUP[1]"+str(preSetUP[1]),"I")
				job=StartSystemJob.systemjob(dictRecord, node, preSetUP[1])
				#If Test Job Started; then only remove its corresponding Test Record from Queue
				jobStatus=job.startProcess()
				logger.log(1,"[QueueProcessor_systemjobtrigger] jobStatus"+str(jobStatus),"I")
				if jobStatus[0]:
					
					logger.log(1,"[QueueProcessor_systemjobtrigger] System Test Job has been successfully started","D")
					
					logger.log(1,jobStatus[1],"I")
					self.devicefarm=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
					self.devicefarm.updatesystemlock(str(node.get('friendlyname')),status="true")
					self.devicefarm.close()
					#lock the test bed
					logger.log(1,   "[QueueProcessor_systemjobtrigger] Assign location and test bed "+str(dictRecord)+str(type(dictRecord)),"D")
					dictRecord['location']=node.get('location')
					dictRecord['test_bed_name']=node.get('friendlyname')
					dictRecord['support_devices']='NA'
					self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
					scrum_teamname= str(dictRecord['scrum_name'])
					user_name = str(dictRecord['user'])
					logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
					if str(scrum_teamname) == "NA":
						priority = self.ScrumDetails.getPriority("System Test", "manual")
					else:
						scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
						if scrumpriotablecheck == 1:
							priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
							if priority == None:
								priority = self.ScrumDetails.getPriority("System Test", "manual")
						else:
							priority = self.ScrumDetails.getPriority("System Test", "manual")
							logger.log(1,"Priority of job="+str(priority),"I")
					dictRecord['priority'] = int(priority)

					self.ScrumDetails.close()






					if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
						
						logger.log(1,   "[QueueProcessor_systemjobtrigger] Test Job put into Running List","D")
					self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
					if self.testQueue.removeFromQueue(testRecord):
						
						logger.log(1,"Removed Test Job from Auto Jobs Queue","D")
						
					self.testQueue.close()
			return True


		except Exception, e:
		
			logger.log(1,"QueueProcessor_systemjobtrigger Exception"+str(e),"E")
			return False

#################################################################################################################
	# SYNOPSIS:													#
    	# Check system capabilities for execution of non mobile testing  job         #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details	
	# swcap 	List		Software capabilities expected								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True	Positive return
	# False	 Negative return 														#
    	#################################################################################################################

	def checksystem(self, record,swcap,node={}):
		try:
			logger.log(1,"Inside checksystem","I")
			result=self.findSWCap(record[11].split(','), swcap)
			if result == 0:
				checknode = "true"
				logger.log(1,"QueueProcessor_Inside checksystem,sw cap matching for node"+str(node['friendlyname']),"I")
			else:
				checknode = "false"
				logger.log(1,"QueueProcessor_Inside checksystem,sw cap not matching for node"+str(node['friendlyname']),"I")
			return checknode

		except Exception, e:
			
			checknode = "false"
			logger.log(1,"QueueProcessor_checksystem Exception"+str(e),"E")
			return checknode
#################################################################################################################
	# SYNOPSIS:													#
    	# Check device capabilities       #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	Dictionary	Test Record
	# device 	Dictionary	Device details	
	# osFlag 	Boolean		status of device os-matching(true), not matching(false) 								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True 	Positive return
	# False	Negative return														#
    	#################################################################################################################	
	def checkfordevice(self,queueRecord,device):
		try:
			osName=None
			record=self.convertToDictionary(queueRecord, osName)
			result=False
			if record.get('wantechnology')=='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"QueueProcessor:check for device ,all are any","I")
				if  device.get('name')==record.get('product') :
					logger.log(1,"Manual_matchfinder:check for device ,all are any,matched","D")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"QueueProcessor:check for device ,scan engine not  any","D")
				if  device.get('name')==record.get('product')  and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"QueueProcessor:check for device ,scan engine not  any,matched","D")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"QueueProcessor:check for device ,hardrev not  any","D")
				if  device.get('name')==record.get('product')  and device.get('revversion')==record.get('hardwarerev'):
					logger.log(1,"QueueProcessor:check for device ,hardrev not  any,matched","D")
					result=True
				else:
					result=False

			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"QueueProcessor:check for device ,wantechnology not  any","D")
				if  device.get('name')==record.get('product')  and device.get('wantechnology')==record.get('wantechnology'):
					logger.log(1,"QueueProcessor:check for device ,wantechnology not  any,matched","D")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"QueueProcessor:check for device ,wantechnology  any","D")
				if  device.get('name')==record.get('product')  and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"QueueProcessor:check for device ,wantechnology  any,matched","D")
					result=True
				else:
					result=False

			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"QueueProcessor:check for device ,hardwarerev  any","D")
				if  device.get('name')==record.get('product')  and device.get('wantechnology')==record.get('wantechnology') and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"QueueProcessor:check for device ,hardwarerev  any,matched","D")
					result=True
				else:
					result=False
			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"QueueProcessor:check for device ,hardwarerev  any","D")
				if  device.get('name')==record.get('product')  and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine'):
					result=True
				else:
					result=False
			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"QueueProcessor:check for device ,no  any","D")
				if  device.get('name')==record.get('product') and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine') and device.get('wantechnology')==record.get('wantechnology'):
					logger.log(1,"QueueProcessor:check for device ,no  any,matched","D")
					result=True
				else:
					result=False

			else:
					result=False
			logger.log(1,"QueueProcessor:check for device ,result"+str(result),"I")
			return result


		except Exception, e:
			

			logger.log(1,"QueueProcessor_QueueProcessor:check for device Exception"+str(e),"E")
			return None







#####################################################################################################################################################
json_data.close()
#########################################################################################################
# SYNOPSIS:												#
# Starting point of execution for Module								#
#########################################################################################################
if __name__=='__main__':
	m=Process()
	#m.checkQueueTable()
	m.checkQueue_unlockeddevices()
	#m.startProcess()
