##########################################################################################################
# Name Of File: ManualMatchFinder.py                                                                     #
# Author: Vinayak Wagh                                                                                   #
# Purpose Of File: Provide Functional Interface to find Matching Test Beds & Devices in Manual Mode      #
##########################################################################################################
# History:                                                                                               #
# Date                   Author                  Changes                                                 #
# 19/03/2016             Vinayak Wagh            Initial Creation                                        #
##########################################################################################################
import DeviceFarmInfo,time
import sys,json,os
from lockfile import LockFile

with open(os.environ['PYTHONPATH'].split(":")[0]+'/config.json')as json_data:
		Config = json.load(json_data)

sys.path.insert(0, (Config['CONFIG_PATH']+"/code/db"))

import DB_Interface, unicodedata
sys.path.insert(0, (Config['CONFIG_PATH']+"/code/jenkins_job"))

import StartJob, JobPreSetup
import LogDictUtility
import CLMEmailNotification
import datetime
import urllib
import urllib2
import StartSystemJob
from datetime import datetime
logger=LogDictUtility.LogGenerate()


#########################################################################################################
# SYNOPSIS:												#
# 1. Get Test Data from User in Manual Mode, to find Matching Test Bed & Devices			#
# 2. If Match not found then, put Test Data in Queue							#
#########################################################################################################
class ManualMatch():
	global logger
	#########################################################################################################
	# SYNOPSIS:												#
    	# Empty Constructor											#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA	
	# Initialisation Function												#
    	#########################################################################################################
	def __init__(self):
		self.lock=LockFile(Config['CONFIG_PATH']+"/lockfiles/lock.txt")
		self.email = CLMEmailNotification.EmailNotification()
		self.subject = Config['E-mail_Subject']
		self.testRun = None
		self.testQueue = None
		
		self.deviceFarm = None
		
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# 1. Insert Test Record into Running Test Record's Table along with JobName				#
    	# 2. Put flash_status & test_status for corresponding JobName						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dictRecord	Dictionary	Test Record to put into Running Test Jobs Table				#
    	# jobName	String		Test Record's corresponding Job Name					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def insertIntoRunningJob(self, dictRecord, jobName):

		
		try:	
			record={}
			record=dictRecord
			
			record['job_name']=jobName
			logger.log(1,"[ManualMatchFinder_insertinto Table] "+str(jobName),"D")
			
			if record.get('build_xml_location')!='NA' and record.get('device_required')=='true':
				record['flash_status']="IN_PROGRESS"
				record['test_status']="NOT_STARTED"				
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				record['starting_timestamp']=str(starting_timestamp)
				logger.log(1,"[ManualMatchFinder_insertinto Table:flash_status:starting_timestamp] "+str(starting_timestamp),"D")
			elif record.get('build_xml_location')=='NA':
				record['flash_status']="NO_FLASH"
				record['test_status']="IN_PROGRESS"
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				record['starting_timestamp']=str(starting_timestamp)
				logger.log(1,"[ManualMatchFinder_insertinto Table:test_status:starting_timestamp] "+str(starting_timestamp),"D")
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])				
			self.testRun.insert(record)
			
			self.testRun.close()
			logger.log(1,"[ManualMatchFinder_insertinto Table:insertrecord] ","D")
			return True
		except Exception, e:
			
			self.testRun.close()
                        
			logger.log(1,"[ManualMatchFinder_insertinto Table:insertrecord] EXCEPTION"+str(e),"E")
			return False

		

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match SW Capabilties of Test Bed with Test Jobs SW Capabilities					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsSW		List		Test Record's SW Capabilities		 				#
    	# nodeSW	List		Test Bed's SW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################
	def findSWCap(self, tsSW, nodeSW):
		count=len(tsSW)
		finalCount=0
		logger.log(1,"tssw cap"+str(tsSW),"I")
		for i in tsSW:
			
			for j in nodeSW:
				logger.log(1,"i"+str(i.strip(' ')),"I")
				
				if i.strip(' ')==j.encode('ascii', 'ignore'):
					finalCount=finalCount+1
					
					break

		logger.log(1,"finalcount:"+str(finalCount),"I")
		logger.log(1,"count:"+str(count),"I")
		if finalCount==count and finalCount!=0 and count!=0:
			return 0
		elif finalCount<count and finalCount!=0:
			return 1
		elif finalCount==0:
			return 2

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match HW Capabilties of Device with Test Jobs HW Capabilities						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsHw		List		Test Record's HW Capabilities		 				#
    	# nodehwCap	List		Test Bed's HW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################
	def findHWCap(self, tsHw, nodehwCap):
		try:
			hwCapCount=len(tsHw)
			counter=0
			logger.log(1,"tshw cap"+str(tsHw),"I")
			
			logger.log(1,"[ManualMatchFinder_findHWCap] External HW Dependencies Matching","I")
			if tsHw[0] =='NA': ####Check what happens when hw cap is empty 
				logger.log(1,"Test job requires no external hardware","D")
				return 0
			if len(tsHw)!= 0:
				logger.log(1,"Test job requires atleast 1 external hardware","D")
				for i in tsHw:
					
					if len(nodehwCap)!= 0:
						logger.log(1,"Node has atleast 1 external hardware capacity","D")
						for j in nodehwCap:
							logger.log(1,"i"+str(i.strip(' ')),"I")
							
							if i.strip(' ')==j.encode('ascii', 'ignore'):
								counter=counter+1
								
								break
					else:
						logger.log(1,"Node does not support atleast 1 external hardware capacity, but job requires it","D")
						return 2

				if counter==hwCapCount:
					
					logger.log(1,"[ManualMatchFinder_findHWCap] All HW Capabilities Matched","D")
					return 0
					
				
				elif counter< hwCapCount and counter!=0 :
					logger.log(1,"[ManualMatchFinder_findHWCap] Few HW Capabilities Matched","D")
					return 1
					

				elif counter==0:
					logger.log(1,"[ManualMatchFinder_findHWCap] No matching  HW Capabilities found","D")
					return 2

			else:
				logger.log(1,"Test job requires no external hardware","D")
				return 0
		except Exception, e:
			
			
			logger.log(1,"[ManualMatchFinder_findHWCap] EXCEPTION"+str(e),"E")
			return 2

#################################################################################################################################

	########################################################################################################
	# SYNOPSIS:												#
    	# Return the product details	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test record for the job	
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# returnstr		String	Details of product
												#
    	#########################################################################################################
	def checkproduct(self,testRecord):	

		try:
			logger.log(1,"Inside checkproduct function","I")
			logger.log(1,"TestRecord for product:"+str(testRecord),"I")	
			logger.log(1,"WanTechnology required for product:"+str(testRecord['wantechnology']),"I")
			logger.log(1,"Hardwarerev required for product:"+str(testRecord['hardwarerev']),"I")	
			logger.log(1,"Scan engine required for product:"+str(testRecord['scan_engine']),"I")
			returnstr = ""
			if str(testRecord['wantechnology'])!= "Any":
				returnstr= returnstr+ " WanTechnology required for product:"+str(testRecord['wantechnology'])+"\n"
			if str(testRecord['hardwarerev'])!= "Any":
				returnstr= returnstr+ " Hardwarerev required for product:"+str(testRecord['hardwarerev'])+"\n"
			if str(testRecord['scan_engine'])!= "Any":
				returnstr= returnstr+ " Scan engine required for product:"+str(testRecord['scan_engine'])+"\n"
			logger.log(1,"Return string="+str(returnstr),"I")
			return returnstr

		except:
			return "None"
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Convert devicefarm db data from tuple to dictionary format					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	Tuple		Tuple of devicefarm data					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	dictionary	Dictionary output for tuple input							#
    	#########################################################################################################
	def devfarmconvertToDictionary(self, tupleData):
		try:
			
			record={
				'nodename':tupleData[0], 
				'nodeip':tupleData[1], 
				'nodeos':tupleData[2], 
				'nodestatus':tupleData[3],
				'requestedby':tupleData[4],
				'requestcomments':tupleData[5],
				'softwares':tupleData[6],
				'friendlyname':tupleData[7],
				'location':tupleData[8],
				'parallelexec':tupleData[9],
				'macaddress':tupleData[10],
				'nodeonlinestatus':tupleData[11],
				'locked':tupleData[12],
				'nodejenkinsonlinestatus':tupleData[13],
				'hardwares':tupleData[14],
				'manualgit':tupleData[15],
				'scheduledgit':tupleData[16],
				'Branchname':tupleData[17],
				'manualgitstarttime':tupleData[18],
				'jobname':tupleData[19],
				'scrumteam':tupleData[20],
				'systemlock':tupleData[21]
				 	 }
			
			return record
		except Exception, e:
			
			logger.log(1,"devfarmconvertToDictionary:EXCEPTION:"+str(e),"E")
			return None



#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match Device Serial ID with Device ID required for Test Job						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceSerial	String		Device Serial number								#
    	# recordList	List		List of serial numbers to be compared to					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def matchDeviceSerialId(self, deviceSerial, recordList):
		try:
			logger.log(1,"[ManualMatchFinder_matchDeviceSerialId] Matching Serial Number","I")
			
			for serial in recordList:
				
				logger.log(1,str(deviceSerial.strip(" ,"))+str(serial.strip(" ,")),"D")
				if deviceSerial.strip(" ,")==serial.strip(" ,"):
					logger.log(1,"Returning True","I")
					return True
			return False
		except Exception, e:
			
                       
			logger.log(1,"[ManualMatchFinder_matchDeviceSerialId] EXCEPTION"+str(e),"E")
			return False

###############################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Lock device with Device serial number						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialnoString		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def lockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"ManualMatchFinder_Lock Function Server Side","D")
			logger.log(1,"[ManualMatchFinder_LockDevices Server Side] Locking Device: "+str(deviceserialno),"D")
			lockResult=self.deviceFarm.reserve_device(operation='reserve_device', serialno=str(deviceserialno))

			logger.log(1,lockResult,"I")
			if lockResult.get('reservationStatus')=='success' and lockResult.get('result')=='ok':
				
				logger.log(1,"[ManualMatchFinder_LockDevices Server Side] Successfully Locked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			
                       
			logger.log(1,"[ManualMatchFinder_LockDevices Server Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False

###############################################################################################################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to UnLocked on Server Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialno String		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	
	def unlockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"ManualMatchFinder_Unlock Function Server Side","D")
			logger.log(1,"[ManualMatchFinder_UnlockDevices Server Side] Unlocking Device: "+str(deviceserialno),"D")
			unlockResult=self.deviceFarm.release_device(operation='release_device', serialno= str(deviceserialno))
			
			if unlockResult.get('releaseStatus')=='success' and unlockResult.get('result')=='ok':
				
				logger.log(1,"[ManualMatchFinder_UnlockDevices Server Side] Successfully unlocked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			
				   
			logger.log(1,"[ManualMatchFinder_UnlockDevices Server Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False
				
###############################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Locked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	
	
	def lock_device(self, **dataparam):
		try:
			logger.log(1,"ManualMatchFinder_Lock Function Node Side","D")
			logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Locking Device: "+str(dataparam['serialno']),"D")
			logger.log(1,"Dataparam : "+str(dataparam),"D")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			
			
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data : "+str(json_data),"D")
			if json_data['result'] == 'ok':
				lockresult = self.lockDevices(dataparam['serialno'])
				logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"D")
				return lockresult
			else:
				logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Unsuccessful locking Device: "+str(dataparam['serialno']),"D")
				logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno']),"D")
				time.sleep(5)
				noofretry=0
				while noofretry!=3:
					noofretry=noofretry+1
					params = urllib.urlencode(dataparam)
			
					response = urllib2.urlopen(nodeServerUrl, params).read()
			
					json_data = json.loads(response)
					if json_data['result'] == 'ok':
						lockresult = self.lockDevices(dataparam['serialno'])
						logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"D")
						noofretry=3
						return lockresult
					else:
						logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno'])+"retrying attempt"+str(noofretry),"D")
						if noofretry==3:
							return False

					time.sleep(5)
		except Exception, e:
			
                       
			logger.log(1,"[ManualMatchFinder_LockDevices Node Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False
			
###############################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Unlocked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################


	def unlock_device(self, **dataparam):
		try:
			logger.log(1,"ManualMatchFinder_Unlock Function Node Side","D")
			logger.log(1,"[ManualMatchFinder_UnlockDevices Node Side] Unlocking Device: "+str(dataparam['serialno']),"D")
			logger.log(1,"Dataparam : "+str(dataparam),"D")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data: "+str(json_data),"D")
			if json_data['result'] == 'ok':
				unlockresult = self.unlockDevices(dataparam['serialno'])
				logger.log(1,"[ManualMatchFinder_UnlockDevices Node Side] Successfully Unlocked Device: "+str(dataparam['serialno']),"D")
				return unlockresult
			else:
				logger.log(1,"[ManualMatchFinder_UnlockDevices Node Side] Unsuccessful Unlocking Device: "+str(dataparam['serialno']),"D")
				return False
		except Exception, e:
			
                       
			logger.log(1,"[ManualMatchFinder_UnlockDevices Node Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False
			


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for which User has provided Test Bed & Device for execution in Manual Mode	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# record	Dictionary	Test Record								#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_TestBed_AND_DeviceSelected(self, record):
		
		
		try:
			
			
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Create Instance for Queue Database","I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			nodelockedstatus=self.deviceFarm.get_nodelocked_status(operation='get_nodelocked_status',name=record.get('test_bed_name'))

			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
			scrum_teamname= str(record.get('scrum_name'))
			user_name = str(record.get('user'))
			
			logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
			if str(scrum_teamname) == "NA":
				priority = self.ScrumDetails.getPriority("System Test", "manual")
			else:
				scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
				if scrumpriotablecheck == 1:
					priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
					if priority == None:
						priority = self.ScrumDetails.getPriority("System Test", "manual")
				else:
					priority = self.ScrumDetails.getPriority("System Test", "manual")
			logger.log(1,"Priority of job="+str(priority),"I")
			record['priority'] = int(priority)
			role_id = self.ScrumDetails.getroleid(user_name)
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()		
			
			prionodes= self.devicefarmdb.getprionodes(record['scrum_name'])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			nodestobechecked =[]
			nodewithlocked = []
			self.devicefarmdb.close()

			logger.log(1,"After creating db objects","D")
			
			self.manualgitcheck=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
			manualgitstatus=self.manualgitcheck.getmanualgitstatus(str(record.get('test_bed_name')))
			systemlocked=self.manualgitcheck.getsystemlockedinfo(str(record.get('test_bed_name')))
			gitpullstatus=self.manualgitcheck.getscheduledgitstatus(str(record.get('test_bed_name')))
			self.manualgitcheck.close()
			if gitpullstatus=='IN_PROGRESS' or nodelockedstatus['nodeStatus']['locked']=='True' or manualgitstatus=='True'or systemlocked=='true' or gitpullstatus=='INITIATED':
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				self.testQueue.insert(record)
				self.testQueue.close()
				if nodelockedstatus['nodeStatus']['locked']=='True' or manualgitstatus=='True':
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Git_Pull'],'Dear admin,\n\n Manual git is on , job has been put into queue for test bed-'+ str(record.get('test_bed_name'))+'\n\n',[])
				return
			logger.log(1,"After git check","D")

			##########################################################
			#Acquire file system lock
			#########################################################

			self.lock.acquire()
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Lock Locking","I")

		
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Create Instance for Device Farm Wrapper","I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()

			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]  Executing Script:"+record["script_file"],"I")
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]  Executing Script time:"+record["creation_timestamp"],"I")
			if record["build_xml_location"]!="NA":
				checkrecord=None
				self.buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record["build_number"]+"'"		
				pilottested= self.buildInfo.execute(Query, "SELECT")
				self.buildInfo.close()
		
				if pilottested[0]=="YES":
					pass

				else:
			
		        		self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		        		query1='SELECT * FROM TBL_RUNNING_TEST where build_xml_location="'+record["build_xml_location"]+'" AND mode="Manual" AND flash_status="IN_PROGRESS"'
		        		checkrecord=self.testRun.execute(query1,"SELECT");
			
		        		self.testRun.close()
		        		if checkrecord==None:
							pass
		        		else:
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)
							self.testQueue.close()
							logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Record  put in queue for pilot testing"+str(record),"D")
							self.lock.release()
							return
		
				

			
			
			PrimaryDeviceCount=1
			
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] OS Versions: "+str(record.get('os')),"I")

#######################################################################################################################################################

			
			logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Get Node Details from Device Farm Server","I")
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] All Nodes: ","I")
			#Variable initialisations
			flag=False
			email_status = 'Not Sent'
			email_reason = 'None'
			lockflagHw = 'false'
			seclistjob=[]
			nodeWithPri = []
			nodeWithSec = []
			countofSupportDevices = 0
			unlockedSecDevices = 0
			seclockedcount = 0
			expectedDevicecount = 0
			devavail = False
			foundnode = False
			matchedDeviceCounter=0
			matchedSecDeviceCounter = 0
			OnlineSecDevices=0
			lockResultsec = False
			lockResult = False
			inUseDevices=0
			logger.log(1,"Role id ="+str(role_id),"I")
			# For scrum master- all nodes are available
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					
					swCap=node.get('softwares').split(',')
					hwCap = node.get('hardwares').split(',')
					
					if str(node.get('friendlyname')) == str(record.get('test_bed_name')) and str(node.get('location')) == str(record.get('location')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						foundnode = True
						
						nodeavail = self.checknode(record,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							testJobDevices=[]
							if "," in record.get('devices'):
								testJobDevices=record.get('devices').split(",")
							else:
								testJobDevices.append(record.get('devices'))
						
							logger.log(1,"Test job devices:","D")
							logger.log(1,testJobDevices,"D")
							onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
							
							
							countOfDevices=len(onlineDevices.get('devices'))
							#Maintain Device Info for Scheduling purpose 
							deviceList=[]
							secdeviceList =[]
							supportDev = []
							if countOfDevices==0:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

							logger.log(1,"Online devices:"+str(onlineDevices),"I")
							for device in onlineDevices.get('devices'):
									logger.log(1,"Device="+str(device),"I")
									if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':
															

											if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
							
												nodestobechecked.append(node)
												devavail = True
											else:
												continue									
												
									elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
										
										if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
											nodewithlocked.append(node)
								

									else:
										continue
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(record['support_device_count']) >1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
							unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
							if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):



									nodewithlocked.append(node)
							
				if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:
										
										logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","D")
				
									if devavail!= True and foundnode== False:				
												logger.log(1,"Send mail since node not present","D")
			
			#For users other than scrum master; first priority nodes will be checked for availability, else common nodes would be checked #							
			else:				
				
				logger.log(1,"Prionodes="+str(prionodes),"D")
				if prionodes!= None:
					x = len(prionodes)
				else:
					x = 0
				logger.log(1,"Length Prionodes x="+str(x),"D")
				#Check for available priority nodes
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(record.get('scrum_name')),"D")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						
						swCap=node.get('softwares').split(',')
						hwCap = node.get('hardwares').split(',')
						
						if str(node.get('friendlyname')) == str(record.get('test_bed_name')) and str(node.get('location')) == str(record.get('location')):
							foundnode = True
						if foundnode == True:
							
							nodeavail = self.checknode(record,swCap,hwCap,node)
							logger.log(1,"Node avail="+str(nodeavail[0]),"D")
							if nodeavail[0] == "true":

								testJobDevices=[]
								if "," in record.get('devices'):
									testJobDevices=record.get('devices').split(",")
								else:
									testJobDevices.append(record.get('devices'))
							
								
								onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
								

						
								countOfDevices=len(onlineDevices.get('devices'))
								#Maintain Device Info for Scheduling purpose 
								deviceList=[]
								secdeviceList =[]
								supportDev = []
								if countOfDevices==0:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

								for device in onlineDevices.get('devices'):
										if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':
																

												if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
								
													nodestobechecked.append(node)
													devavail = True
												else:
																						
													continue

										elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
											
											if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
												nodewithlocked.append(node)

										else:
											continue
							elif nodeavail[0]!= "SW-HW cap not matching":
								lockeddev = nodeavail[2]
								if int(record['support_device_count']) >1:
									OnlineSecDevices= self.getSecondaryDevicecount(node)
								#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
								unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
										nodewithlocked.append(node)
								else:
										logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","D")
					#Check for common nodes					
					if devavail!= True and foundnode== False:
							if commonnodes!= None:
								y = len(commonnodes)
							else:
								y = 0
							if y != 0:
								for j in commonnodes:
										node= self.devfarmconvertToDictionary(j)
										
										swCap=node.get('softwares').split(',')
										hwCap = node.get('hardwares').split(',')
										if node.get('friendlyname') == record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
											foundnode = True
										if foundnode == True:

											nodeavail = self.checknode(record,swCap,hwCap,node)
											logger.log(1,"Node avail="+str(nodeavail[0]),"I")
											if nodeavail[0] == "true":

												testJobDevices=[]
												if "," in record.get('devices'):
													testJobDevices=record.get('devices').split(",")
												else:
													testJobDevices.append(record.get('devices'))
							
												onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
																				
												countOfDevices=len(onlineDevices.get('devices'))
												#Maintain Device Info for Scheduling purpose 
												
												if countOfDevices==0:
													
													logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

												for device in onlineDevices.get('devices'):
														if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':
																

																if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
								
																	nodestobechecked.append(node)
																	devavail = True
																else:
																	continue					
																	
														elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
	
															if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
																nodewithlocked.append(node)
													
														else:
															logger.log(1,"Send mail since node doesnt have devices required","D")
														
															continue
											elif nodeavail[0]!= "SW-HW cap not matching":
												lockeddev = nodeavail[2]
												if int(record['support_device_count']) >1:
													OnlineSecDevices= self.getSecondaryDevicecount(node)
												#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
												unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
												if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
														nodewithlocked.append(node)
												else:
														logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","D")
														
								if foundnode == False:
									logger.log(1,"Send mail since node not present","D")
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n  "Dear admin,\n\n Requested node not available for execution for job:'+str(record['script_file'])+'\n\n',[])
								else:
									if len(nodestobechecked)== 0:
										if len(nodewithlocked) != 0:
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											self.testQueue.insert(record)
											self.testQueue.close()
										else:
											logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
									
								
									
							else:
									logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								
					#If both priority nodes and common nodes not available
					else:
						if len(nodestobechecked)== 0:
									#If nodes are avaialble with locked devices; put job in queue
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:
										logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
									
							
								
				# If scrum team has no nodes assigned to it	
				else:
					logger.log(1,"Commonnodes="+str(commonnodes),"D")
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
					if commonnodes!= None:
								y = len(commonnodes)
					else:
								y = 0					
					
					# Check for avaiable common nodes
					if y!= 0:
							for j in commonnodes:
									node= self.devfarmconvertToDictionary(j)
									
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									if node.get('friendlyname') == record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
										foundnode = True
									if foundnode == True:

										nodeavail = self.checknode(record,swCap,hwCap,node)
										logger.log(1,"Node avail="+str(nodeavail[0]),"I")
										if nodeavail[0] == "true":

											testJobDevices=[]
											if "," in record.get('devices'):
												testJobDevices=record.get('devices').split(",")
											else:
												testJobDevices.append(record.get('devices'))
						
											onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
											
							
											countOfDevices=len(onlineDevices.get('devices'))
											#Maintain Device Info for Scheduling purpose 
											
											if countOfDevices==0:
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

											for device in onlineDevices.get('devices'):
													if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':
															

															if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
							
																nodestobechecked.append(node)
																logger.log(1,"Nodes to be checked:"+str(nodestobechecked),"I")
																devavail = True
															else:
																					
																continue

													elif device.get('status')=='online' and device.get('locked')=='true' and device.get('secondary')=='false':
														
														if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
															nodewithlocked.append(node)
													else:
														logger.log(1,"Send mail since node doesnt have devices required","D")
														
														continue
										elif nodeavail[0]!= "SW-HW cap not matching":
											lockeddev = nodeavail[2]
											if int(record['support_device_count'])>1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
											#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1: 
											unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
											if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
													nodewithlocked.append(node)
											else:
													logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","D")
					

							if foundnode == False:
								logger.log(1,"Send mail since node not present","D")
					
								
							else:
								if len(nodestobechecked)== 0:
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:
										logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
									
							
								
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
					
						
			logger.log(1,"Nodes to be checked:"+str(nodestobechecked),"I")		
			# If no matching nodes are available for execution, send mail with reason
			if len(nodestobechecked)== 0:	
				if len(nodewithlocked) == 0:	
					for node in allNodes.get('nodes'):
						
						matchedDeviceCounter=0
						matchedSecDeviceCounter = 0
						inUseDevices=0
						
						logger.log(1,node,"I")
						if node.get('location')==record.get('location') and str(node.get('friendlyname')) == str(record.get('test_bed_name')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
							
							logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Location Matched","D")
							if node.get('friendlyname')==record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
							
								noofunlocked = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
								if int(record['support_device_count']) >1:	
										noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
										if noofavailsecdev >= int(record['support_device_count'])-1: 
											nodeWithSec.append(node)
											secresult = True
										else:
											secresult = False
								else:
									secresult = True
								if secresult == True:
									nodeWithSec.append(node)
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									logger.log(1,"External hwcap:"+str(hwCap),"D")
									parallelnodestatus = node.get('parallelexec').lower()
									logger.log(1,"Parallel execution status="+str(parallelnodestatus),"D")
									matchedDeviceCounter=0
									matchedSecDeviceCounter = 0
									inUseDevices=0
									noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
								
									noofunlocked = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
							
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Bed Name Matched: "+str(node.get('friendlyname')),"D")
									result=self.findSWCap(record.get('sw_cap').split(','), swCap)
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]: Result of SwCap: "+str(result),"D")

									hwresult=self.findHWCap(record.get('hw_cap').split(','), hwCap)
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]: Result of HwCap: "+str(hwresult),"D")

									
									#Send mail for software capability not matching	
									if result != 0:
																		
										
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear admin,\n\n Software capabilities not matching in requested testbed: '+ str(record.get('test_bed_name'))+' and device: ' +str(record.get('devices'))+' for testsuite: '+str(record.get('script_file'))+'\n\nExpected software capabilities: '+str(record.get('sw_cap'))+'\n\n',[])

									#Send mail for hardware capability not matching	
									if hwresult != 0:
									
								
										
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n Hardware capabilities not matching in requested testbed: '+ str(record.get('test_bed_name'))+' and device: ' +str(record.get('devices'))+' for testsuite: '+str(record.get('script_file'))+'\n\nExpected hardware capabilities: '+str(record.get('hw_cap'))+'\n\n',[])
				
									if noofunlocked[0] >= 1:
										priavail= True
									else:
										priavail = False
									if priavail == True:
											nodeWithPri.append(node)								
											
											
									else:
										logger.log(1,"No primary devices available","D")

					#Send mail for no node with number of secondary devices available
					if len(nodeWithSec)== 0:
						
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node '+ str(record.get('test_bed_name'))+' has no secondary devices required for execution of job'+str(record['script_file'])+'. \nNumber of secondary devices required='+str(record['support_device_count']-1)+'\n\n',[])
					#Send mail for no node with primary devices available
					else:
						if len(nodeWithPri)== 0:
							productresult = self.checkproduct(record)
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node '+ str(record.get('test_bed_name'))+'  has no devices required for execution for job:'+str(record['script_file'])+"Device required:\n"+"Product:"+str(record['product'])+"OS:"+str(record['os'])+str(productresult)+'\n\n',[])
					
					
			#If node is avaialble for execution		
			else:
				
				for node in nodestobechecked:

					if node.get('location')==record.get('location') and str(node.get('friendlyname')) == str(record.get('test_bed_name')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						parallelnodestatus = node.get('parallelexec').lower()
						logger.log(1,"Parallel execution status="+str(parallelnodestatus),"D")
						matchedDeviceCounter=0
						matchedSecDeviceCounter = 0
						inUseDevices=0
						
						lockflagHw = self.inUseHardware_nothingSelected(node.get('friendlyname'),record.get('hw_cap').split(","))
			

						if lockflagHw== 'true':
							logger.log(1,"Matching External HW in use for node. Test job put in Queue","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)
							self.testQueue.close()
							break

						else:										

							
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: All Test Suite SW Capabilities Found in this Node","D")
							onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name',nodename=node.get('friendlyname'))
							
							
							countOfDevices=len(onlineDevices.get('devices'))
							#Maintain Device Info for Scheduling purpose 
							deviceList=[]
							secdeviceList =[]
							supportDev = []
							if countOfDevices==0:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Recieved Empty Device List from Device Farm","D")

							for device in onlineDevices.get('devices'):
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Device Info: ","D")
								
								logger.log(1,device,"I")
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Devices Selected By User: "+str(record.get('devices')),"I")
								testJobDevices=[]
								if "," in record.get('devices'):
									testJobDevices=record.get('devices').split(",")
								else:
									testJobDevices.append(record.get('devices'))
		
								logger.log(1,"Test job devices:","I")
								logger.log(1,testJobDevices,"I")
								if int(record['support_device_count'])> 1:
									countofSupportDevices= self.getSecondaryDevicecount(node)
									unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
								seclockedcount = int(countofSupportDevices) - int(unlockedSecDevices)
			
								if device.get('status')=='online' and device.get('locked')=='false' and device.get('secondary')=='false':
											

									if self.matchDeviceSerialId(device.get('serialno'), testJobDevices):
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Device Serial Number Matched for Primary devices","D")
										matchedDeviceCounter=matchedDeviceCounter+1
										deviceList.append(device)
										pass
									else:
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Device Serial Number Not Matched","D")
										pass
			
									logger.log(1,"Count of required support devices","D")
									suppdevices = int(record.get('support_device_count'))
									suppdevices = suppdevices-1
									logger.log(1,str(suppdevices),"D")
									if countofSupportDevices != 0:
										logger.log(1,"Online sec devices present","D")
										if suppdevices == countofSupportDevices:
											logger.log(1, "number of unlocked support devices"+str(unlockedSecDevices),"D")
							
							
								else:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Device is either Offline or Locked","D")
									if device.get('secondary')=='false':
					
										inUseDevices=inUseDevices+1

					else:
						
						logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Bed Name not Matching/ Requested node is not online","D")
						continue

#######################################################################################################################################################
					
					totalSupportDeviceCount = int(record.get('support_device_count'))
					logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
					if totalSupportDeviceCount <= 1:
						expectedDevicecount = 0
					else:
						expectedDevicecount = totalSupportDeviceCount - 1
					logger.log(1,"Expected device count"+str(expectedDevicecount),"I")
					
					logger.log(1,"matchedSecDeviceCounter"+str(countofSupportDevices),"I")
					i = 0
					
					if (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices>= expectedDevicecount) :
						
						logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Found Exact Number of Devices required for Execution on Node: "+str(node.get('friendlyname')),"D")
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						QUERY='SELECT priority FROM TBL_TEST_QUEUE where test_bed_name="'+node.get('friendlyname')+'" AND devices="' + str(device.get('serialno'))+'" ORDER BY priority'
						NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
						lenQueue = len(NewQueueRecord)
						#Check if any job available in queue of higher priority for same capabilities
						if NewQueueRecord!= ():
							minimum= min(NewQueueRecord)
							logger.log(1,"Minimum priority="+str(minimum),"D")
							logger.log(1,"Current priority="+str(record['priority']),"I")
							if int(record['priority']) >= int(minimum[0]):
									self.testQueue.insert(record)
									break
							
						self.testQueue.close()
						#Check if Node is parallel execution capable
						if parallelnodestatus =='true':
							#Lock the Devices
							
							logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Locking Devices before Starting Test Job","I")
							for device in deviceList:
								
								
								logger.log(1,"Device Info for Lock Devices : "+str(device),"D")
								lockResult = self.lock_device(nodeip=device.get('node'), serialno=device.get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
								if record.get('build_xml_location')!='NA':

									flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=device.get('serialno'))
										
									if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
										

										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Successfully Set flash status as true","D")

								else:
									flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))
								
							
							if expectedDevicecount >=1:
								secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
								logger.log(1,"Secondary dev list:"+str(secdeviceList),"I")
								if len(secdeviceList) != 0:
									for secdevice in secdeviceList:
										
										i =0
										logger.log(1,"Secondary device list:","D")
										logger.log(1,secdeviceList,"I")
										while i < expectedDevicecount:
											logger.log(1,"Secondary device list of"+str(i),"I")
											logger.log(1,secdeviceList[i].get('serialno'),"I")
											seclistjob.append(secdeviceList[i].get('serialno'))
											
											lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
											
											i = i+1	
									logger.log(1,"Sec device job:"+str(seclistjob),"I")
									record['support_devices']=",".join(seclistjob)					

								else:
									logger.log(1,"Required number of support devices are not available in the requested testbed","D")
									record['support_devices']=str(seclistjob)
							else:
								lockResultsec = True
								record['support_devices']=str(seclistjob)
							
								
							
							logger.log(1,record['support_devices'],"D")
							#Create Test Job & Trigger it
							#Create testCase.xml file for Test Job Execution
							setUp=JobPreSetup.SetUp()
							
							preSetUP=setUp.doPreSetUp(record)
							logger.log(1,"Value of presetup"+str(preSetUP[0]),"I")
							if preSetUP[0]==True and lockResult != False and lockResultsec != False:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] TestCases.xml file created||||||||||||||||||||||||||||||||||||||||||||||||","D")
								#Pass the TestCases.xml file name, Node & record to Jenkins Job Creation Module
								job=StartJob.JenkinsJob(record, node, deviceList,secdeviceList, preSetUP[1])
								#If Test Job Started; then only remove its corresponding Test Record from Queue
								jobStatus=job.startProcess()
								if jobStatus[0]:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job has been successfully started","D")
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job Name: ","I")
									
									logger.log(1,jobStatus[1],"I")
									if self.insertIntoRunningJob(record, jobStatus[1]):
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job put into Running List","D")
									break
								else:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
									#Put Test Job in Queue
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)
									self.testQueue.close()
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] UnLocking Devices after failure in Starting Test Job","I")
									for device in deviceList:
										
										unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
										
										logger.log(1,unLockResult,"I")
										flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))
										logger.log(1,flashresult,"I")
									for secdevice in secdeviceList:
										
										unLockResult = self.unlock_device(nodeip=secdevice.get('node'), serialno=secdevice.get('serialno'), operation='unlock_device')
										logger.log(1,unLockResult,"I")
							else:
								if lockResult == False or lockResultsec == False:
					
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] CLM was not able to lock the device ,drop the job","D")

										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'], 'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put the job with script  :'+str(record['script_file'])+' in queue'+'\n\n',[])


	
							pass
#######################################################################################################################################################
						else:
							
							logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Node is not Parallel Execution Capable; So Check if there is already ongoing execution","D")
							
							logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] In Use Devices for Node: "+str(inUseDevices),"I")
							#Check if there is already ongoing execution	
							
							if inUseDevices==0:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There is no ongoing execution on any Device of this Node; So Start Execution","D")
								#Lock the Devices
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Locking Devices before Starting Test Job","I")
								for device in deviceList:
									
									lockResult = self.lock_device(nodeip=device.get('node'), serialno=device.get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
									logger.log(1,lockResult,"I")
									
									

									if record.get('build_xml_location')!='NA':

										flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=device.get('serialno'))
										
										if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Successfully Set flash status as true","D")

									else:
										flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))
											
										
										
								
								secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
								logger.log(1,"Secondary dev list:"+str(secdeviceList),"I")
								if expectedDevicecount>=1:
									if len(secdeviceList) != 0:
										for secdevice in secdeviceList:
												i =0
												while i < expectedDevicecount:
													seclistjob.append(secdeviceList[i].get('serialno'))
													
													lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
											
													i = i+1	
										logger.log(1,"Sec device job:"+str(seclistjob),"I")
										record['support_devices']=",".join(seclistjob)	
													
									else:
										logger.log(1,"Required number of support devices are not available in the requested testbed","D")
									
										record['support_devices']=str(seclistjob)
								else:
									lockResultsec = True
									record['support_devices']=str(seclistjob)

								#Create Test Job & Trigger it
								#Create testCase.xml file for Test Job Execution
								setUp=JobPreSetup.SetUp()
								
								preSetUP=setUp.doPreSetUp(record)
								if preSetUP[0]==True and lockResult != False and lockResultsec != False:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] TestCases.xml file created","D")
									#Pass the TestCases.xml file name, Node & record to Jenkins Job Creation Module
									job=StartJob.JenkinsJob(record, node, deviceList,secdeviceList, preSetUP[1])
									#If Test Job Started; then only remove its corresponding Test Record from Queue
									jobStatus=job.startProcess()
									if jobStatus[0]:
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job Started Successfully","D")
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job Name: ","I")
										
										logger.log(1,jobStatus[1],"I")
										if self.insertIntoRunningJob(record, jobStatus[1]):
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Job put into Running List","D")
										break
									else:
										
										logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There is error in creating & starting Test Job; So put the Test Record in Manual Queue & Unlock Devices which are locked for this Test Job","D")
										#Put Test Job in Queue
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] UnLocking Devices after failure in Starting Test Job","I")
										for device in deviceList:
											
											unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
											logger.log(1,unLockResult,"I")
											flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false',serialno=device.get('serialno'))
											logger.log(1,flashresult,"I")	
										for secdevice in secdeviceList:
											
											unLockResult = self.unlock_device(nodeip=secdevice.get('node'), serialno=secdevice.get('serialno'), operation='unlock_device')
											logger.log(1,unLockResult,"I")

								else:
									if lockResult == False or lockResultsec == False:
					
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put  the job with script :'+str(record['script_file'])+' in queue'+'\n\n',[])
										logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] CLM was not able to lock the device ,queued the job","D")






		

								pass
#######################################################################################################################################################
							else:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There is Already ongoing execution on this Node; SO put Test Job in Manual Queue","D")
								#Put Test Job in Queue
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(record)
								self.testQueue.close()
								pass
#######################################################################################################################################################
					elif (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices < expectedDevicecount and seclockedcount!=0) :
						logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There are no sufficient matching Devices for execution on User Selected Node; So put Test Job in Manual Queue" ,"D") 
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(record) 
						self.testQueue.close()


					elif (matchedDeviceCounter==PrimaryDeviceCount and matchedDeviceCounter!=0) and (unlockedSecDevices < expectedDevicecount and seclockedcount==0  ) :
						logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There are no sufficient matching Devices for execution on User Selected Node; Send email to admin" ,"D")  
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_sufficient_supportdevice'],'Dear admin,\n\n No sufficient support devices in requested testbed: '+ str(record.get('test_bed_name'))+' for testsuite: '+str(record.get('script_file'))+'\nExpected number of support devices: '+str(expectedDevicecount)+'\n\n',[])

					elif matchedDeviceCounter==0 and inUseDevices==0 :
						logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] The slotted test beds donot have required sw capabilities" ,"D") 
						pass
					else:
						logger.log(1, "[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] There are no sufficient matching Devices for execution on User Selected Node; So put Test Job in Manual Queue" ,"D")                  
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(record) 
						self.testQueue.close()
						pass
#############################################################################################################################################
				else:
					
					logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Test Bed Location not Matching","D")
					pass
#######################################################################################################################################################
		
			
#######################################################################################################################################################
		except Exception, e:
			
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.manualgitcheck.close()
			self.testQueue.close()
			self.buildInfo.close()
			self.testRun.close()           
			logger.log(1,"ManualMatchFinder startProcessTestBedandDeviceSelected EXCEPTION"+str(e),"E")

		finally:
			
			self.lock.release()
			logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected] Lock Releasing","I")
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check if locked devices are available in the testbed selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test Record	
	# lockedDevicesList	List		List of locked devices							#
	# devicetype		String		Type of device-primary or secondary							#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################


	def lookForLockedDevices_TestBedSelected(self, lockedDevicesList, testRecord, devicetype):
		try:
			#Maintain Device Info for Scheduling purpose 
			deviceList=[]
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			unlockedDevices=0
			for device in lockedDevicesList:
				
				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] Locked Device: ","D")
				
				logger.log(1,device,"I")
				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] All HW Capabilities of Locked Device Matched","I")
				deviceList.append(device)
				foundAllHWCapNode=True
				foundAllHWCapDevice=True
				unlockedDevices=unlockedDevices+1
				
			if foundAllHWCapDevice==True:
				
				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] Unlocked Devices: "+str(unlockedDevices),"D")
				
				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] Required Support Devices for Test Execution: "+ str(eval(testRecord.get('support_device_count'))-1),"I")

				if devicetype == 'Primary':
					if unlockedDevices>=1:
						
						logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] Node has sufficient Device Count for Execution","D")
						return True	
					else:
						return False
				
			else:
				return False						


		except Exception, e:
			
                       
			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_TestBedSelected] EXCEPTION"+str(e),"E")
			return False

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	# expectedcount		Integer		Expected count of secondary devices for the job # 		#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicelist		List	List of available secobdary devices 												
    	#########################################################################################################


	def lookforSecondarydevices(self,node,expectedcount):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicelist=[]   
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		logger.log(1,"Online sec devices:","I")
		logger.log(1,str(onlineSecDevices),"I")
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)
		
		if len(unlockedsecdevices)>= expectedcount:
			i = 0
			while i< expectedcount:
					secdevicelist.append(unlockedsecdevices[i])
					i =i+1

		logger.log(1,"Available secondary devices:"+str(secdevicelist),"I")
		return secdevicelist
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicecount	Integer		Count of available secobdary devices 												
    	#########################################################################################################

	def getSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		secdevicecount = len(onlineSecDevices.get('devices'))
		logger.log(1,"total count of locked and unlocked secondary device from node:"+str(secdevicecount),"I")
		return secdevicecount
		

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# unlockedsecdevicecount	Integer		Count of available unlocked secobdary devices 												
    	#########################################################################################################
		

	def getunlockedSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		unlockedsecdevicecount = len(unlockedsecdevices)
		logger.log(1,"count of unlocked secondary device from node:"+str(unlockedsecdevicecount),"I")
		return unlockedsecdevicecount


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Find match for Test Record for which User has provided only Test Bed for execution in Manual Mode	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# record	Dictionary	Test Record								#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_TestBedSelected(self, record=None):
		
		try:
			
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] In startProcess_TestBedSelected |||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||","I")
			
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
			scrum_teamname= str(record.get('scrum_name'))
			user_name = str(record.get('user'))
			logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
			if str(scrum_teamname) == "NA":
				priority = self.ScrumDetails.getPriority("System Test", "manual")
			else:
				scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
				if scrumpriotablecheck == 1:
					priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
					if priority == None:
						priority = self.ScrumDetails.getPriority("System Test", "manual")
				else:
					priority = self.ScrumDetails.getPriority("System Test", "manual")
			logger.log(1,"Priority of job="+str(priority),"I")
			role_id = self.ScrumDetails.getroleid(user_name)
			record['priority'] = int(priority)
			self.ScrumDetails.close()
			
			nodelockedstatus=self.deviceFarm.get_nodelocked_status(operation='get_nodelocked_status',name=record.get('test_bed_name'))
			self.manualgitcheck=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
			manualgitstatus=self.manualgitcheck.getmanualgitstatus(str(record.get('test_bed_name')))
			systemlocked=self.manualgitcheck.getsystemlockedinfo(str(record.get('test_bed_name')))
			gitpullstatus=self.manualgitcheck.getscheduledgitstatus(str(record.get('test_bed_name')))
			self.manualgitcheck.close()

			prionodes= self.devicefarmdb.getprionodes(record['scrum_name'])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			if gitpullstatus=='IN_PROGRESS'or gitpullstatus=='INITIATED' or nodelockedstatus['nodeStatus']['locked']=='True' or manualgitstatus=='True'or systemlocked=='true':
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				self.testQueue.insert(record)
				self.testQueue.close()
				if nodelockstatus=='True' or manualgitstatus == 'True':
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Git_Pull'],'Dear admin,\n\n Manual git is on , job has been put into queue for test bed-'+ str(record.get('test_bed_name'))+'\n\n',[])
				return

			self.lock.acquire()
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Lock Locking","I")

			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()


			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected]  Executing Script:"+record["script_file"],"I")
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected]  Executing Script time:"+record["creation_timestamp"],"I")
		
			lockedDevices = []
			unlockedDevices=0
			unlockedSecDevices=0
			if record["build_xml_location"]!="NA":
				checkrecord=None
				self.buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record["build_number"]+"'"		
				pilottested= self.buildInfo.execute(Query, "SELECT")
				self.buildInfo.close()
		
				if pilottested[0]=="YES":
					pass

				else:
			
		        		self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		        		query1='SELECT * FROM TBL_RUNNING_TEST where build_xml_location="'+record["build_xml_location"]+'" AND mode="Manual" AND flash_status="IN_PROGRESS"'
		        		checkrecord=self.testRun.execute(query1,"SELECT");
			
		        		self.testRun.close()
		        		if checkrecord==None:
							pass
		        		else:
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)
							self.testQueue.close()
							logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Record  put in queue for pilot testing"+str(record),"D")
							self.lock.release()
							return
			#Number of Devices Required
			totalSupportDeviceCount=int(record.get('support_device_count'))+1
			
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Total Device Count: "+str(totalSupportDeviceCount),"I")
			PrimaryDeviceCount=1

			
			
			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			# Variable initialisations
			flag=False
			unlockedSecDevices = 0
			seclockedcount = 0
			expectedDevicecount = 0
			matchedSecDeviceCounter = 0
			matchedDeviceCounter=0
			matchedSecDeviceCounter = 0
			lockResultsec = False
			lockResult = False
			foundAllHWCapDevice=False
			lockedDevices = []
			nodeWithPri=[]
			nodeWithSec=[]
			OnlineSecDevices=0
			lockflagHw = 'false'
			seclistjob = []
			foundAllHWCapNode=False
			product = "NA"
			os = "NA"
			lockeddev = 0
			nodestobechecked =[]
			nodewithlocked = []
			devavail = False
			nodeavail = "false"
			# For scrum master-all nodes to be checked
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					
					swCap=node.get('softwares').split(',')
					hwCap = node.get('hardwares').split(',')
					logger.log(1,"Node="+str(node),"D")
					logger.log(1,"Node type="+str(type(node)),"I")
					if node.get('friendlyname')== record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						foundnode = True
						nodeavail = self.checknode(record,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0]== "true" and foundnode == True:
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
								if node.get('friendlyname')== record.get('test_bed_name')and str(node.get('location')) == str(record.get('location'))  and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
									lockeddev = nodeavail[2]
									OnlineSecDevices= self.getSecondaryDevicecount(node)
								#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1: 
								unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
									nodewithlocked.append(node)
								else:
									continue
				if len(nodestobechecked)== 0: 

					logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
					if len(nodewithlocked) != 0:
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(record)
						self.testQueue.close()
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")

				
			
			# For users other than scrummaster
			else:		
					
				logger.log(1,"Prionodes="+str(prionodes),"D")
				if prionodes!= None:
					x = len(prionodes)
				else:
					x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				# Check in available priority nodes
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(record.get('scrum_name')),"I")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"Node="+str(node),"I")
						logger.log(1,"Node type="+str(type(node)),"I")
						if node.get('friendlyname')== record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
							foundnode = True
							nodeavail = self.checknode(record,swCap,hwCap,node)
							logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0]== "true" and foundnode == True:
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
								if node.get('friendlyname')== record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
									lockeddev = nodeavail[2]
									if int(record['support_device_count']) >1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
								#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
								unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
									nodewithlocked.append(node)
								else:
									continue
					# If priority nodes not having devices available, check common nodes
					if devavail!= True and foundnode == False:
						if commonnodes!= None:
							y = len(commonnodes)
						else:
							y = 0
						# Check within available common nodes
						if y != 0:
							for j in commonnodes:
									node= self.devfarmconvertToDictionary(j)
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									nodeavail = self.checknode(record,swCap,hwCap,node)
									if nodeavail[0]!= "true":
										nodestobechecked.append(node)
										logger.log(1,"Node to be checked ="+str(nodestobechecked),"D")
										devavail = True
									elif nodeavail[0]!= "SW-HW cap not matching":
										if node.get('friendlyname')== record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
											lockeddev = nodeavail[2]
											if int(record['support_device_count']) >1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
										#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
										unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
										if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
											nodewithlocked.append(node)
										else:
											continue
							if len(nodestobechecked)== 0:
								if len(nodewithlocked) != 0:
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)
									self.testQueue.close()
								else:
									logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
									
						else:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								
					# If both priority and common nodes not available
					else:
						if len(nodestobechecked)== 0:
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:
										logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","I")
										
							
				# If no nodes assigned to scrum team, check common nodes	
				else:
					logger.log(1,"Commonnodes="+str(commonnodes),"D")
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y=0
					logger.log(1,"Length of Commonnodes="+str(y),"I")
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								hwCap = node.get('hardwares').split(',')
								nodeavail = self.checknode(record,swCap,hwCap,node)
								logger.log(1,"Node avail="+str(nodeavail[0]),"I")
								if nodeavail[0]== "true":
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"D")
									devavail = True

								elif nodeavail[0]!= "SW-HW cap not matching":	
									if node.get('friendlyname')== record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
										lockeddev = nodeavail[2]
										if int(record['support_device_count']) >1:
											OnlineSecDevices= self.getSecondaryDevicecount(node)
									#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:
									unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
									if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
										nodewithlocked.append(node)
									else:
										pass
						if len(nodestobechecked)== 0: 

							logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
							if len(nodewithlocked) != 0:
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(record)
								self.testQueue.close()
							else:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","I")
						
#######################################################################################################################################################
			#Create Locked Devices's List; so that if any match found from this list, Scheduler can keept Test Job in Queue
			lockedDevicesList=[] 
			seclockedDevicesList =[]
#######################################################################################################################################################

			# If no nodes available, state reason for unavailability
			if len(nodestobechecked)== 0: 
				if len(nodewithlocked) == 0:
					for node in allNodes.get('nodes'):
						
						matchedDeviceCounter=0
						matchedSecDeviceCounter = 0
						foundAllHWCapDevice=False
						
						lockedDevices = []
						lockflagHw = 'false'
						seclistjob = []
						
						if node.get('location')==record.get('location') and str(node.get('friendlyname')) == str(record.get('test_bed_name')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
							
							logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Location Matched: "+str(record.get('location')),"D")
							if node.get('friendlyname')==record.get('test_bed_name') and str(node.get('location')) == str(record.get('location')):
								swCap=node.get('softwares').split(',')
								hwCap = node.get('hardwares').split(',')
								logger.log(1,"External hwcap:"+str(hwCap),"D")
								parallelnodestatus = node.get('parallelexec').lower()
								logger.log(1,"Parallel execution status="+str(parallelnodestatus),"I")
								matchedDeviceCounter=0
								matchedSecDeviceCounter = 0
								
							
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Bed Name Matched: "+str(node.get('friendlyname')),"I")
								#Unlocked Devices Counter
								
								
								logger.log(1,node,"I")
								result=self.findSWCap(record.get('sw_cap').split(','), swCap)
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected]: Result of SwCap: "+str(result),"I")

							
								hwresult=self.findHWCap(record.get('hw_cap').split(','), hwCap)
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected]: Result of HwCap: "+str(hwresult),"I")
								noofunlocked = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
								if int(record['support_device_count']) >1:	
										noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
										if noofavailsecdev >= int(record['support_device_count'])-1: 
											nodeWithSec.append(node)
											secresult = True
										else:
											secresult = False
								else:
									secresult = True
								if secresult == True:
									nodeWithSec.append(node)
							
									if result!=0:
										
															
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear admin,\n\n Software capabilities not matching in requested testbed: '+ str(record.get('test_bed_name'))+' for testsuite: '+str(record.get('script_file'))+'\nExpected software capabilities: '+str(record.get('sw_cap'))+'\n\n',[])

									if hwresult!=0:
										

										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n Hardware capabilities not matching in requested testbed: '+ str(record.get('test_bed_name'))+' and device: ' +str(record.get('devices'))+' for testsuite: '+str(record.get('script_file'))+'\n\nExpected hardware capabilities: '+str(record.get('hw_cap'))+'\n\n',[])

									if noofunlocked[0] >= 1:
										priavail= True
									else:
										priavail = False
									if priavail == True:
											nodeWithPri.append(node)								
											
											
									else:
										logger.log(1,"No primary devices available","D")
										
											
								else:
									logger.log(1,"Sufficient secondary dev not available","D")
									

					if len(nodeWithSec)== 0:
							
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has secondary devices required for execution of job'+str(record['script_file'])+'. \nNumber of secondary devices required='+str(record['support_device_count']-1)+'\n\n',[])
					else:
						if len(nodeWithPri)== 0:
							productresult = self.checkproduct(record)	
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has devices required for execution of job:'+str(record['script_file'])+"Device required:\n"+"Product:"+str(record['product'])+"OS:"+str(record['os'])+str(productresult)+'\n\n',[])
						
			# If node available for execution
			else:
				
				for node in nodestobechecked:
						if node.get('location')==record.get('location') and str(node.get('friendlyname')) == str(record.get('test_bed_name')) and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':

							parallelnodestatus = node.get('parallelexec').lower()
							logger.log(1,"Parallel execution status="+str(parallelnodestatus),"D")
							matchedDeviceCounter=0
							matchedSecDeviceCounter = 0
							foundAllHWCapDevice=False
							
							lockedDevices = []
							lockflagHw = 'false'
							seclistjob = []
							lockflagHw = self.inUseHardware_nothingSelected(node.get('friendlyname'),record.get('hw_cap').split(","))
							

							if lockflagHw== 'true':
								logger.log(1,"Matching External HW in use for node. Test job put in Queue","D")
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(record)
								self.testQueue.close()
								break

							else:
							
								onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
								
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Online Devices for this Node: ","I")
								
								foundAllHWCapDevice=False
								countOfDevices=len(onlineDevices.get('devices'))
								
								#Maintain Device Info for Scheduling purpose 
								deviceList=[]
								secdeviceList=[]
							
								inUseDevices=0
								#osRecord = Config['OS_VERSIONS']
								if countOfDevices==0:
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Recieved Empty Device List from Device Farm","D")
								matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
								unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
								seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)
								for device in onlineDevices.get('devices'):
									
									logger.log(1,device,"D")
									if device.get('status')=='online' and device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Device is Online & Unlocked","D")
										#Get Product & OS Information for all selected Online Devices from above step &
										#Select only those Devices, which have matching Product &
										#OS info mentioned in record['product'] & record['os']
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Matching Product & OS","D")
										
										logger.log(1,device.get('name')+record.get('product'),"I")
										
										logger.log(1,str(device.get('version')).split("-")[1]+str(record.get('os')),"I")
										#if device.get('name')==record.get('product') and device.get('version')==record.get('os').split(" ")[1]: Uncomment It*****************************************************************************************************************
										#Logic to check OS Versions
										osFlag=False
										for osIter in record.get('os').split(","):
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] OS: "+ str(osIter.strip(" '")),"D")
											if (str(device.get('version'))).split("-")[1] == str(osIter.strip(" '")):
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] OS Version Matched:" +osIter.strip(" '"),"D")
												osFlag=True
												#Critical Section
												record['os']=osIter.strip(" '")
												os_version = str(device.get('version')).split("-")[1]
												break


										#if device.get('name')==record.get('product') and device.get('version') in Config.OS_VERSIONS.get(record.get('os')):
										#call check for device function for complete matching
										result=self.checkfordevice(record,device,osFlag)
										if result==True:
											
											product = device.get('name')
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Device Product, OS Matched","D")
												
											
											if device.get('secondary')=='false': 
												deviceList.append(device)
												foundAllHWCapNode=True
												foundAllHWCapDevice=True
												unlockedDevices=unlockedDevices+1
												logger.log(1,"Unlocked devices:"+str(unlockedDevices),"D")
												
									elif device.get('locked')=='true' or device.get('flash_status')=='true' :
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Device is either Locked or Offline; So put Device in Locked Devices List","D")
										if device.get('secondary')=='false': 
											inUseDevices=inUseDevices+1
											lockedDevices.append(device)
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Matching Product & OS of Primary Locked Device: ","D")
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Matching Product & OS of Locked Device: ","I")
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Device Property : Test Suite Property","I")
										
										logger.log(1,device.get('name')+" : "+str(record.get('product')),"I")
										
										print str(device.get('version')).split("-")[1], str(record.get('os'))
										if ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
											#Logic to check OS Versions
											osFlag=False
											for osIter in record.get('os').split(","):
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] OS: "+ str(osIter.strip(" '")),"D")
												if (str(device.get('version'))).split("-")[1] == str(osIter.strip(" '")):
													
													logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] OS Version Matched: "+str(osIter.strip(" '")),"D")
													osFlag=True
													os_version = str(device.get('version')).split("-")[1]
													break
		
											#if device.get('name')==record.get('product') and device.get('version') in Config.OS_VERSIONS.get(record.get('os')):
											result=self.checkfordevice(record,device,osFlag)
											if result==True:
											
												
												product = device.get('name')
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Locked Device's Product, OS Matched","D")
												if device.get('secondary')=='false': 
													lockedDevicesList.append({'node': node, 'devices': lockedDevices})
											
		
	#######################################################################################################################################################
							totalSupportDeviceCount = int(record.get('support_device_count'))
							logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
							if totalSupportDeviceCount <= 1:
								expectedDevicecount = 0
							else:
								expectedDevicecount = totalSupportDeviceCount - 1

														
							logger.log(1,"Matched sec devices:"+str(matchedSecDeviceCounter),"I")

							if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Unlocked Primary Devices: "+ str(unlockedDevices),"D")
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")

								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] locked Secondary Device count: "+ str(seclockedcount),"I")
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Required Support Devices for Test Execution: "+str(expectedDevicecount),"I")
								#Check testRecord['support_device_count'] info & verify whether Node has sufficient
								#device count for execution
								if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Node has sufficient Device Count for Execution","D")
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] In Use Primary Devices for Node: "+str(inUseDevices),"I")
									
									
									testJobScheduled=False
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									QUERY='SELECT priority FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" AND test_bed_name="'+node.get('friendlyname')+'" ORDER BY priority;'
									NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
									lenQueue = len(NewQueueRecord)
									
									# Check if any job available in queue with higher priority
									if NewQueueRecord!= ():
										minimum= min(NewQueueRecord)
										logger.log(1,"Minimum priority="+str(minimum),"D")
										logger.log(1,"Current priority="+str(record['priority']),"I")
										if int(record['priority']) >= int(minimum[0]):
												self.testQueue.insert(record)
												testJobScheduled = True
												break
										
									self.testQueue.close()
	#######################################################################################################################################################
									if parallelnodestatus =='true':
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Node is Parallel Execution Capable; So Create Jenkins Job for this Test Job & Trigger it on Test Bed","I")
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Trigger Test Job on Device","I")
										secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										
										preSetUP=setUp.doPreSetUp(record)
										if preSetUP[0]==True:
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] TestCases.xml file created","D")
											#Pass the TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(record, node, deviceList,secdeviceList,preSetUP[1])
											#If Test Job Started; then only put its corresponding Test Record into Running Test Jobs List
											
											#if jobStatus[0]:
											if True:
												
												

												#Lock the Devices
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Locking Devices before Starting Test Job","I")
												
												logger.log(1,"Primary device list:","I")
												logger.log(1,deviceList,"I")
												
												logger.log(1,"Secondary device list:","I")
												logger.log(1,secdeviceList,"I")
												if deviceList!= None:
													logger.log(1,"Lock for primary devices","D")
													
													lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
													logger.log(1,lockResult,"I")
										

													if record.get('build_xml_location')!='NA':
														flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))
									
														if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																

																logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Successfully Set flash status as true","D")

													else:
														flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))
								
												if expectedDevicecount>=1:
													if len(secdeviceList)!= 0:
														i = 0
														seclistjob = []
														while i < expectedDevicecount:
															seclistjob.append(secdeviceList[i].get('serialno'))
															logger.log(1,"Sec job list:"+str(seclistjob),"D")
															
															lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
															logger.log(1,lockResultsec,"I")
																
															i = i+1
								
														record['support_devices']=",".join(seclistjob)

													else:
														record['support_devices']=str(seclistjob)
												else:
													lockResultsec= True
													record['support_devices']=str(seclistjob)

												if lockResult != False and lockResultsec != False:

													
													#Add Test Bed & Device Data to Test Record (For Auto Mode)
													jobStatus=job.startProcess()
													if jobStatus[0]:
													
														logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Putting Test Bed & Device Details: ","D")
													
														logger.log(1,deviceList[0].get('serialno'),"I")
														record['devices']=deviceList[0].get('serialno')
												
												
												
														if self.insertIntoRunningJob(record, jobStatus[1]):
														
															logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Job put into Running List","D")
														break
													else:
														logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] There is error in creating & starting Test Job; So put the Test Record in Manual Jobs Queue & Unlock Devices which are locked for this Test Job","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														self.testQueue.insert(record)
														self.testQueue.close()

														break


												else:
													logger.log(1,"Error in locking the device. Job will be put in queue","I")
													#job.removefromjenkins(str(jobStatus[1]),node.get('friendlyname'))	
													logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","I")
													
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(record)
													self.testQueue.close()
													self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put  the job with script :'+str(record['script_file'])+' in queue'+'\n\n',[])
													
													break
													
											else:
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] There is error in creating & starting Test Job; So put the Test Record in Manual Jobs Queue & Unlock Devices which are locked for this Test Job","D")
												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												self.testQueue.insert(record)
												self.testQueue.close()
												
	#######################################################################################################################################################
									else:
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Node is not Parallel Execution Capable","D")
										#Check whether there is any already ongoing execution on Test Bed
										#If no Ongoing execution then Schedule test Job 
										#& trigger it on Test Bed
										#Else put Test Job in Queue
										
										if inUseDevices==0:
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")

											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Trigger Test Job on Device","I")
											secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
											#Create testCase.xml file for Test Job Execution
											setUp=JobPreSetup.SetUp()
											
											preSetUP=setUp.doPreSetUp(record)
											if preSetUP[0]==True:
												
												logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] TestCases.xml file created","D")
												#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
												job=StartJob.JenkinsJob(record, node, deviceList, secdeviceList, preSetUP[1])
												#If Test Job Started; then only remove its corresponding Test Record from Queue
												
												#if jobStatus[0]:
												if True:
																												
													logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Job has been successfully started","D")
													
													logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Job Name: ","I")
													
													

													#Lock the Devices
													
													logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Locking Devices before Starting Test Job","I")
													if deviceList!= None:
														logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Locking Device: "+str(deviceList[0].get('serialno')),"D")
														
														lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
													

														logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Successfully Locked Device","I")

														if record.get('build_xml_location')!='NA':
															flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))
											
															if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																

																logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Successfully Set flash status as true","D")


														else:
															flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))

													if expectedDevicecount >=1:
														if len(secdeviceList)!= 0:
																i =0
																seclistjob = []
																while i < expectedDevicecount:
																		seclistjob.append(secdeviceList[i].get('serialno'))
										
																	
																		
																		lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
																		logger.log(1,lockResultsec,"I")
																		
																		i=i+1
																record['support_devices']=",".join(seclistjob)

														else:
															record['support_devices']=str(seclistjob)
													else:
														
														lockResultsec = True
														record['support_devices']=str(seclistjob)

													if lockResult != False and lockResultsec != False:
														jobStatus=job.startProcess()
														#Add Test Bed & Device Data to Test Record (For Auto Mode)
														if jobStatus[0]:
														
															logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Putting Test Bed & Device Details: ","I")
														
															logger.log(1,deviceList[0].get('serialno'),"I")
															record['devices']=deviceList[0].get('serialno')

														
															if self.insertIntoRunningJob(record, jobStatus[1]):
															
																logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Job put into Running List","D")
															break

														else:

															logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
															self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
															self.testQueue.insert(record) 
															self.testQueue.close()
													
		                                        								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","D")
															break 






													else:
														logger.log(1,"Error in locking the device. Job will be put in queue","I")
														#job.removefromjenkins(str(jobStatus[1]),node.get('friendlyname'))	
														logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","I")							
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														self.testQueue.insert(record)
														self.testQueue.close()
														self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put  the job with script :'+str(record['script_file'])+' in queue'+'\n\n',[])



														#self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Job is inserted into queue.Expected hardware dependencies'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])

														break
												else:
													
													logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(record) 
													self.testQueue.close()
													
		                                        						logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] UnLocking Devices after failure in Starting Test Job","D") 
													

										else:
											#Put Test Job in Queue
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So Put the Test Job in Queue","D")
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											self.testQueue.insert(record) 
											self.testQueue.close()
											pass
	#######################################################################################################################################################
								elif (unlockedDevices > 1) and ((unlockedSecDevices < int(expectedDevicecount)) and seclockedcount !=0):
									logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Node has no sufficient unlocked Support Device Count for execution.Put job in Queue","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)	
									self.testQueue.close()
								
								else:
									#Put Test Job in Queue
									
									logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Node has no sufficient Device Count for execution","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)	
									self.testQueue.close()
	#######################################################################################################################################################
							else:
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Looking for Locked Devices","D")
								if len(lockedDevicesList)>0 and (matchedSecDeviceCounter >= expectedDevicecount):
									deviceType = "Primary"
									if self.lookForLockedDevices_TestBedSelected(lockedDevicesList, record,deviceType)==True:
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] No Devices Found from this Node which has All HW Capabilities; so put the Test Job in Queue","D")
										#Put Test Job in Queue
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)	
										self.testQueue.close()
									else:
										#Send EMAIL Notification to Device Farm Admin
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n No Devices found with matching HW Capabilities.Expected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] No Devices Found from this Node which has All HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1","D")                                                                                                           
								elif len(lockedDevicesList)== 0 and (matchedSecDeviceCounter >= expectedDevicecount):
									#Send EMAIL Notification to Device Farm Admin
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Primary Devices found with matching HW Capabilities.Expected hardware dependencies'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])

								elif (unlockedDevices < expectedDevicecount) and (int(seclockedcount) >0):
											
											logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] No Unlocked support Devices Found from this Node which has All HW Capabilities; so put the Test Job in Queue","D")
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											self.testQueue.insert(record)	
											self.testQueue.close()

								else:

										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] No sufficient Secondary Devices Found from this Node which has All HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1","D")                                                              
										
										self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n Suffiecient Secondary Devices not found  in selected testbed:'+str(record.get('test_bed_name'))+"for script:"+str(record.get('script_file'))+'\n Expected number of support devices:'+str(expectedDevicecount)+'\nExpected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
											
								
#######################################################################################################################################################
						else:
							
							logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Bed Name not Matched: "+str(node.get('friendlyname'))+" or Requested testbed not online","D")
#######################################################################################################################################################
				else:
					
					logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Test Bed Location not Matched: "+str(record.get('location')),"D")
#######################################################################################################################################################
			
#######################################################################################################################################################
		except Exception, e:
			
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.manualgitcheck.close()
			self.testQueue.close()
			self.buildInfo.close()
			self.testRun.close()
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] EXCEPTION"+str(e),"E")

		finally:
			
			self.lock.release()
			logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Lock Releasing","I")


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check if locked devices are available when the testbed not selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test Record	
	# lockedDevicesList	List		List of locked devices							#
	# devicetype		String		Type of device-primary or secondary							#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################



	def lookForLockedDevices_NothingSelected(self, lockedDevicesList, testRecord,deviceType):
		try:
			filteredNodes=[]
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			
			for nodeDetail in lockedDevicesList:
				logger.log(1,"Inside lock nothing selected","D")
				node=nodeDetail.get('node')
				unlockedDevices=0
				
				foundAllHWCapDevice=False
				logger.log(1,"locked list"+str(nodeDetail),"I")
				logger.log(1,"locked devices list"+str(nodeDetail.get('devices')),"I")
				countOfDevices=len(nodeDetail.get('devices'))
				#Maintain Device Info for Scheduling purpose 
				deviceList=[]
				secdeviceList=[]
				unlockedSecDevices = 0

				for device in nodeDetail.get('devices'):
					
                    			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Locked Device: ","D")
					
					logger.log(1,device,"I")

					result=self.findHWCap(testRecord.get('hw_cap').split(","),nodeDetail.get('hardwares'))
					if result==0:
						if deviceType == 'Primary':
							
	                        			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] All HW Capabilities of Locked Primary Device Matched","D")
							deviceList.append(device)
							foundAllHWCapNode=True
							foundFewHWCapNode=False
							foundAllHWCapDevice=True
							foundFewHWCapDevice=False
							unlockedDevices=unlockedDevices+1
						
					else:
						foundFewHWCapNode=True
						foundFewHWCapDevice=True
#######################################################################################################################################################
				if foundAllHWCapDevice==True:
					logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Unlocked Devices: "+ str(unlockedDevices),"D")
					
					unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)	
					secdeviceList = self.lookforSecondarydevices(node, str(testRecord.get('support_device_count')-1))
					#Check testRecord['support_device_count'] info & verify whether Node has sufficient locked device count for execution
					
					if deviceType == 'Primary':
						if unlockedDevices>=1:
						
                        				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Add Node to filteredNodes; & Continue Processing of Node","D")
							filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicablePrimaryDevices':unlockedDevices, 'applicableSecondaryDevices':unlockedSecDevices,'devices':deviceList, 'support_devices':secdeviceList})
						else:
							#Reject Node
							pass
					
										
			
				else:
					#Reject Node
					
                    			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] No Locked Devices Found from this Node which has All HW Capabilities","D")
#######################################################################################################################################################
			#If Node found, which has Locked Device with all HW Capabilities 
			if foundAllHWCapNode==True:
				#Process Node further
				#If no Node has sufficient Locked Devices for execution, then Send EMAIL Notification
				if len(filteredNodes)==0:
					#Send EMAIL Notification
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_locked_device'],'Dear user,\n\nNo Node has sufficient Locked Devices for execution\n\n',[])
					
                    			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] No Node has sufficient Locked Devices for execution; send EMAIL Notification","D")
					return False
				else:
					filterredNodeCounter=1
					#Process Node further
					
                    			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Filterred Nodes: ","I")
					

					testJobScheduled=False
					for node in filteredNodes:
						parallelnodestatus = (node.get('node').get('parallelexec')).lower()
						print "Parallel execution status=",parallelnodestatus
						
						logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Fileterred Node "+str(filterredNodeCounter),"D")
						filterredNodeCounter=filterredNodeCounter+1
						
						logger.log(1,node,"I")
#######################################################################################################################################################
						if parallelnodestatus =='true':
							
                            				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Node is Parallel Execution Capable; So Put the Test Job in Queue","D")
							return True
						else:
							
                            				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Node is not Parallel Execution Capable","D")
							
							if node.get('totalDevices') >= (node.get('applicablePrimaryDevices')+node.get('applicableSecondaryDevices')):
								
                                				logger.log(1,"[lookForLockedDevices_NothingSelected] Put Test Job In Queue","D")
								return True
							else:
								#Send EMAIL Notification
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_sufficient_device'],'Dear user,\n\nNo sufficient device found in any node\n\n',[])
								
                                				logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] Send EMAIL Notification","D")
								return False
#######################################################################################################################################################
			else:
				#Send EMAIL Notification to Device Farm Admin
				self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear user,\n\nNo Node found with matching HW capabilities.Expexted HW capabilities'+str(testRecord.get('hw_cap'))+"\nExpected product:"+str(testRecord.get('product'))+"\nExpected OS version:"+str(testRecord.get('os'))+"\n\n",[])
				
                		logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] No Node found which has Unlocked Devices with matching HW Capabilities; Send EMAIL Notification to Device Farm Admin","D")                                                                                                          
				return False
#######################################################################################################################################################
		except Exception, e:
			
			logger.log(1,"[ManualMatchFinder_lookForLockedDevices_NothingSelected] EXCEPTION"+str(e),"E")
			return False
		

#######################################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check if teh hardware is in use for the node selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# nodename		String		Node name	
	# hwCap			String		Hardware capability to be checked						#
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################

	def inUseHardware_nothingSelected(self, nodename, hwCap):
		#self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		try:
			
			lockflagHw = 'false'
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			inUseHardware = self.testRun.inUseHwCap(nodename)
			self.testRun.close()
			inUseHardware = str(inUseHardware)
			inUseHardware = inUseHardware.replace("(","")
			inUseHardware = inUseHardware.replace(")","")
			inUseHardware = inUseHardware.replace("'","")
			logger.log(1,"In use hardware:"+str(inUseHardware),"D")
		
		
			if inUseHardware.split(",")[0] == "NA":
				logger.log(1,"No hardware required","I")
				return lockflagHw

			else:
				for a in hwCap:
					
						j= 0
						if len(inUseHardware)!=0:
								if "," in inUseHardware:
									inUseHardware = inUseHardware.split(",")
				
									logger.log(1,"New in use hardware:"+str(inUseHardware),"D")
								for j in inUseHardware:
										logger.log(1,"a"+str(a.strip(' ')),"I")
										
										if a.strip(' ')==j.encode('ascii', 'ignore'):
											logger.log(1, "Found match with in use hardware","D")
											lockflagHw = 'true'
											
											break
		
				return lockflagHw
		
		except Exception, e:
			
			logger.log(1,"[ManualMatchFinder] inUseHardware_nothingSelected EXCEPTION"+str(e),"E")
			return 'false'
		
		#finally:
			#self.testRun.close()
	
	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of unlocked devices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked		
    	# os		string		OS version to be checked			
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# # resultarray	array		[Number of unlocked devices , number of locked devices] 															#
    	#################################################################################################################
	
	def checkunlockeddevices(self, product,os,nodename,record):
		logger.log(1,"Inside unlocked devices","I")
		unlockedcount = 0
		lockedcount = 0
		resultarray = []
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices=  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		
		logger.log(1,"Devices="+str(devices),"I")
		
		for device in devices['devices']:
			


			result=self.checkfordevice(record,device,True)

			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os and device.get('secondary')=='false' and result==True:
					if str(device.get('locked').lower()) != 'true':
						unlockedcount=unlockedcount+1
					else:
						lockedcount = lockedcount+1
		resultarray.append(unlockedcount)
		resultarray.append(lockedcount)
		return resultarray

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of locked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked		
    	# os	string			OS version to be checked			
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# lockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################
	
	def checklockeddevices(self, product,os,nodename):
		
		logger.log(1,"In check for locked devices","I")
		lockedcount = 0
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices =  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		for device in devices['devices']:
			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os:
					if str(device.get('locked').lower()) == 'true':
						lockedcount=lockedcount+1
						logger.log(1,"Locked device available","D")
					else:
						pass
		return lockedcount
					
	#################################################################################################################
	# SYNOPSIS:													#
    	# Find nodes with unlocked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	dictionary	Record to be checked		
    	# node	    dictionary  Node to be checked	
	# swcap		list		List of software capabilities to be checked
	# hwcap		list 		List of hardware capabilities to be checked		
    	# 						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# resultarray	Array	[Node status,Number of unlocked devices, number of locked devices] 															#
    	#################################################################################################################
	
	def checknode(self, record,swcap,hwcap,node={}):
		checknode = None
		logger.log(1,"Inside checknode","I")
		noofdevices = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
		noofunlocked = noofdevices[0]
		nooflocked= noofdevices[1]
		resultarray=[]
		logger.log(1,"No of unlocked device:"+str(noofunlocked),"I")
		result=self.findSWCap(record.get('sw_cap').split(','), swcap)
		hwresult=self.findHWCap(record.get('hw_cap').split(','), hwcap)
		if result == 0 and hwresult==0:
			if noofunlocked >= 1:
				if int(record['support_device_count']) >1:	
					noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
					if noofavailsecdev >= int(record['support_device_count'])-1: 
						checknode = "true"
					else:
						logger.log(1,"Required secondary devices not available","I")
						checknode = "Sec_unavail"
				else:
					checknode = "true"
			else:
				checknode = "Pri_unavail"
		else:
			
			checknode = "SW-HW cap not matching"
		logger.log(1,"Checknode return value:"+str(checknode),"I")
		logger.log(1,"Result array="+str(resultarray),"I")
		resultarray.append(str(checknode))
		logger.log(1,"Result array="+str(resultarray),"I")
		resultarray.append(noofunlocked)
		logger.log(1,"Result array="+str(resultarray),"I")
		resultarray.append(nooflocked)
		logger.log(1,"Result array="+str(resultarray),"I")
		return resultarray
				
	
	#################################################################################################################
	# SYNOPSIS:													#
    	# Find match for Test Record for which User has not provided Test Bed & Device for execution in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	Dictionary	Test Record									#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# NA														#
    	#################################################################################################################
	def startProcess_NothingSelected(self, record=None):
		
		try:
			
			self.lock.acquire()
			logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Lock Locking","I")

			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
			scrum_teamname= str(record.get('scrum_name'))
			user_name = str(record.get('user'))
			logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
			if str(scrum_teamname) == "NA":
				priority = self.ScrumDetails.getPriority("System Test", "manual")
			else:
				scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
				if scrumpriotablecheck == 1:
					priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
					if priority == None:
						priority = self.ScrumDetails.getPriority("System Test", "manual")
				else:
					priority = self.ScrumDetails.getPriority("System Test", "manual")
			logger.log(1,"Priority of job="+str(priority),"I")
			record['priority'] = int(priority)
			role_id = self.ScrumDetails.getroleid(user_name)
			logger.log(1,"Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
	
			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(record['scrum_name'])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			
			self.devicefarmdb.close()
			
			logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]  Executing Script:"+record["script_file"],"I")
			logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]  Executing Script time:"+record["creation_timestamp"],"I")
			logger.log(1,"start time" +str(time.time()),"I")
			if record["build_xml_location"]!="NA":
				checkrecord=None
				self.buildInfo=DB_Interface.Build_Info(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				Query="select pilot_tested from TBL_BUILD_INFO where build_number='"+record["build_number"]+"'"		
				pilottested= self.buildInfo.execute(Query, "SELECT")
				self.buildInfo.close()
		
				if pilottested[0]=="YES":
					pass

				else:
			
		        		self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		        		query1='SELECT * FROM TBL_RUNNING_TEST where build_number="'+record["build_number"]+'" AND flash_status="IN_PROGRESS"'
		        		checkrecord=self.testRun.execute(query1,"SELECT");
			
		        		self.testRun.close()
		        		if checkrecord==None:
							pass
		        		else:
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)
							self.testQueue.close()
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Record  put in queue for pilot testing"+str(record),"D")
							self.lock.release()
							return
		
			
			
            		logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Suite SW Capabilities: ","I")
			
    			logger.log(1,record.get('sw_cap'),"I")

			#List of Nodes which have all SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithAllSWCap=[]
			nodeWithAllHWCap=[]
			nodestobechecked = []
			nodewithlocked = []
			#List of Nodes which have few SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithFewSWCap=[]
			nodeWithFewHWCap=[]
			nodeWithAllCap =[]
			nodeWithPri = []
			nodeWithSec = []
			foundAllHWCapDevice=False
			matchedSecDeviceCounter = 0
			unlockedSecDevices = 0
			seclockedcount = 0
			expectedDevicecount = 0
			lockedDevices = []
			devavail = False
#######################################################################################################################################################
			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			if allNodes==None:
				
                		logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Negative Response from Device Farm","D")
				return False
			
			manualgittestbedlocked=[]
			foundAll=False
			foundFew=False
			nodeOnline = False
			nodeOffline = False
			lockResultsec= False
			lockResult = False
			OnlineSecDevices = 0
			lockeddev = 0
			# For scrum master-all nodes to be checked
			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					if node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(record,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							nodestobechecked.append(node)
							devavail = True
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(record['support_device_count'])>1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
							if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
									nodewithlocked.append(node)
							
				if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"I")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()

									else:
										
										logger.log(1,"No node has available locked or unlocked sec devices required for execution.Send mail to admin","I")
			#For users other than scrum master; first priority nodes will be checked for availability, else common nodes would be checked #									
			else:		
				logger.log(1,"Prionodes="+str(prionodes),"I")
				if prionodes!= None:
					x = len(prionodes)
				else:
					x = 0
				logger.log(1,"Length Prionodes x="+str(x),"I")
				# Check within available priority nodes
				if x != 0:
					logger.log(1,"Testbeds have been allocated to the scrum team :"+str(record.get('scrum_name')),"D")
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						logger.log(1,"Node="+str(node),"I")
						logger.log(1,"Node type="+str(type(node)),"I")
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
						hwCap = node.get('hardwares').split(',')
						logger.log(1,"External hwcap:"+str(hwCap),"D")
						#Logic to Handle SW Capabilities


						nodeavail = self.checknode(record,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail[0]),"I")
						if nodeavail[0] == "true":
							if node['locked']!='True' and  node['manualgit']!='True' and node['scheduledgit']!='IN_PROGRESS' and node['scheduledgit']!='INITIATED': 
								parallelnodestatus = (node['parallelexec']).lower()
								if parallelnodestatus=='false':
									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									testbed_in_progress=self.testRun.checkInprogress_on_testbed(node['friendlyname'])
									self.testRun.close()
									systemlocked='false'
									if  node['systemlock']=='true' or  testbed_in_progress:
										nodewithlocked.append(node)
								
									else:
										nodestobechecked.append(node)
										devavail = True
									
								else:
									nodestobechecked.append(node)
									devavail = True
							else:
								nodewithlocked.append(node)
						elif nodeavail[0]!= "SW-HW cap not matching":
							lockeddev = nodeavail[2]
							if int(record['support_device_count']) >1:
								OnlineSecDevices= self.getSecondaryDevicecount(node)
							#if lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1:

							unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
							if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
									nodewithlocked.append(node)
							elif nodeavail[0]!= "SW-HW cap not matching":
									lockeddev = nodeavail[2]
									if int(record['support_device_count']) >1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
									if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):



										nodewithlocked.append(node)
									else:
										pass
					# If device not available in priority node, check in common node
					if devavail!= True:
							if commonnodes!= None:
								y = len(commonnodes)
							else:
								y = 0
							if y!= 0:
								for j in commonnodes:
										node= self.devfarmconvertToDictionary(j)
										swCap=node.get('softwares').split(',')
										
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
										hwCap = node.get('hardwares').split(',')
										nodeavail = self.checknode(record,swCap,hwCap,node)
										if nodeavail[0] == "true":
											nodestobechecked.append(node)
											logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
											devavail = True
										elif nodeavail[0]!= "SW-HW cap not matching":
											lockeddev = nodeavail[2]
											if int(record['support_device_count']) >1:
												OnlineSecDevices= self.getSecondaryDevicecount(node)
											unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
											if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
												nodewithlocked.append(node)
											else:
												pass
					
							if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:

										
										logger.log(1,"No node available required for execution.Send mail to admin","D")
										
					# If no devices are available in both priority and common nodes	
					else:
						if len(nodestobechecked)== 0:
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
									else:
										logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
										
							
				# If no testbed assigned to scrum teams	
				else:
					logger.log(1,"Commonnodes="+str(commonnodes),"D")
					logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y = 0
					logger.log(1,"Length of Commonnodes="+str(y),"D")
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
								hwCap = node.get('hardwares').split(',')
								logger.log(1,"External hwcap:"+str(hwCap),"I")
								nodeavail = self.checknode(record,swCap,hwCap,node)
								logger.log(1,"Node avail="+str(nodeavail[0]),"I")
								if nodeavail[0] == "true":
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"D")
									devavail = True

														
								elif nodeavail[0]!= "SW-HW cap not matching":
									lockeddev = nodeavail[2]
									if int(record['support_device_count']) >1:
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									unlockeddev=self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
									if (lockeddev >= 1 and OnlineSecDevices >= int(record['support_device_count'])-1) or (unlockeddev[0]>=1 and OnlineSecDevices >= int(record['support_device_count'])-1):
										logger.log(1,"Manualmatchfinder:SW-HW cap not matching:lockedev:append locked node","I")
										nodewithlocked.append(node)
									else:
										pass
						if len(nodestobechecked)== 0: 

							logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
							if len(nodewithlocked) != 0:
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(record)
								self.testQueue.close()
							

					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
						
				
#######################################################################################################################################################
			if len(nodestobechecked)== 0:
				if len(nodewithlocked) ==0 :
					if int(role_id) == 1:
						for node in allNodes.get('nodes'):
							lockflagHw = 'false'
							#Check only Online Nodes
						
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Is it Online: "+str(node.get('nodeonlinestatus')),"D")
							if node.get('nodeonlinestatus')=='online'and node.get('nodejenkinsonlinestatus')=='online':
								nodeOnline = True
							
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Node: "+str(node.get('friendlyname')),"D")

								swCap=node.get('softwares').split(',')
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
								hwCap = node.get('hardwares').split(',')
								logger.log(1,"External hwcap:"+str(hwCap),"I")
								#Logic to Handle SW Capabilities
								result=self.findSWCap(record.get('sw_cap').split(','), swCap)
								hwresult=self.findHWCap(record.get('hw_cap').split(','), hwCap)
								logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]: Result of HwCap: "+str(hwresult),"D")
								lockflagHw = 'false'
								foundAllCapNode=False
								foundFewCapNode=False
								noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
								noofunlocked = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
								logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
								if int(record['support_device_count']) >1:	
										noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
										if noofavailsecdev >= int(record['support_device_count'])-1: 
											nodeWithSec.append(node)
											secresult = True
										else:
											secresult = False
								else:
									secresult = True
								if secresult == True:
									nodeWithSec.append(node)
									swCap=node.get('softwares').split(',')
								
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: SW Capabilities: "+str(swCap),"D")
									hwCap = node.get('hardwares').split(',')
									logger.log(1,"External hwcap:"+str(hwCap),"D")
									lockflagHw = 'false'
									#Logic to Handle SW Capabilities
									result=self.findSWCap(record['sw_cap'].split(','), swCap)
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Result of SwCap: "+str(result),"D")
									hwresult=self.findHWCap(record['hw_cap'].split(','), hwCap)
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Result of HwCap: "+str(hwresult),"D")
								
								
								
									if result==0 and hwresult!= 0:
													#Put Node in nodeWithFewSWCap
												
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
													nodeWithFewHWCap.append(node)
													nodeWithAllSWCap.append(node)
									elif result!=0 and hwresult== 0:
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
										nodeWithFewSWCap.append(node)
										nodeWithAllHWCap.append(node)
									elif result!=0 and hwresult!= 0:
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
										nodeWithFewSWCap.append(node)
										nodeWithFewHWCap.append(node)
									elif result == 0 and hwresult==0:
										#Put Node in nodeWithAllSWCap
									
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
									
										nodeWithAllHWCap.append(node)
										nodeWithAllSWCap.append(node)	
										if noofunlocked[0] >= 1:
											priavail= True
										else:
											priavail = False
										if priavail == True:
												nodeWithPri.append(node)								
											
											
										else:
											logger.log(1,"No primary devices available","I")
										
											
								else:
									logger.log(1,"Sufficient secondary dev not available","I")
									
							else:
								nodeOffline = False
								nodeOnline = nodeOnline | nodeOffline

				
					elif len(nodewithlocked) ==0 and int(role_id) != 1:
						if commonnodes!= None:
							y = len(commonnodes)
						else:
							y = 0
						logger.log(1,"Length of Commonnodes="+str(y),"D")
						
						if x==0 and y!=0:
							commonandprionodes=commonnodes
						elif x!=0 and y==0:
							commonandprionodes=prionodes
						elif x!=0 and y!=0:
							commonandprionodes=list(prionodes)
							for k in commonnodes:
								commonandprionodes.append(k)
							commonandprionodes=tuple(commonandprionodes)
						elif x==0 and y==0:
							commonandprionodes=()
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] no node is available","D")	

						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]commonprionodes"+str(commonandprionodes),"D")


						if len(commonandprionodes)==0:
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node is  available for the user'+'\n\n',[])	
						else:

							
							for m in commonandprionodes:
								node= self.devfarmconvertToDictionary(m)
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Is it Online: "+str(node.get('nodeonlinestatus')),"D")
								if node.get('nodeonlinestatus')=='online'and node.get('nodejenkinsonlinestatus')=='online':
									nodeOnline = True
							
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Node: "+str(node.get('friendlyname')),"D")

									swCap=node.get('softwares').split(',')
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] SW Capabilities: "+str(swCap),"I")
									hwCap = node.get('hardwares').split(',')
									logger.log(1,"External hwcap:"+str(hwCap),"I")
									#Logic to Handle SW Capabilities
									result=self.findSWCap(record.get('sw_cap').split(','), swCap)
									hwresult=self.findHWCap(record.get('hw_cap').split(','), hwCap)
									logger.log(1,"[ManualMatchFinder_startProcess_TestBed_AND_DeviceSelected]: Result of HwCap: "+str(hwresult),"D")
									lockflagHw = 'false'
									foundAllCapNode=False
									foundFewCapNode=False
									noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
									noofunlocked = self.checkunlockeddevices(record['product'],record['os'], node['friendlyname'],record)
									logger.log(1,"No of unlocked device:"+str(noofunlocked[0]),"I")
									if int(record['support_device_count']) >1:	
											noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
											if noofavailsecdev >= int(record['support_device_count'])-1: 
												nodeWithSec.append(node)
												secresult = True
											else:
												secresult = False
									else:
										secresult = True
									if secresult == True:
										nodeWithSec.append(node)
										swCap=node.get('softwares').split(',')
								
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: SW Capabilities: "+str(swCap),"D")
										hwCap = node.get('hardwares').split(',')
										logger.log(1,"External hwcap:"+str(hwCap),"D")
										lockflagHw = 'false'
										#Logic to Handle SW Capabilities
										result=self.findSWCap(record['sw_cap'].split(','), swCap)
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Result of SwCap: "+str(result),"D")
										hwresult=self.findHWCap(record['hw_cap'].split(','), hwCap)
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Result of HwCap: "+str(hwresult),"D")
								
								
								
										if result==0 and hwresult!= 0:
											#Put Node in nodeWithFewSWCap
												
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
											nodeWithFewHWCap.append(node)
											nodeWithAllSWCap.append(node)
										elif result!=0 and hwresult== 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithAllHWCap.append(node)
										elif result!=0 and hwresult!= 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithFewHWCap.append(node)
										elif result == 0 and hwresult==0:
											#Put Node in nodeWithAllSWCap
									
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
									
											nodeWithAllHWCap.append(node)
											nodeWithAllSWCap.append(node)	
											if noofunlocked[0] >= 1:
												priavail= True
											else:
												priavail = False
											if priavail == True:
												nodeWithPri.append(node)								
											
											
											else:
												logger.log(1,"No primary devices available","I")
										
											
									else:
										logger.log(1,"Sufficient secondary dev not available","I")
									
								else:
									nodeOffline = False
									nodeOnline = nodeOnline | nodeOffline


























					#######################################################################################################################################################

					#Find Nodes which has all SW Capabilities mentioned in testRecord['sw_cap']
					#If all the Nodes do not have any of the SW Cap, then send EMAIL to Device Farm Admin; Else Continue next Step
					#If only Node found which has some of SW Cap mentioned in testRecord['sw_cap'], then put Job in Queue
					#If Node found which has all SW Capabilities mentioned in testRecord['sw_cap'], then Continue next Step
					logger.log(1,"Nodes with sec:"+str(nodeWithSec),"I")
					logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
					logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
					logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
					logger.log(1,"Node online"+str(nodeOnline),"I")


					

		


 
					if len(nodeWithSec)== 0 and nodeOnline ==True:
							
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has secondary devices required for execution of job'+str(record['script_file'])+'. \nNumber of secondary devices required='+str(record['support_device_count']-1)+'\n\n',[])
					
					
					
					else:
													
							if len(nodeWithAllSWCap)==0  and nodeOnline ==True:
									#Send EMAIL notification to Device Farm Admin
									
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has software capability required for execution of job:'+str(record['script_file'])+"\n Required software capability:"+str(record['sw_cap'])+'\n\n',[])						
									

									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
							
											
							elif len(nodeWithAllHWCap)==0 and nodeOnline==True:
									
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has hardware capability required for execution of job:'+str(record['script_file'])+"\n Required hardware capability:"+str(record['hw_cap'])+'\n\n',[])	
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
							
									pass
							elif len(nodeWithPri)== 0 and nodeOnline ==True:
								productresult = self.checkproduct(record)
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has devices required for execution of job:'+str(record['script_file'])+"Device required:\n"+"Product:"+str(record['product'])+"OS:"+str(record['os'])+str(productresult)+'\n\n',[])
						
			# If nodes available for execution
			if len(nodestobechecked)!=0:
					
					logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Found Node with all SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")                   
					matchdevices=[]                                                                                      
					filteredNodes=[]
					foundAllCapNode=False
					foundFewHWCapNode=False

#######################################################################################################################################################
					#Create Locked Devices's List; so that if any match found from this list, Scheduler can keept Test Job in Queue
					lockedDevicesList=[] 
					seclockedDevicesList=[]
	#######################################################################################################################################################
					logger.log(1,"Node with both HW and SW capability:"+str(nodeWithAllCap),"D")

					matchedSecDeviceCounter = 0
					unlockedSecDevices = 0
					seclockedcount = 0
					count = 0		
						#Get all Online Devices from Selected Nodes from above step
					for node in nodestobechecked:
						
						logger.log(1,"HW capabilities to be checked:"+str(record.get('hw_cap').split(",")),"I")
						lockflagHw =self.inUseHardware_nothingSelected(node.get('friendlyname'),record.get('hw_cap').split(","))
						if lockflagHw!= 'true':
							#Unlocked Devices Counter
							unlockedDevices=0
							foundAllCapNode = True

							inUseDevices=0
							#inUseSecDevices=0
							
							onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
							
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Online Devices for this Node: ","I")
							
							foundAllHWCapDevice=False
							countOfDevices=len(onlineDevices.get('devices'))
							
							#Maintain Device Info for Scheduling purpose 
							deviceList=[]
							secdeviceList=[]
							seclistjob = []
							lockedDevices=[]
							seclockedDevices=[]
							matchedSecDeviceCounter = 0
							unlockedSecDevices = 0
							seclockedcount = 0
							
							matchedSecDeviceCounter=0
							unlockedSecDevices = 0
							


							if int(record['support_device_count']) >1:
								matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
								unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
							seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)

							if countOfDevices==0:
								
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Recieved Empty Device List from Device Farm","D")
								
							for device in onlineDevices.get('devices'):
								
								logger.log(1,device,"D")
								
								if device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')) and device.get('status')=='online':
								#Get Product & OS Information for all selected Online Devices from above step &
								#Select only those Devices, which have matching Product &
								#OS info mentioned in record['product'] & record['os']
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Matching Product & OS","D")
									
									logger.log(1,device.get('name')+" : "+str(record.get('product')),"I")
									
									logger.log(1,str(device.get('version')).split("-")[1]+":"+str(record.get('os')),"I")
									#if device.get('name')==record.get('product') and device.get('version')==record.get('os').split(" ")[1]:Uncomment It********************************************************************************************************************************
									#Logic to check OS Versions
									osFlag=False
									for osIter in record.get('os').split(","):
										
										logger.log(1,osIter.strip(" '"),"D")
										if str(device.get('version')).split("-")[1] == str(osIter.strip(" '")):
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] OS Version Matched: "+osIter.strip(" '"),"D")
											osFlag=True
											#Critical Section
											record['os']=osIter.strip(" '")
											os_version = str(device.get('version')).split("-")[1]
											break

									result=self.checkfordevice(record,device,osFlag)
									if result==True:
										
										product = str(device.get('name'))
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Device Product, OS Matched","D")

													
										#Get Devices which has all HW Capabilities mentioned in 								#record ['hw_cap']
										#If there is no Device found in any Node, then send EMAIL to Device
										#Farm Admin; Else Continue next Step
										
										
										if device.get('secondary')=='false': 
											
											deviceList.append(device)
											
											foundAllHWCapDevice=True
											unlockedDevices=unlockedDevices+1

																
											
									else:
										
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Device Product, OS Not Matched","D")
								elif device.get('locked')=='true' or device.get('flash_status')=='true':
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Device is Locked; So put Device in Locked Devices List","D")
									if device.get('secondary')=='false': 
										inUseDevices=inUseDevices+1
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Matching Product & OS of Primary Locked Device: ","I")
										logger.log(1,device.get('name')+" : "+str(record.get('product')),"D")
									
									#Match Product & OS Version Before putting to List; Don't Put any Locked Device (Want only matching Locked Devices) 
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Matching Product & OS of Locked Device: ","I")
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Device Property : Test Suite Property","I")
									
									logger.log(1,device.get('name')+" : "+str(record.get('product')),"I")
									
									logger.log(1,str(device.get('version')).split("-")[1]+str(record.get('os')),"I")
									if ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
										#Logic to check OS Versions
										osFlag=False
										for osIter in record.get('os').split(","):
											
											logger.log(1,osIter.strip(" '"),"D")
											if str(device.get('version')).split("-")[1] == str(osIter.strip(" '")):
												
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] OS Version Matched: "+str(osIter.strip(" '")),"D")
												osFlag=True
												os_version = str(device.get('version')).split("-")[1]
												break
										
										result=self.checkfordevice(record,device,osFlag)
										if result==True:
											
											product = str(device.get('name'))
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Locked Device's Product, OS Matched","D")
											if device.get('secondary')=='false': 
												lockedDevices.append(device)
											

				#######################################################################################################################################################
										#######################################################################################################################################################
							totalSupportDeviceCount = int(record.get('support_device_count'))
							logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
							if totalSupportDeviceCount <= 1:
								expectedDevicecount = 0
							else:
								expectedDevicecount = totalSupportDeviceCount - 1

						
							logger.log(1,"Expected device count:"+str(expectedDevicecount),"I")
							logger.log(1,"Matched sec device count:"+str(matchedSecDeviceCounter),"I")
							if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Unlocked Primary Devices: "+ str(unlockedDevices),"D")
								unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")
													
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] locked Secondary Device count: "+ str(seclockedcount),"I")
								
								logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] Required Support Devices for Test Execution: "+str(expectedDevicecount),"I")
								#Check testRecord['support_device_count'] info & verify whether Node has sufficient
								#device count for execution
								secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
								if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
									systemlocked='false'
									parallelnodestatus = (node.get('parallelexec')).lower()
									if parallelnodestatus=='false' and node.get('systemlock')=='true':
										systemlocked='true'
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] node locked status"+str(node.get('locked')),"D")
									if node.get('locked')!='True' and  node.get('manualgit')!='True'and systemlocked=='false' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED': 
										
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Add Node to filteredNodes; & Continue Processing of Node","D")
										
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] In Use Primary Devices for Node: "+str(inUseDevices),"I")
										logger.log(1,"[ManualMatchFinder_startProcess_TestBedSelected] In Use Support Devices for Node: "+str(seclockedcount),"I")
										filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicableDevices':unlockedDevices, 'devices':deviceList, 'support_devices': secdeviceList, 'inUseDevices':inUseDevices,'inUseSecDevices':seclockedcount})
									elif node.get('locked')=='True' or node.get('manualgit')=='True' or systemlocked=='true' or node.get('scheduledgit')=='IN_PROGRESS' or node.get('scheduledgit')=='INITIATED':
										logger.log(1,"[ManualMatchFinder_startProcess_Find_TestBed_Device] Node has ongoing git or system is locked","D")
										manualgittestbedlocked.append(node.get('friendlyname'))
									
								else:
									#Reject Node
									pass  
							else:
								#Reject Node
								
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Devices Found from this Node which has All HW Capabilities","D")
				
		#######################################################################################################################################################
							#Add Node & Locked Devices Details to List
							if len(lockedDevices)>0:
								
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Found Matching Locked Devices; So putting into Locked Devices's List","D")
								lockedDevicesList.append({'node': node, 'devices': lockedDevices})

							
	#######################################################################################################################################################
				
						else:
							logger.log(1,"HW in use for node. Check next node","D")
							count= count +1
							continue
							
#################################################################################################################################


					
					logger.log(1,"Count of nodes with HW in use"+str(count),"I")
					if count == len(nodestobechecked):
							logger.log(1,"All external HW in use. Put job in Queue","I")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)	
							self.testQueue.close()
							#If Node found, which has all HW Capabilities
					if foundAllCapNode==True:
						#Process Node further
						#If no Node has sufficient Unlocked Devices for execution, then put Test Job in Queue
						if len(filteredNodes)==0 and len(manualgittestbedlocked)==0:
							#Put Test Job in Queue
							
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node has sufficient Unlocked Devices for execution; SO put the Test Job in  Queue","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)	
							self.testQueue.close()
							pass
						elif len(filteredNodes)==0 and len(manualgittestbedlocked)>0:
							#put test job in queue as no nodes are available and Git is True
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] put test job in queue as no nodes are available and ManualGit is True","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)	
							self.testQueue.close()
							
						else:
							#Process Node further
							
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Filterred Node: ","D")
							
							testJobScheduled=False
							for node in filteredNodes:
								parallelnodestatus = (node.get('node').get('parallelexec')).lower()
								print "Parallel execution status=",parallelnodestatus
								
								logger.log(1,node,"D")
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								QUERY='SELECT priority FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" ORDER BY priority;'
								NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
								lenQueue = len(NewQueueRecord)
								logger.log(1,"Queue priority="+str(NewQueueRecord),"I")
								# Check if any job present in the queue with higher priority #
								if NewQueueRecord!= ():
									minimum= min(NewQueueRecord)
									logger.log(1,"Minimum priority="+str(minimum),"D")
									logger.log(1,"Current priority="+str(record['priority']),"I")
									if int(record['priority']) >= int(minimum[0]):
											self.testQueue.insert(record)
											testJobScheduled = True
											break
										
								self.testQueue.close()
	#######################################################################################################################################################
								if parallelnodestatus=='true':
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Node is Parallel Execution Capable; So Create Jenkins Job for this Test Job & Trigger it on Test Bed|||||||||||||||||||||||||","D")                                                                        
									#Create Jenkins Job for this Test Job & Trigger it on Test Bed
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Trigger Test Job on Device","I")
									
									setUp=JobPreSetup.SetUp()
									
									preSetUP=setUp.doPreSetUp(record)
									if preSetUP[0]==True:
										
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] TestCases.xml file created","D")
										#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
										job=StartJob.JenkinsJob(record, node.get('node'), node.get('devices'),node.get('support_devices') ,preSetUP[1])
										#If Test Job Started; then only put its corresponding Test Record in Running Jobs List
										#jobStatus=job.startProcess()
										#if jobStatus[0]:
										if True:
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job has been successfully started","D")
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job Name: ","I")
											
											


											

											if len(node.get('devices'))!= 0:
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Locking Device: "+node.get('devices')[0].get('serialno'),"D")
												
												lockResult = self.lock_device(nodeip=str(node.get('devices')[0].get('node')), serialno=str(node.get('devices')[0].get('serialno')), user=record.get('user'), operation='lock_device', lockingTool='CLM')
												
												logger.log(1,lockResult,"I")
												
												if record.get('build_xml_location')!='NA':

													flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
												
													if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
														
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Successfully Set flash status as true","D")


												else:
													flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=node.get('devices')[0].get('serialno'))

											if expectedDevicecount>=1:
												if len(node.get('support_devices'))!= 0:
														
														i = 0
														while i < expectedDevicecount:
															seclistjob.append(node.get('support_devices')[i].get('serialno'))
															
															lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
															
															logger.log(1,lockResultsec,"I")
															
															i= i+1		
								
														record['support_devices']=",".join(seclistjob)

												else:
													record['support_devices']=str(seclistjob)
											else:
												record['support_devices']=str(seclistjob)
												lockResultsec = True

											if lockResultsec != False and lockResult != False:
												#Add Test Bed & Device Data to Test Record (For Auto Mode)
												jobStatus=job.startProcess()
												if jobStatus[0]:
												
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Putting Test Bed & Device Details: ","D")
												
													logger.log(1,node.get('node').get('location'),"I")
												
													logger.log(1,node.get('node').get('friendlyname'),"I")
												
													logger.log(1,node.get('devices')[0].get('serialno'),"I")
												
													record['location']=node.get('node').get('location')
													record['test_bed_name']=node.get('node').get('friendlyname')
													record['devices']=node.get('devices')[0].get('serialno')
											
											
													if self.insertIntoRunningJob(record, jobStatus[1]):
													
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job put into Running List","D")
													testJobScheduled=True
													break


												else:
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D") 
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(record)	
													self.testQueue.close()



											else:
												logger.log(1,"Error in locking device. Job put into queue","I")
												#job.removefromjenkins(str(jobStatus[1]),node.get('node').get('friendlyname'))	
												logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","I")

												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												self.testQueue.insert(record)	
												self.testQueue.close()
												


												self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put  the job with script :'+str(record['script_file'])+' in queue'+'\n\n',[])
												testJobScheduled=True
												break
										else:
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")                                                                                                           
											
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] UnLocking Devices after failure in Starting Test Job","I")
											

	#######################################################################################################################################################
								else:
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Node is not Parallel Execution Capable","D")
									#Check whether there is any already ongoing execution on Test Bed
									#If no Ongoing execution then Schedule test Job 
									#& trigger it on Test Bed
									#Else put Test Job in Queue
									
									if node.get('inUseDevices')==0:
										
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")                                                                                                           
										#Create Jenkins Job for this Test Job & 
										#Trigger it on Test Bed
										
										logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Trigger Test Job on Device","I")
										
										#Create Jenkins Job for this Test Job & 
										#Trigger it on Test Bed
										#Create Test Job & Trigger it

										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										
										preSetUP=setUp.doPreSetUp(record)
										if preSetUP[0]==True:
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(record, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
											#If Test Job Started; then only remove its corresponding Test Record from Queue
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:
												
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job has been successfully started","D")
												
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job Name: ","I")
												
												#logger.log(1,jobStatus[1],"I")
												if len(node.get('devices'))!= 0:
														
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Locking Devices before Starting Test Job","D")
													
														
														lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
													

														if record.get('build_xml_location')!='NA':

															flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))

					
												
															if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
																

																logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Successfully Set flash status as true","D")
								

														else:

															flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=node.get('devices')[0].get('serialno'))
												if expectedDevicecount>=1:		
													if len(node.get('support_devices'))!= 0:
															i = 0
															while i < expectedDevicecount:
																seclistjob.append(node.get('support_devices')[i].get('serialno'))
																
																
																lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=record.get('user'), operation='lock_device', lockingTool='CLM')
																i= i+1

															record['support_devices']=",".join(seclistjob)

													else:
														record['support_devices']=str(seclistjob)
												else:
													lockResultsec= True
													record['support_devices']=str(seclistjob)
													
													
												if lockResult != False and lockResultsec != False:
													jobStatus=job.startProcess()
													
													#Add Test Bed & Device Data to Test Record (For Auto Mode)
													if jobStatus[0]:
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Putting Test Bed & Device Details: ","D")
													
														logger.log(1,node.get('node').get('location'),"I")
													
														logger.log(1,node.get('node').get('friendlyname'),"I")
													
														logger.log(1,node.get('devices')[0].get('serialno'),"I")
													
														record['location']=node.get('node').get('location')
														record['test_bed_name']=node.get('node').get('friendlyname')
														record['devices']=node.get('devices')[0].get('serialno')
													
														if self.insertIntoRunningJob(record, jobStatus[1]):
														
															logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test Job put into Running List","D")
														testJobScheduled=True
														break

													else:
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")                                                                                                           
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														self.testQueue.insert(record) 
														self.testQueue.close()
												
														logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] UnLocking Devices after failure in Starting Test Job","I")
														break


												else:
													logger.log(1,"Error in locking device. Job put into queue","D")
													#job.removefromjenkins(str(jobStatus[1]),node.get('node').get('friendlyname'))	
													logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","D")									
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(record)	
													self.testQueue.close()
													testJobScheduled=True
													self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put  the job with script :'+str(record['script_file'])+' in queue'+'\n\n',[])


													break
													
											else:
												
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")                                                                                                           
												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												self.testQueue.insert(record) 
												self.testQueue.close()
												
												logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] UnLocking Devices after failure in Starting Test Job","I")
												
												
	#######################################################################################################################################################
									else:
										matchdevices.append(node.get('devices')) 
										#Put Test Job in Queue
										
										pass
	#######################################################################################################################################################
							#If Test Job is not scheduled for some reason; the look for Locked Devices List.
							# So that if any match found from Locked Devices's List Scheduler can put Job in Queue
							if testJobScheduled==False:
								
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Looking for Locked Devices 1","D")
								if len(lockedDevicesList)>0:
									lockedDevices=self.lookForLockedDevices_NothingSelected(lockedDevicesList, record, "Primary")
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Put Test Job in Queue, as Test Job is not scheduled for some reason","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record) 
									self.testQueue.close()
								
								elif len(seclockedDevicesList)>0:
									seclockedDevices=self.lookForLockedDevices_NothingSelected(seclockedDevicesList, record,"Secondary")
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Put Test Job in Queue, as Test Job is not scheduled for some reason","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record) 
									self.testQueue.close()
								
								elif len(matchdevices)>0:

									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So put Test Job in Manual Queue","D")							
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)	
									self.testQueue.close()
								else:
									#Send EMAIL Notification to Device Farm Admin
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear user,\n\nNo Node found with matching HW Capabilities.Expected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1","D")                                                                                                           
							pass
	#######################################################################################################################################################
					else:
						
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Looking for Locked Devices 2","D")
						if len(lockedDevicesList)>0 and (matchedSecDeviceCounter >= expectedDevicecount):
							logger.log(1,"Inside locked devices list","D")
							lockedDevices=self.lookForLockedDevices_NothingSelected(lockedDevicesList, record,"Primary")
							if lockedDevices==True:
								
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Put Test Job in Queue, as Match found from Locked Devices","D")
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(record)	
								self.testQueue.close()
							else:
								#Send EMAIL Notification to Device Farm Admin
								
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Node found with matching HW Capabilities.Expected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 3","D")

						elif (matchedSecDeviceCounter >= expectedDevicecount) and seclockedcount>0:
							seclockedDevices=self.lookForLockedDevices_NothingSelected(seclockedDevicesList, record,"Secondary")
							logger.log(1,"Inside sec locked devices list","D")
							if seclockedDevices==True:
									
									logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Put Test Job in Queue, as Match found from Locked Devices","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(record)	
									self.testQueue.close()
							else:
								
								#Send EMAIL Notification to Device Farm Admin
								
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Node found with matching HW Capabilities.Expected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 3","D")
		
						elif (matchedSecDeviceCounter < expectedDevicecount) and seclockedcount==0:
							
							logger.log(1,"Sufficient support devices not found in this node.","D")
							if seclockedDevices==True:
									
								
								#Send EMAIL Notification to Device Farm Admin
								
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Node found with matching number of support devices.Expected number of support devices:'+str(expectedDevicecount)+"\n\n",[])
								logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 3","D")
		
						elif lockflagHw == 'true':
						
								logger.log(1,"HW in use. Job put in Queue","D")
								
								
						elif (nodeWithAllSWCap!= 0) and (nodeWithAllCap==0):
							#Send EMAIL Notification to Device Farm Admin
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Node found with matching HW Capabilities.Expected HW capabilities'+str(record.get('hw_cap'))+"\nExpected product:"+str(record.get('product'))+"\nExpected OS version:"+str(record.get('os'))+"\n\n",[])
							
							logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 2","D")                                                                                                           
						pass
							
					
							
					

#######################################################################################################################################################
			
#######################################################################################################################################################
		except Exception, e:
			
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.testRun.close()
			#self.buildInfo.close()
			self.testQueue.close()
			logger.log(1,"ManualMatchFinder startProcess_NothingSelected EXCEPTION"+str(e),"E")
		finally:
			
			self.lock.release()	
			logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Lock Releasing","I")

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Continuously check TBL_TEST_DETAILS table for incomming Data to be processed				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def checkTestTable(self):

		try:
			#Create Instance for Test Detail DB Interface 
			while True:

				self.testmanual=DB_Interface.Test_Manual_Record(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						
				QUERY='SELECT COUNT(*) FROM TBL_MANUAL_RECORD;'
				
				result=self.testmanual.execute(QUERY, "SELECT")
				self.testmanual.close()
				
				
				if result[0]>0L:
				
					
					logger.log(1,"[Manual MatchFinder_checkTestTable] Record is there to Process in Test Details Table","D")
					self.startProcess()
					
				
					logger.log(1,"[Manual MatchFinder_checkTestTable] One Test Detail Processed","I")
					time.sleep(0.1)
				else:
					
                    
					time.sleep(5)
				
								

		except Exception, e:
			
			logger.log(1,"[Manual MatchFinder_checkTestTable]"+str(e),"E")

#######################################################################################################################################################
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Continuously check TBL_MANUAL_RECORD table for incomming Data to be processed				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess(self):
	
		
		try:
			#Create Instance for Test Detail DB Interface 
						
			self.testmanual=DB_Interface.Test_Manual_Record(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
	
			#Get First Test Detail
			testRecord=self.testmanual.pop()
			self.testmanual.close()
	
			logger.log(1, "[Manual MatchFinder_startProcess] Test Record Popped: ","I")
			logger.log(1, "[Manual MatchFinder_startProcess]"+str(testRecord),"I")
			
			record=self.convertToDictionary(testRecord)
			if record['device_required']=='true':
			
				if record['test_bed_name']=='NA' and record['devices']=='NA':
					
					logger.log(1,"[ManualMatchFinder_startProcess] Test Bed & Devices not Provided By User","D")
				
					self.startProcess_NothingSelected(record)
				elif record['test_bed_name']!='NA' and record['devices']=='NA':
					
					logger.log(1,"[ManaulMatchFinder_startProcess] Test Bed provided By User","D")
					self.startProcess_TestBedSelected(record)

				elif record['test_bed_name']!='NA' and record['devices']!='NA':
					
					logger.log(1,"[ManaulMatchFinder_startProcess] Test Bed provided By User","D")
					self.startProcess_TestBed_AND_DeviceSelected(record)
				else:
					
					logger.log(1,"[ManaulMatchFinder_startProcess] Not Sufficient Information for Test Bed or Test Location","D")
			else:
				if record['test_bed_name']=='NA':
					
					logger.log(1,"[ManualMatchFinder_startProcess] Test Bed & Devices not Provided By User_device req false","D")
				
					self.startProcess_System_not_selected(record)
				else:
					
					logger.log(1,"[ManualMatchFinder_startProcess] Test Bed & Devices Provided By User_device req false","D")
				
					self.startProcess_SystemSelected(record)

		
		except Exception, e:
			
			self.testmanual.close()
			logger.log(1,"[ManualMatchFinder_startProcess]"+str(e),"E")


##########################################################################################################################

#############################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Convert Test Record format from Tuple to Dictionary							#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	Tuple		Test Record Tuple							#
    	#########################################################################################################
	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	Dictionary	Test Record Dictionary							#
	# None		Object		Negative Return								#	
    	#########################################################################################################
	def convertToDictionary(self, tupleData):
		try:
			
			logger.log(1,"[ManualMatchFinder_checkTestTable] Tuple Data: "+str(tupleData),"I")
			
			record={
				'build_mode':tupleData[0], 
				'build_kind':tupleData[1], 
				'build_number':tupleData[2], 
				'product':tupleData[3],
				'os':tupleData[4],
				'component':tupleData[5],
				'tag':tupleData[6],
				'test_plan':tupleData[7],
				'selected_tc_ids':tupleData[8],
				'selected_tc_titles':tupleData[9],
				'script_file':tupleData[10],
				'sw_cap':tupleData[11],
				'hw_cap':tupleData[12],
				'est_runtime':tupleData[13],
				'support_device_count':tupleData[14],
				'mode':tupleData[15],
				'location':tupleData[16],
				'test_bed_name':tupleData[17],
				'devices':tupleData[18],
				'build_xml_location':tupleData[19],
				'user':tupleData[20],
				'creation_timestamp':tupleData[21],
				'flash':tupleData[22],
				'email_status':tupleData[23],
				'email_reason':tupleData[24],
				'build_variant':tupleData[25],
				'scrum_name':tupleData[26],
				'priority':tupleData[27],
				'pilot_tested':tupleData[28],
				'starting_timestamp':tupleData[29],
				'device_required':tupleData[30],
				'wantechnology':tupleData[31],
				'hardwarerev':tupleData[32],
				'scan_engine':tupleData[33],
				'uniquejob_name':tupleData[34]
				}
			
			return record
		except Exception, e:
			
			logger.log(1,str(e),"E")
			return None
#######################################################################################################################################################



	#################################################################################################################
	# SYNOPSIS:													#
    	# Find match for Test Record for which User has  provided Test Bed for execution of non mobile testinf          #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	Dictionary	Test Record									#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# NA														#
    	#################################################################################################################	

	def startProcess_SystemSelected(self, testRecord):

		try:
			####################
			#####File system lock
			#####################	
			
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
			scrum_teamname= str(testRecord['scrum_name'])
			user_name = str(testRecord['user'])
			logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
			if str(scrum_teamname) == "NA":
				priority = self.ScrumDetails.getPriority("System Test", "manual")
			else:
				scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
				if scrumpriotablecheck == 1:
					priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
					if priority == None:
						priority = self.ScrumDetails.getPriority("System Test", "manual")
				else:
					priority = self.ScrumDetails.getPriority("System Test", "manual")
			logger.log(1,"Priority of job="+str(priority),"I")
			testRecord['priority'] = int(priority)		
			self.ScrumDetails.close()
		


			record=testRecord
			logger.log(1,"Manual_MatchFinder_startProcess_System_selected TestRun ","I")
			self.lock.acquire()
			logger.log(1,"[Manual_MatchFinder_startProcess_System_selected]: Lock Locking","I")
			
			logger.log(1,"[Manual_MatchFinder_startProcess_System_selected]: Test Suite SW Capabilities: ","I")
			
			logger.log(1,"1111111111111111"+str(testRecord),"I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			foundAllHWCapNode=False
			flag=False
			nodeWithFewHWCap =[]
			nodeWithAllCap = []
			nodeWithFewSWCap = []
			logger.log(1,"[Manual_MatchFinder_startProcess_System_selected]: Test Suite SW Capabilities: "+str(testRecord),"I")
			user_name = str(record.get('user'))
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			role_id = self.ScrumDetails.getroleid(user_name)
			logger.log(1,"[Manualmatchfinder_startProcess_SystemSelected]Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(record['scrum_name'])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"[Manualmatchfinder_startProcess_SystemSelected] Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"[Manualmatchfinder_startProcess_SystemSelected] Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()

			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
					lockflag='False'
					
					if node.get('location')==testRecord["location"] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Location Matched: "+str(testRecord["location"])+str(testRecord["test_bed_name"])+str(node.get('friendlyname')),"D")
						if node.get('friendlyname')==testRecord["test_bed_name"]:
							swCap=node.get('softwares').split(',')
							result=self.findSWCap(testRecord["sw_cap"].split(','), swCap)
							if result==1:
								#Put Node in nodeWithFewSWCap
								
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Few Test Suite SW Capabilities Found in this Node","D")
								nodeWithFewSWCap.append(node)
								#drop the job
							elif result==2:
							
					
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear user,\n\nSoftware capabilities not matching in the reqested testbed: '+str(testRecord["test_bed_name"])+' for script:'+str(testRecord["script_file"])+'\nExpected software capabilities: '+str(testRecord["sw_cap"])+'\n\n',[])
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")

					
							elif result == 0 :
								#Put Node in nodeWithAllSWCap
								
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] All Test Suite HW Capabilities Found in this Node","D")
								foundAll=True
								foundFew=False
								nodeWithAllCap.append(node)
		
		
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] All Test Suite SW Capabilities Found in this Node","D")
							if len(nodeWithAllCap)!=0:
								
								logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Found Nodes with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
								for node in nodeWithAllCap:
									if node.get('systemlock')=='true' or node.get('locked')=='True' or  node.get('manualgit')=='True' or  node.get('scheduledgit')=='IN_PROGRESS' or node.get('scheduledgit')=='INITIATED': 
										#put job in queue if test bed is already locked by other job
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										lockflag='True'
										break
							logger.log(1,"Node with all SW capability:"+str(nodeWithAllCap),"D")
							if  lockflag!='True' and node.get('friendlyname')==testRecord["test_bed_name"] and len(nodeWithAllCap)!=0:
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									pass
									#directly trigger a job on test bed and locked the test bed 
									self.systemjobtrigger(testRecord,node)
									jobtriggered= True
									break


								else:
									#parrallel exec is false check whther any job is running on the test bed
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										#job is running on the test bed so put job into queue with email notification
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										break
									else:
										pass
										#no job is running trigger the job.
										self.systemjobtrigger(testRecord,node)
										break


						else:
							logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Friendlyname not Matched: "+str(testRecord["test_bed_name"]),"D")

					else:
						
						logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Test Bed Location not Matched: "+str(testRecord["location"])+" or requested node not online","D")

			else:
				lockflag= 'False'
				nodematchingallswcap="false"
				foundNode= False
				foundincommonNode =False
				logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Prionodes="+str(prionodes),"I")
				if prionodes!= None:
						x = len(prionodes)
				else:
						x = 0	
						
				logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Length Prionodes x="+str(x),"I")

				if x != 0:
					
					logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Testbeds have been allocated to the scrum team :","I")#testRecord[14]?
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						if node.get('friendlyname')== testRecord["test_bed_name"] and node.get('location')==testRecord["location"]:
							foundNode = True
							nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
							
			
					


						if nodematchingallswcap== "true" and foundNode == True:
							nodeWithAllCap.append(node)
						elif nodematchingallswcap== "false" and foundNode == True:
							#send mail not matching sw
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear user,\n\nSoftware capabilities not matching in any node for script:'+str(testRecord["script_file"])+'.\nExpected software capabilities:'+str(testRecord["sw_cap"])+'\n\n',[])
							pass

				if x==0 or foundNode==False:
					for i in commonnodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						if node.get('friendlyname')== testRecord["test_bed_name"] and node.get('location')==testRecord["location"]:
							foundincommonNode = True
							nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
							

					


						if nodematchingallswcap== "true" and foundincommonNode == True:
							nodeWithAllCap.append(node)
						elif nodematchingallswcap== "false" and foundincommonNode == True:
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear user,\n\nSoftware capabilities not matching in any node for script:'+str(testRecord["script_file"])+'.\nExpected software capabilities:'+str(testRecord["sw_cap"])+'\n\n',[])
							pass

				if foundincommonNode==False and foundNode==False:
					logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] No node is found","D")
					pass
				if len(nodeWithAllCap)!=0:
					
					logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] Found Nodes with all SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
					for node in nodeWithAllCap:
						logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] node"+str(node),"D")
						logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] node"+str(node.get('systemlock')),"I")
						if node.get('systemlock')=='true' or node.get('locked')=='True' or  node.get('manualgit')=='True' or  node.get('scheduledgit')=='IN_PROGRESS' or node.get('scheduledgit')=='INITIATED': 
							#put job in queue if test bed is already locked by other job
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(record)
							self.testQueue.close()
							lockflag='True'
							break
						else:
							logger.log(1,"Manual_MatchFinder_startProcess_System_selected:Node with all SW capability:"+str(nodeWithAllCap),"D")
							if  lockflag!='True' and node.get('friendlyname')==testRecord["test_bed_name"] and len(nodeWithAllCap)!=0:
								
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									self.systemjobtrigger(testRecord,node)
									logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] job triggered with parrel; exec true ","D")
									pass
									#directly trigger a job on test bed and locked the test bed 



								else:
									#parrallel exec is false check whther any job is running on the test bed
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										#job is running on the test bed so put job into queue with email notification
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(record)
										self.testQueue.close()
										logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] job put into queue; exec false and job running on test bed: ","D")
									else:
										#no job is running trigger the job.
										self.systemjobtrigger(testRecord,node)
										logger.log(1,"[Manual_MatchFinder_startProcess_System_selected] job triggered with parrel; exec false and no job running on test bed: ","D")
										pass


			


		except Exception, e:
			
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.testQueue.close()
			self.testRun.close()
			logger.log(1,"Manual_MatchFinder_startProcess_System_selected exception"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[Manual_MatchFinder_startProcess_System_selected]: Lock Releasing","I")
######################################################################################################################################

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find match for Test Record for which User has not provided Test Bed for execution of non mobile testing           #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record									#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# NA														#
    	#################################################################################################################	
	def startProcess_System_not_selected(self, testRecord):
		try:
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			
			scrum_teamname= str(testRecord['scrum_name'])
			user_name = str(testRecord['user'])
			logger.log(1,"Scrum team name of user="+str(scrum_teamname),"I")
			if str(scrum_teamname) == "NA":
				priority = self.ScrumDetails.getPriority("System Test", "manual")
			else:
				scrumpriotablecheck= self.ScrumDetails.scrumnamepriocheck(scrum_teamname)
				if scrumpriotablecheck == 1:
					priority = self.ScrumDetails.getPriority(scrum_teamname, "manual")
					if priority == None:
						priority = self.ScrumDetails.getPriority("System Test", "manual")
				else:
					priority = self.ScrumDetails.getPriority("System Test", "manual")
			logger.log(1,"Priority of job="+str(priority),"I")
			testRecord['priority'] = int(priority)		
			self.ScrumDetails.close()
	
	
			record=testRecord
			logger.log(1," Manualmatchfinder_startProcess_System_not_selected TestRun ","I")
			self.lock.acquire()
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]: Lock Locking","I")
			
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]: Test Suite SW Capabilities: ","I")
			
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			foundAllHWCapNode=False
			flag=False
			nodeWithFewHWCap =[]
			nodeWithAllCap = []
			nodeWithFewSWCap = []
			nodeWithAllSWCap=[]
			nodeWithAllCap_prio=[]
			nodeWithAllCap_locked=[]
			nodeOffline = False
			nodeOnline = False
			foundAll=False
			foundFew=False
			lockflag='False'
			jobtriggered=False
			user_name = str(record.get('user'))
			self.ScrumDetails=DB_Interface.CLM_Scrum_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			role_id = self.ScrumDetails.getroleid(user_name)
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]Role id of user="+str(role_id),"I")
			self.ScrumDetails.close()
			self.devicefarmdb = DB_Interface.devicefarm()
			
			prionodes= self.devicefarmdb.getprionodes(record['scrum_name'])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()

			if int(role_id) == 1:
				for node in allNodes.get('nodes'):
				
				
					if  node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online':
						
						nodeOnline = True
						logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Node: "+str(node.get('friendlyname')),"D")
						swCap=node.get('softwares').split(',')
						
						logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] SW Capabilities: "+str(swCap),"I")
						result=self.findSWCap(testRecord["sw_cap"].split(','), swCap)
						lockflag='False'
						if result==0:
							#Put Node in nodeWithAllSWCap
							
							logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] All Test Suite SW Capabilities Found in this Node","D")
							foundAll=True
							foundFew=False
							nodeWithAllSWCap.append(node)
							logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Test Bed all sw cap matched: "+str(nodeWithAllSWCap),"D")
						elif result==1:
							#Put Node in nodeWithFewSWCap
							
							logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Few Test Suite SW Capabilities Found in this Node","D")
							foundFew=True
							nodeWithFewSWCap.append(node)
						elif result==2:
							foundAll=False
							foundFew=False
						
							logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")

					else:
						logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Test Bed is offline: "+str(node.get('friendlyname')),"D")
				
				if len(nodeWithAllSWCap)==0:
					#no node found with all sw put job into queue
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear user,\n\nSoftware capabilities not matching in any node for script:'+str(testRecord["script_file"])+'.\nExpected software capabilities:'+str(testRecord["sw_cap"])+'\n\n',[])
					logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
				else:
					filteredNodes_matched_inprogress=[]
					jobtriggered= False
					logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node with all capa"+str(nodeWithAllSWCap),"D")
					for node in nodeWithAllSWCap:
						if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('systemlock')!='true' and node.get('scheduledgit')!='INITIATED': 
							lockflag='False'
							logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node with is free no git in progress"+str(node),"D")
							parallelnodestatus = node.get('parallelexec').lower()
							if parallelnodestatus=='true':
								#trigger the job
								logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node has parrel node status true trigger a job"+str(node),"D")
								self.systemjobtrigger(testRecord,node)
								jobtriggered= True
								break
					
							else:
								self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
								self.testrun.close()
								if inprogressstatus:
									filteredNodes_matched_inprogress.append(str(node.get('friendlyname')))
									logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node has parrel node status FALSE AND HAS A IN PROGRESS job"+str(node)+str(filteredNodes_matched_inprogress),"D")
							
								else:
									logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node has parrel node status FALSE AND HAS No IN PROGRESS job"+str(node),"D")
									#trigger the job
									self.systemjobtrigger(testRecord,node)
									jobtriggered= True
									break
							
					if jobtriggered==False:
						logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Node with all capa but job no triggered put into queue"+str(nodeWithAllCap),"D")
						#no matching test bed is free so put job into queue
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(record)
						self.testQueue.close()

			else:
				
				if prionodes!= None:
					x = len(prionodes)
				else:
					x = 0
				logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Length Prionodes x="+str(x),"I")
				if x != 0:
					logger.log(1,"Manualmatchfinder_startProcess_System_not_selected:Testbeds have been allocated to the scrum team :","D")#testRecord[14]?
					for i in prionodes:
						node= self.devfarmconvertToDictionary(i)
						swCap=node.get('softwares').split(',')
						nodematchingallswcap = self.checksystem(testRecord,swCap,node)
						if nodematchingallswcap== "true" :
							nodeWithAllCap_prio.append(node)
				
					if len(nodeWithAllCap_prio)==0:
				
						logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Not a single SW Capability found in any Node from prioriy nodes;","D")
					else:
					
						for node in nodeWithAllCap_prio:
							if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED': 
								parallelnodestatus = node.get('parallelexec').lower()
								if parallelnodestatus=='true':
									#trigger the job and check whether test bed is locked or not
									if (str(node.get('systemlock')))!='true':
										self.systemjobtrigger(testRecord,node)
										jobtriggered = True
										break
									else:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))
					
								else:
									self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
									self.testrun.close()
									if inprogressstatus:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							
									else:
										#trigger the job and check whether test bed is locked or not 
										if (str(node.get('systemlock')))!='true':
											self.systemjobtrigger(testRecord,node)
											jobtriggered= True
											break
										else:
											nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							else:
								logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]: Node has active manual git ","D")
				
			
				if x==0 or jobtriggered==False:
					
						for i in commonnodes:
							node= self.devfarmconvertToDictionary(i)
							swCap=node.get('softwares').split(',')
							nodematchingallswcap = self.checksystem(testRecord,swCap,node)
							if nodematchingallswcap== "true" :
								nodeWithAllCap.append(node)
				
						if len(nodeWithAllCap) ==0 and len(nodeWithAllCap_prio)==0:
				
							logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_SW_Cap'],'Dear user,\n\nSoftware capabilities not matching in any node for script:'+str(testRecord["script_file"])+'.\nExpected software capabilities:'+str(testRecord["sw_cap"])+'\n\n',[])





							#send email notification
						elif len(nodeWithAllCap)!=0 and jobtriggered==False:
								for node in nodeWithAllCap:
									if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED': 
										parallelnodestatus = node.get('parallelexec').lower()
										if parallelnodestatus=='true':
										#trigger the job and check whether test bed is locked or not
											if (str(node.get('systemlock')))!='true':
												self.systemjobtrigger(testRecord,node)
												jobtriggered = True
												break
											else:
												nodeWithAllCap_locked.append(str(node.get('friendlyname')))
					
										else:
											self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
											self.testrun.close()
											if inprogressstatus:
												nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							
											else:
												#trigger the job and check whether test bed is locked or not 
												if (str(node.get('systemlock')))!='true':
													self.systemjobtrigger(testRecord,node)
													jobtriggered= True
													break
												else:
													nodeWithAllCap_locked.append(str(node.get('friendlyname')))
									else:
										logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]: Node has active manual git ","D")

				if len(nodeWithAllCap_locked)!=0 and jobtriggered==False:
					self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
					self.testQueue.insert(record)
					self.testQueue.close()
					logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]:Nodes are locked put job into queue ","D")		
				elif (len(nodeWithAllCap_prio)!=0 or len(nodeWithAllCap)!=0) and jobtriggered==False:
					self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
					self.testQueue.insert(record)
					self.testQueue.close()
					logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]:Nodes are locked due to git put job into queue ","D")
					



		except Exception, e:
			
			self.ScrumDetails.close()
			self.devicefarmdb.close()
			self.testQueue.close()
			self.testRun.close()
			
			logger.log(1,"Manualmatchfinder_startProcess_System_not_selected"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected]: Lock Releasing","I")

#################################################################################################################
	# SYNOPSIS:													#
    	# Trigger job for execution of non mobile testing           #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details									#
	#################################################################################################################
    	# OUTPUT DATA:													#
	# True	Positive return
	# False	 Negative return
    	#################################################################################################################	

	def systemjobtrigger(self,testRecord,node):
		try:
			logger.log(1,"[MatchFinder_systemjobtrigger] ","D")
			nodename=str(testRecord["test_bed_name"])
			print nodename
			logger.log(1,"[MatchFinder_systemjobtrigger] nodename "+str(nodename),"I")
			logger.log(1,"[MatchFinder_systemjobtrigger] testRecord "+str(testRecord),"I")
			setUp=JobPreSetup.SetUp()
			preSetUP=setUp.doPreSetUp(testRecord)
			logger.log(1,"[MatchFinder_systemjobtrigger] preSetUP "+str(preSetUP),"I")
			print preSetUP
			if preSetUP[0]==True:
				
				logger.log(1,"[MatchFinder_systemjobtrigger] TestCases.xml file created","D")
				#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start job testRecord"+str(testRecord),"I")
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start job node"+str(node),"I")
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start preSetUP[1]"+str(preSetUP[1]),"I")
				job=StartSystemJob.systemjob(testRecord, node, preSetUP[1])
				#If Test Job Started; then only remove its corresponding Test Record from Queue
				jobStatus=job.startProcess()
				logger.log(1,"[MatchFinder_systemjobtrigger] jobStatus"+str(jobStatus),"I")
				if jobStatus[0]:
					
					logger.log(1,"[systemjobtrigger] System Test Job has been successfully started","D")
					
					logger.log(1,jobStatus[1],"I")
					self.devicefarm=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
					self.devicefarm.updatesystemlock(str(node.get('friendlyname')),status="true")
					self.devicefarm.close()
					#lock the test bed
					testRecord['location']=node.get('location')
					testRecord['test_bed_name']=node.get('friendlyname')
					testRecord['support_devices']='NA'

					
					if self.insertIntoRunningJob(testRecord, jobStatus[1]):
						
						logger.log(1,   "[MatchFinder_systemjobtrigger] Test Job put into Running List","D")
			return True


		except Exception, e:
			
			self.devicefarm.close()
			logger.log(1,"Match_finder_systemjobtrigger Exception"+str(e),"E")	
			return False

#################################################################################################################
	# SYNOPSIS:													#
    	# Check system capabilities for execution of non mobile testing  job         #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details	
	# swcap 	List		Software capabilities expected								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True	Positive return
	# False	 Negative return 														#
    	#################################################################################################################	
	def checksystem(self, testRecord,swcap,node={}):
		try:
			logger.log(1,"Inside checksystem","I")
			result=self.findSWCap(testRecord["sw_cap"].split(','), swcap)
			if result == 0:
				checknode = "true"
				logger.log(1,"Manual_matchfinder:Inside checksystem,sw cap matching for node"+str(node['friendlyname']),"I")
			else:
				checknode = "false"
				logger.log(1,"Manual_matchfinder:Inside checksystem,sw cap not matching for node"+str(node['friendlyname']),"I")
			logger.log(1,"Manual_matchfinder:Inside checksystem,sw cap not matching for node"+str(node['friendlyname'])+str(checknode),"I")
			return checknode

		except Exception, e:
			
			checknode = "false"
			logger.log(1,"Manual_matchfinder_checksystem Exception"+str(e),"E")	
			return checknode
#################################################################################################################
	# SYNOPSIS:													#
    	# Check device capabilities       #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	Dictionary	Test Record
	# device 	Dictionary	Device details	
	# osFlag 	Boolean		status of device os-matching(true), not matching(false) 								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True 	Positive return
	# False	Negative return														#
    	#################################################################################################################	


	def checkfordevice(self,record,device,osFlag):
		try:
			result=False
			if record.get('wantechnology')=='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"Manual_matchfinder:check for device ,all are any","I")
				if  device.get('name')==record.get('product') and osFlag:
					logger.log(1,"Manual_matchfinder:check for device ,all are any,matched","I")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"Manual_matchfinder:check for device ,scan engine not  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"Manual_matchfinder:check for device ,scan engine not  any,matched","I")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"Manual_matchfinder:check for device ,hardrev not  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('revversion')==record.get('hardwarerev'):
					logger.log(1,"Manual_matchfinder:check for device ,hardrev not  any,matched","I")
					result=True
				else:
					result=False
		
			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"Manual_matchfinder:check for device ,wantechnology not  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('wantechnology')==record.get('wantechnology'):
					logger.log(1,"Manual_matchfinder:check for device ,wantechnology not  any,matched","I")
					result=True
				else:
					result=False
			elif record.get('wantechnology')=='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"Manual_matchfinder:check for device ,wantechnology  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"Manual_matchfinder:check for device ,wantechnology  any,matched","I")
					result=True
				else:
					result=False

			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')=='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"Manual_matchfinder:check for device ,hardwarerev  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('wantechnology')==record.get('wantechnology') and device.get('scanengine')==record.get('scan_engine'):
					logger.log(1,"Manual_matchfinder:check for device ,hardwarerev  any,matched","I")
					result=True
				else:
					result=False
			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')=='Any':
				logger.log(1,"Manual_matchfinder:check for device ,hardwarerev  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine'):
					result=True
				else:
					result=False
			elif record.get('wantechnology')!='Any' and  record.get('hardwarerev')!='Any' and  record.get('scan_engine')!='Any':
				logger.log(1,"Manual_matchfinder:check for device ,no  any","I")
				if  device.get('name')==record.get('product') and osFlag and device.get('revversion')==record.get('hardwarerev') and device.get('scanengine')==record.get('scan_engine') and device.get('wantechnology')==record.get('wantechnology'):
					logger.log(1,"Manual_matchfinder:check for device ,no  any,matched","I")
					result=True
				else:
					result=False

			else:
					result=False
			logger.log(1,"Manual_matchfinder:check for device ,result"+str(result),"I")
			return result



		except Exception, e:
			print str(e)
			logger.log(1,"Exception:[Manual_matchfinder]:checkdevice"+str(e),"E")
			return None





#########################################################################################################
# SYNOPSIS:												#
# Starting point of execution for Module								#
#########################################################################################################
if __name__=='__main__':
	m=ManualMatch()
	m.checkTestTable()
	#m.startProcess()
