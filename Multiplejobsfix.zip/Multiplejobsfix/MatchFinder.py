##########################################################################################################
# Name Of File: MatchFinder.py										 #
# Author: Vinayak Wagh                                                                                   #
# Purpose Of File: Provide Functional Interface for finding match for Test Record in Auto Mode	         #
##########################################################################################################
# History:                                                                                               #
# Date                   Author                  Changes                                                 #
# 19/03/2016             Vinayak Wagh            Initial Creation                                        #
##########################################################################################################
import DeviceFarmInfo
import CLMEmailNotification
import sys, time,json,os
from lockfile import LockFile

with open(os.environ['PYTHONPATH'].split(":")[0]+'/config.json')as json_data:
		Config = json.load(json_data)
sys.path.insert(0, (Config['CONFIG_PATH']+"/code/db"))

import DB_Interface, unicodedata
sys.path.insert(0, (Config['CONFIG_PATH']+"/code/jenkins_job"))

import StartJob, JobPreSetup
import LogDictUtility
import datetime
import urllib
import urllib2
import StartSystemJob
from datetime import datetime
logger=LogDictUtility.LogGenerate()

#########################################################################################################
# SYNOPSIS:												#
# 1. Find match for Test Record in Auto Mode								#
# 2. If match not found; put Test Record in Queue							#
#########################################################################################################
class Match():
	global logger
	#########################################################################################################
	# SYNOPSIS:												#
    	# Initialisation function										#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def __init__(self):
		self.testDetails=None
		self.nodeNames=[]
		self.testQueue=None
		self.deviceFarm=None
		self.testRun = None
		
		self.lock=LockFile(Config['CONFIG_PATH']+"/lockfiles/lock.txt")
		self.email = CLMEmailNotification.EmailNotification()
		self.subject = Config['E-mail_Subject']

#############################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# 1. Insert Test Record into Running Test Record's Table along with JobName				#
    	# 2. Put flash_status & test_status for corresponding JobName						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dictRecord	Dictionary	Test Record to put into Table						#
    	# jobName	String		Job name of corresponding Test Record					#
    	#########################################################################################################
	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def insertIntoRunningJob(self, dictRecord, jobName):

		#self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
		try:	
			record={}
			record=dictRecord
			
			record['job_name']=jobName
			logger.log(1,"MatchFinder_insertIntoRunningJob]job_name "+str(jobName),"I")
			logger.log(1,"MatchFinder_insertIntoRunningJob]device required "+str(record.get('device_required')),"I")
			if record.get('device_required')=='true':
				if record.get('build_xml_location')!='NA':
					record['flash_status']="IN_PROGRESS"
					record['test_status']="NOT_STARTED"
				
					starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
					starting_timestamp=str(starting_times)
					logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:flash_status:starting_timestamp device required true"+str(starting_timestamp),"I")
					record['starting_timestamp']=str(starting_timestamp)
					logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:flash_status:starting_timestamp:in record device required true"+str(starting_timestamp),"I")
				elif record.get('build_xml_location')=='NA':
					record['flash_status']="NO_FLASH"
					record['test_status']="IN_PROGRESS"
					starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
					starting_timestamp=str(starting_times)
					logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:test_status:starting_timestamp device required true"+str(starting_timestamp),"I")
					record['starting_timestamp']=str(starting_timestamp)	
					logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:test_status:starting_timestamp:in record device required true "+str(starting_timestamp),"I")

			elif record.get('device_required')=='false':
				record['flash_status']="NO_FLASH"
				record['test_status']="IN_PROGRESS"
				starting_times=datetime.utcnow().strftime('%m-%d-%y %H:%M:%S.%f')[:-3]
				starting_timestamp=str(starting_times)
				logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:test_status:device required false starting_timestamp "+str(starting_timestamp),"I")
				record['starting_timestamp']=str(starting_timestamp)	
				logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:test_status:starting_timestamp:in record device required false"+str(starting_timestamp),"I")
			
	

	
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])				
			self.testRun.insert(record)
			self.testRun.close()
			logger.log(1,"MatchFinder_insertIntoRunningJob]job_name:insert record","I")
			return True
		except Exception, e:
			
			logger.log(1,str(e),"E")
			return False

		#finally:
			#self.testRun.close()

#############################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match SW Capabilties of Test Bed with Test Jobs SW Capabilities					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsSW		List		Test Record's SW Capabilities		 				#
    	# nodeSW	List		Test Bed's SW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################
	def findSWCap(self, tsSW, nodeSW):
		count=len(tsSW)
		finalCount=0
		for i in tsSW:
			
			for j in nodeSW:
				
				if i.strip(' ')==j.encode('ascii', 'ignore'):
					finalCount=finalCount+1
					
					break
		if finalCount==count and finalCount!=0:
			return 0
		elif finalCount<count and finalCount!=0:
			return 1
		elif finalCount==0:
			return 2

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match HW Capabilties of Device with Test Jobs HW Capabilities						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tsHw		List		Test Record's HW Capabilities		 				#
    	# nodehwCap	List		Test Bed's HW Capabilities						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# 0		Integer		Positive Return								#
	# 1,2		Integer		Negative Return								#
    	#########################################################################################################
	def findHWCap(self, tsHw, nodehwCap):
		try:
			hwCapCount=len(tsHw)
			counter=0
			logger.log(1,"tshw cap"+str(tsHw),"I")
		
			logger.log(1,"[MatchFinder_findHWCap] External HW Dependencies Matching","I")
			if tsHw[0] =='NA': ####Check what happens when hw cap is empty 
				logger.log(1,"Test job requires no external hardware","D")
				return 0
				
			if len(tsHw)!= 0 and tsHw[0] !='NA':
				logger.log(1,"Test job requires atleast 1 external hardware","D")
				for i in tsHw:
					
					if len(nodehwCap)!= 0:
						logger.log(1,"Node has atleast 1 external hardware capacity","D")
						for j in nodehwCap:
							logger.log(1,"i"+str(i.strip(' ')),"I")
							
							if i.strip(' ')==j.encode('ascii', 'ignore'):
								counter=counter+1
								
								break
					else:
						logger.log(1,"Node does not support atleast 1 external hardware capacity, but job requires it","D")
						return 2

				if counter==hwCapCount:
					
					logger.log(1,"[MatchFinder_findHWCap] All HW Capabilities Matched","D")
					return 0
					
				
				elif counter< hwCapCount and counter!=0 :
					logger.log(1,"[MatchFinder_findHWCap] Few HW Capabilities Matched","D")
					return 1
					

				elif counter==0:
					logger.log(1,"[MatchFinder_findHWCap] No matching  HW Capabilities found","D")
					return 2

			else:
				logger.log(1,"Test job requires no external hardware","D")
				return 0
		except Exception, e:
			
			logger.log(1,str(e),"E")
			return 2

#############################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Convert Test Record format from Tuple to Dictionary							#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	Tuple		Test Record Tuple							#
    	#########################################################################################################
	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	Dictionary	Test Record Dictionary							#
	# None		Object		Negative Return								#	
    	#########################################################################################################
	def convertToDictionary(self, tupleData):
		try:
			
			logger.log(1,"[MatchFinder_checkTestTable] Tuple Data: "+str(tupleData),"I")

			
			record={
				'build_mode':tupleData[0], 
				'build_kind':tupleData[1], 
				'build_number':tupleData[2], 
				'product':tupleData[3],
				'os':tupleData[4],
				'component':tupleData[5],
				'tag':tupleData[6],
				'test_plan':tupleData[7],
				'selected_tc_ids':tupleData[8],
				'selected_tc_titles':tupleData[9],
				'script_file':tupleData[10],
				'sw_cap':tupleData[11],
				'hw_cap':tupleData[12],
				'est_runtime':tupleData[13],
				'support_device_count':tupleData[14],
				'mode':tupleData[15],
				'location':tupleData[16],
				'test_bed_name':tupleData[17],
				'devices':tupleData[18],
				'build_xml_location':tupleData[19],
				'user':tupleData[20],
				'creation_timestamp':tupleData[21],
				'starting_timestamp':tupleData[22],
				'flash':tupleData[23],
				'email_status':tupleData[24],
				'email_reason':tupleData[25],
				'support_devices':tupleData[26],
				'build_variant':tupleData[27],
				'scrum_name':tupleData[28],
				'priority':tupleData[29],
				'pilot_tested':tupleData[30],
				'device_required':tupleData[31],
				'wantechnology':tupleData[32],
				'hardwarerev':tupleData[33],
				'scan_engine':tupleData[34],
				'uniquejob_name':tupleData[35]
				}
			
			logger.log(1,"[MatchFinder_checkTestTable] converted record"+str(record),"I")
			return record
		except Exception, e:
			
			logger.log(1,str(e),"E")
			return None
	
	#######################################################################################################################################################
        ################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Match Device Serial ID with Device ID required for Test Job						#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# tupleData	tuple	        Node details								#
    	# 					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# record	dictionary	Node details								#
	# 							#
    	#########################################################################################################
	#################################################################################################################################

	def devfarmconvertToDictionary(self, tupleData):
		try:
			
			record={
				'nodename':tupleData[0], 
				'nodeip':tupleData[1], 
				'nodeos':tupleData[2], 
				'nodestatus':tupleData[3],
				'requestedby':tupleData[4],
				'requestcomments':tupleData[5],
				'softwares':tupleData[6],
				'friendlyname':tupleData[7],
				'location':tupleData[8],
				'parallelexec':tupleData[9],
				'macaddress':tupleData[10],
				'nodeonlinestatus':tupleData[11],
				'locked':tupleData[12],
				'nodejenkinsonlinestatus':tupleData[13],
				'hardwares':tupleData[14],
				'manualgit':tupleData[15],
				'scheduledgit':tupleData[16],
				'Branchname':tupleData[17],
				'manualgitstarttime':tupleData[18],
				'jobname':tupleData[19],
				'scrumteam':tupleData[20],
				'systemlock':tupleData[21]
				 	 }
			
			return record
		except Exception, e:
			
			logger.log(1,"devfarmconvertToDictionary:EXCEPTION:"+str(e),"E")
			return None



#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Locked on Server Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialno String		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################

	
	def lockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"MatchFinder_Lock Function Server Side","D")
			logger.log(1,"[MatchFinder_LockDevices Server Side] Locking Device: "+str(deviceserialno),"D")
			lockResult=self.deviceFarm.reserve_device(operation='reserve_device', serialno=str(deviceserialno))

			logger.log(1,lockResult,"I")
			if lockResult.get('reservationStatus')=='success' and lockResult.get('result')=='ok':
				
				logger.log(1,"[MatchFinder_LockDevices Server Side] Successfully Locked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			
                       
			logger.log(1,"[MatchFinder_LockDevices Server Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False

#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to UnLocked on Server Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# deviceserialno String		Device Serial number								#
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################

	
	def unlockDevices(self,deviceserialno):
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		try:
			logger.log(1,"MatchFinder_Unlock Function Server Side","D")
			logger.log(1,"[MatchFinder_UnlockDevices Server Side] Unlocking Device: "+str(deviceserialno),"D")
			unlockResult=self.deviceFarm.release_device(operation='release_device', serialno= str(deviceserialno))
			
			if unlockResult.get('releaseStatus')=='success' and unlockResult.get('result')=='ok':
				
				logger.log(1,"[MatchFinder_UnlockDevices Server Side] Successfully unlocked Device: "+str(deviceserialno),"D")
				return True
		except Exception, e:
			
				   
			logger.log(1,"[MatchFinder_UnlockDevices Server Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False
				
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Locked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################
	def lock_device(self, **dataparam):
		try:
			logger.log(1,"MatchFinder_Lock Function Node Side","D")
			logger.log(1,"[MatchFinder_LockDevices Node Side] Locking Device: "+str(dataparam['serialno']),"D")
			logger.log(1,"Dataparam : "+str(dataparam),"D")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data : "+str(json_data),"D")
			if json_data['result'] == 'ok':
				lockresult = self.lockDevices(dataparam['serialno'])
				logger.log(1,"[MatchFinder_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"D")
				return lockresult
			else:
				logger.log(1,"[MatchFinder_LockDevices Node Side] Unsuccessful locking Device: "+str(dataparam['serialno']),"D")
				logger.log(1,"[MatchFinder_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno']),"D")
				time.sleep(5)
				noofretry=0
				while noofretry!=3:
					noofretry=noofretry+1
					params = urllib.urlencode(dataparam)
			
					response = urllib2.urlopen(nodeServerUrl, params).read()
			
					json_data = json.loads(response)
					if json_data['result'] == 'ok':
						lockresult = self.lockDevices(dataparam['serialno'])
						logger.log(1,"[MatchFinder_LockDevices Node Side] Successfully Locked Device: "+str(dataparam['serialno']),"D")
						noofretry=3
						return lockresult
					else:
						logger.log(1,"[MatchFinder_LockDevices Node Side] Unsuccessful locking Device clm retrying to lock the device: "+str(dataparam['serialno'])+"retrying attempt"+str(noofretry),"D")
						if noofretry==3:
							return False

					time.sleep(5)




				
		except Exception, e:
			
                       
			logger.log(1,"[MatchFinder_LockDevices Node Side] Unsuccessful locking Device EXCEPTION: "+str(e),"E")
			return False
			
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Change the Device Lock Status to Unlocked on Node Side					#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
    	# dataparam 	Pointer		Dataparameter to be passed to the handler				#			
    					#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# Data		Type		Note									#
	# True		Boolean		Positive Return								#
	# False		Boolean		Negative Return								#
    	#########################################################################################################

	def unlock_device(self, **dataparam):
		try:
			logger.log(1,"MatchFinder_Unlock Function Node Side","D")
			logger.log(1,"[MatchFinder_UnlockDevices Node Side] Unlocking Device: "+str(dataparam['serialno']),"D")
			logger.log(1,"Dataparam : "+str(dataparam),"D")
			nodeServerUrl = 'http://' + str(dataparam['nodeip']) + '/interface'
			
			params = urllib.urlencode(dataparam)
			
			response = urllib2.urlopen(nodeServerUrl, params).read()
			
			json_data = json.loads(response)
			logger.log(1,"json_data: "+str(json_data),"D")
			if json_data['result'] == 'ok':
				unlockresult = self.unlockDevices(dataparam['serialno'])
				logger.log(1,"[MatchFinder_UnlockDevices Node Side] Successfully Unlocked Device: "+str(dataparam['serialno']),"D")
				return unlockresult
			else:
				logger.log(1,"[MatchFinder_UnlockDevices Node Side] Unsuccessful Unlocking Device: "+str(dataparam['serialno']),"D")
				return False
		except Exception, e:
			
                       
			logger.log(1,"[MatchFinder_UnlockDevices Node Side] Unsuccessful Unlocking Device EXCEPTION: "+str(e),"E")
			return False
			
#######################################################################################################################################################

	#########################################################################################################
	# SYNOPSIS:												#
    	# Continuously check TBL_TEST_DETAILS table for incomming Data to be processed				#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def checkTestTable(self):

		try:
			#Create Instance for Test Detail DB Interface 
			while True:

				self.testDetails=DB_Interface.Test_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				logger.log(1,"MatchFinder checkTestTable testDetails DB connection opened:","I")
				
				
				QUERY='SELECT COUNT(*) FROM TBL_TEST_DETAILS;'
				
				logger.log(1,QUERY,"I")
				result=self.testDetails.execute(QUERY, "SELECT")
				self.testDetails.close()
				
				logger.log(1,result,"I")
				
				if result[0]>0L:
					
			        	logger.log(1,"[MatchFinder_checkTestTable] Record is there to Process in Test Details Table","D")
					self.startProcess()
					
                  		        logger.log(1,"[MatchFinder_checkTestTable] One Test Detail Processed","I")
				else:
					
                    			logger.log(1,"[MatchFinder_checkTestTable] No Record is there to Process in Test Details Table; Wait For Some Time","D")
					time.sleep(5)
				
				logger.log(1,"MatchFinder checkTestTable testDetails DB connection closed","I") 		

		except Exception, e:
			
			logger.log(1,str(e),"E")

		
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	# expectedcount		Integer		Expected count of secondary devices for the job # 		#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicelist		List	List of available secobdary devices 												
    	#########################################################################################################

	def lookforSecondarydevices(self,node,expectedcount):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicelist=[]   
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		logger.log(1,"Online sec devices:","I")
		logger.log(1,str(onlineSecDevices),"I")
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)
		
		if len(unlockedsecdevices)>= expectedcount:
			i = 0
			while i< expectedcount:
					secdevicelist.append(unlockedsecdevices[i])
					i =i+1

		logger.log(1,"Available secondary devices:"+str(secdevicelist),"I")
		return secdevicelist
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# secdevicecount	Integer		Count of available secobdary devices 												
    	#########################################################################################################
	def getSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		secdevicecount = len(onlineSecDevices.get('devices'))
		logger.log(1,"total count of locked and unlocked secondary device from node:"+str(secdevicecount),"I")
		return secdevicecount
		

######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Function to return number of unlocked secondary devices for a node	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# node			Dictionary	Node details	
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# unlockedsecdevicecount	Integer		Count of available unlocked secobdary devices 												
    	#########################################################################################################		

	def getunlockedSecondaryDevicecount(self,node):

		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		secdevicecount = 0
		lockedsecdevices=[]
		unlockedsecdevices=[]
		logger.log(1,"Node name:"+str(node.get('friendlyname')),"I")
		onlineSecDevices=self.deviceFarm.get_all_online_sec_devices_from_node_name(operation='get_all_online_sec_devices_from_node_name',nodename=node.get('friendlyname'))
		for device in onlineSecDevices.get('devices'):
			if device.get('locked')=='true':
				lockedsecdevices.append(device)
			else:
				unlockedsecdevices.append(device)

		unlockedsecdevicecount = len(unlockedsecdevices)
		logger.log(1,"count of unlocked secondary device from node:"+str(unlockedsecdevicecount),"I")
		return unlockedsecdevicecount


#########################################################################################################
	# SYNOPSIS:												#
    	# Check if locked devices are available in the testbed selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test Record	
	# lockedDevicesList	List		List of locked devices							#
	# devicetype		String		Type of device-primary or secondary							#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################
	def lookForLockedDevices(self, lockedDevicesList, testRecord,devicetype):
		try:
			filteredNodes=[]
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			
			for nodeDetail in lockedDevicesList:
				node=nodeDetail.get('node')
				unlockedDevices=0

				inUseDevices=0
				
				foundAllHWCapDevice=False
				foundFewHWCapDevice=False
				countOfDevices=len(nodeDetail.get('devices'))
				#Maintain Device Info for Scheduling purpose 
				deviceList=[]
				secdeviceList=[]
				unlockedSecDevices = 0
				matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
				unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
				seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)
				
				for device in nodeDetail.get('devices'):
					
					logger.log(1,"[MatchFinder_lookForLockedDevices] Locked Device: ","I")
					
					logger.log(1,device,"I")

					
					if devicetype == 'Primary':
						
						logger.log(1,"[MatchFinder_lookForLockedDevices] All HW Capabilities of Locked Primary Device Matched","D")
						deviceList.append(device)
						foundAllHWCapNode=True
						foundAllHWCapDevice=True
						unlockedDevices=unlockedDevices+1
						
					
				if foundAllHWCapDevice==True:
					
					logger.log(1,"[MatchFinder_lookForLockedDevices] Unlocked Devices: "+ str(unlockedDevices),"D")
					
					logger.log(1,"[MatchFinder_lookForLockedDevices] Required Devices for Test Execution: "+str(testRecord[14]),"I")
					
					logger.log(1,"[MatchFinder_lookForLockedDevices] Required Devices for Test Execution: "+str(testRecord[14]+1),"I")
					#Check testRecord['support_device_count'] info & verify whether Node has sufficient locked device count for execution
					
					if devicetype == 'Primary':
						if unlockedDevices>=1:
								
								logger.log(1,"[MatchFinder_lookForLockedDevices] Add Node to filteredNodes; & Continue Processing of Node","D")
								filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicablePrimaryDevices':unlockedDevices, 'applicableSecondaryDevices':unlockedSecDevices,'devices':deviceList, 'support_devices':secdeviceList,'friendlyname':node.get('friendlyname')})
						else:
							#Reject Node
							pass
					
				else:
					#Reject Node
					
					logger.log(1,"[MatchFinder_lookForLockedDevices] No Locked Devices Found from this Node which has All HW Capabilities","D")
#######################################################################################################################################################
			
			#If Node found, which has Locked Device with all HW Capabilities 
			if foundAllHWCapNode==True:
				#Process Node further
				#If no Node has sufficient Locked Devices for execution, then Send EMAIL Notification
				if len(filteredNodes)==0:
					#Send EMAIL Notification
					
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_locked_device'],'Dear user,\n\n No node has sufficient locked devices with all HW capabilities for execution for script:'+str(testRecord[10])+'\n\n',[])
					logger.log(1,"[MatchFinder_lookForLockedDevices] No Node has sufficient Locked Devices for execution; send EMAIL Notification","I")
					return False
				else:
					filterredNodeCounter=1
					#Process Node further
					
					logger.log(1,  "[MatchFinder_lookForLockedDevices] Filterred Nodes: ","D")
					foundParallel=False

					testJobScheduled=False
					for node in filteredNodes:
						parallelnodestatus = (node.get('node').get('parallelexec')).lower()
						print "Parallel execution status=",parallelnodestatus
						
						logger.log(1,"[MatchFinder_lookForLockedDevices] Fileterred Node "+str(filterredNodeCounter),"I")
						filterredNodeCounter=filterredNodeCounter+1
						
						logger.log(1,node,"I")
#######################################################################################################################################################
						if parallelnodestatus =='true':
							
                            				logger.log(1,"[MatchFinder_lookForLockedDevices] Node is Parallel Execution Capable; So Put the Test Job in Queue","D")
							
							return True
						else:
							
							logger.log(1,"[MatchFinder_lookForLockedDevices] Node is not Parallel Execution Capable","D")
							if node.get('totalDevices') >= (node.get('applicablePrimaryDevices')+node.get('applicableSecondaryDevices')):
								
								logger.log(1,"[MatchFinder_lookForLockedDevices] Put Test Job In Queue","D")
								
								return True
							else:
								#Send EMAIL Notification
								
								self.email.sendMailNotification((Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_sufficient_device'],'Dear user,\n\n Sufficient devices are not found in any node for script:'+str(testRecord[10])+'\n\n',[]))
								logger.log(1,"[MatchFinder_lookForLockedDevices] Send EMAIL Notification","I")
								return False
			else:
				#Send EMAIL Notification to Device Farm Admin
				
				self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear user,\n\n No node found  which has Unlocked Devices with matching HW capabilities for script:'+str(testRecord[10])+'. Expected hardware capabilities:'+str(testRecord[12])+"\n\n",[])
				logger.log(1,"[MatchFinder_lookForLockedDevices] No Node found which has Unlocked Devices with matching HW Capabilities; Send EMAIL Notification to Device Farm Admin","I")
				return False

		except Exception, e:
			
			logger.log(1,str(e),"E")
			return False


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Remove Topmost record from TBL_TEST_DETAILS table & start finding match for it			#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess(self):
		

		try:

			#Create Instance for Test Detail DB Interface 
			
			
			self.testDetails=DB_Interface.Test_Details(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			logger.log(1,"[MatchFinder_startProcess] Executing Query","I")
			QUERY='SELECT * FROM TBL_TEST_DETAILS;'
			result=self.testDetails.execute(QUERY, "SELECT")
			
			logger.log(1,"[MatchFinder_startProcess] Query Execution Result: "+str(result),"I")
			checkrecord=None

			#Create Instance for Device Farm Wrapper
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()

			#Get First Test Detail
			testRecord=self.testDetails.pop()
			self.testDetails.close()
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			query1='SELECT * FROM TBL_RUNNING_TEST where build_xml_location="'+testRecord[19]+'"';
			checkrecord=self.testRun.execute(query1,"SELECT");
			self.testRun.close()
			if checkrecord==None:
				
				logger.log(1, "[MatchFinder_startProcess] First Test Record: ","D")
				
				logger.log(1, testRecord,"I")
			

				
				logger.log(1,"[MatchFinder_startProcess] Test Location: "+str(testRecord[16]),"I")
				
				logger.log(1,"[MatchFinder_startProcess] Test Bed Name: "+str(testRecord[17]),"I")

				
				logger.log(1,"[MatchFinder_startProcess] Test Location: "+str(type(testRecord[16])),"I")
				
				logger.log(1,"[MatchFinder_startProcess] Test Bed Name: "+str(type(testRecord[17])),"I")

				
				logger.log(1,"[MatchFinder_startProcess] Test Location: "+str(len(testRecord[16])),"I")
				
				logger.log(1,"[MatchFinder_startProcess] Test Bed Name: "+str(len(testRecord[17])),"I")
	
				
				logger.log(1,str(testRecord[16]=='NA'),"I")
				
				logger.log(1, str(testRecord[17]=='NA'),"I")
				

				if testRecord[16]=='NA' and testRecord[17]=='NA' and testRecord[31]=='true':
					
					logger.log(1,"[MatchFinder_startProcess] Test Location & Test Bed not Provided in Build.xml","D")
					self.startProcess_Find_TestBed_Device(testRecord)
				elif testRecord[16]!='NA' and testRecord[17]!='NA' and testRecord[31]=='true':
					
					logger.log(1,"[MatchFinder_startProcess] Test Location & Test Bed provided in Build.xml","D")
					self.manualgitcheck=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
					manualgitstatus=self.manualgitcheck.getmanualgitstatus(str(testRecord[17]))
					nodelockstatus=self.manualgitcheck.getnodelockedstatus(str(testRecord[17]))
					systemlocked=self.manualgitcheck.getsystemlockedinfo(str(testRecord[17]))
					gitpullstatus=self.manualgitcheck.getscheduledgitstatus(str(testRecord[17]))
					self.manualgitcheck.close()
					logger.log(1,"[MatchFinder_startProcess] Manual git nodelocked and manualgitstatus"+str(nodelockstatus)+str(manualgitstatus),"I")
					if nodelockstatus=='True' or manualgitstatus == 'True' or systemlocked=='true' or gitpullstatus=='IN_PROGRESS' or gitpullstatus=='INITIATED':
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()
						if nodelockstatus=='True' or manualgitstatus == 'True':
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Git_Pull'],'Dear admin,\n\n Manual git is on , job has been put into queue for test bed-'+ str(testRecord[17])+'\n\n',[])
							logger.log(1,"[MatchFinder_startProcess] Manual git is on,so put record in queue","I")
						return
					else:
						logger.log(1,"[MatchFinder_startProcess] startProcess_Find_Device","D")
						self.startProcess_Find_Device(testRecord)
				elif testRecord[16]=='NA' and testRecord[17]=='NA' and testRecord[31]=='false':
					
					logger.log(1,"[MatchFinder_startProcess] Test Location & Test Bed not Provided in Build.xml","D")
					self.startProcess_System_not_selected(testRecord)
				elif testRecord[16]!='NA' and testRecord[17]!='NA' and testRecord[31]=='false':
					
					logger.log(1,"[MatchFinder_startProcess] Test Location & Test Bed provided in Build.xml","D")
					self.manualgitcheck=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
					manualgitstatus=self.manualgitcheck.getmanualgitstatus(str(testRecord[17]))
					nodelockstatus=self.manualgitcheck.getnodelockedstatus(str(testRecord[17]))
					gitpullstatus=self.manualgitcheck.getscheduledgitstatus(str(testRecord[17]))
					self.manualgitcheck.close()
					logger.log(1,"[MatchFinder_startProcess] Manual git nodelocked and manualgitstatus"+str(nodelockstatus)+str(manualgitstatus),"I")
					if nodelockstatus=='True' or manualgitstatus == 'True' or gitpullstatus=='IN_PROGRESS' or gitpullstatus=='INITIATED':
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Git_Pull'],'Dear admin,\n\n Manual git is on , job has been put into queue for test bed-'+ str(testRecord[17])+'\n\n',[])
						logger.log(1,"[MatchFinder_startProcess] Manual git is on,so put record in queue","I")
						return
					else:
						logger.log(1,"[MatchFinder_startProcess] startProcess_Find_Device","D")
						self.startProcess_System_selected(testRecord)
				
				else:
					
					logger.log(1,"[MatchFinder_startProcess] Not Sufficient Information for Test Bed or Test Location","D")


			else:
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				self.testQueue.insert(self.convertToDictionary(testRecord))
				logger.log(1,"[MatchFinder_startProcess] Putting the record in queue to wait for pilot testing","I")
				self.testQueue.close()
		
		except Exception, e:
			
			logger.log(1,str(e),"E")
		
#########################################################################################################
	# SYNOPSIS:												#
    	# Check if teh hardware is in use for the node selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# nodename		String		Node name	
	# hwCap			String		Hardware capability to be checked						#
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################
	def inUseHardware_nothingSelected(self, nodename, hwCap):
		
		
		try:
			lockflagHw = 'false'
			self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
			inUseHardware = self.testRun.inUseHwCap(nodename)
			self.testRun.close()
			inUseHardware = str(inUseHardware)
			inUseHardware = inUseHardware.replace("(","")
			inUseHardware = inUseHardware.replace(")","")
			inUseHardware = inUseHardware.replace("'","")
			logger.log(1,"In use hardware:"+str(inUseHardware),"I")
		
			if inUseHardware.split(",")[0] == "NA":
				logger.log(1,"No hardware required","D")
				return lockflagHw
			

			else:
				for a in hwCap:
					
						j= 0
						if len(inUseHardware)!=0:
								if "," in inUseHardware:
									inUseHardware = inUseHardware.split(",")
				
									logger.log(1,"New in use hardware:"+str(inUseHardware),"I")
								for j in inUseHardware:
										logger.log(1,"a"+str(a.strip(' ')),"I")
										
										if a.strip(' ')==j.encode('ascii', 'ignore'):
											logger.log(1, "Found match with in use hardware","D")
											lockflagHw = 'true'
											
											break
		
				return lockflagHw
		except Exception, e:
			
			logger.log(1,str(e),"E")
			return 'false'
		
########################################################################################################
	# SYNOPSIS:												#
    	# Return the product details	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test record for the job	
							#
	#########################################################################################################
    	# OUTPUT DATA:	lockflagHw											#
    	# returnstr		String	Details of product
												#
    	#########################################################################################################
	def checkproduct(self,testRecord):	

		try:
			logger.log(1,"Inside checkproduct function","I")
			logger.log(1,"TestRecord for product:"+str(testRecord),"I")	
			logger.log(1,"WanTechnology required for product:"+str(testRecord[32]),"I")
			logger.log(1,"Hardwarerev required for product:"+str(testRecord[33]),"I")	
			logger.log(1,"Scan engine required for product:"+str(testRecord[34]),"I")
			returnstr = ""
			if str(testRecord[32])!= "Any":
				returnstr= returnstr+ " WanTechnology required for product:"+str(testRecord[32])+"\n"
			if str(testRecord[33])!= "Any":
				returnstr= returnstr+ " Hardwarerev required for product:"+str(testRecord[33])+"\n"
			if str(testRecord[34])!= "Any":
				returnstr= returnstr+ " Scan engine required for product:"+str(testRecord[34])+"\n"
			logger.log(1,"Return string="+str(returnstr),"I")
			return returnstr

		except:
			return "None"
#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Remove Topmost record from TBL_TEST_DETAILS table & start finding match for it			#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_Find_TestBed_Device(self, testRecord):
		
		
		try:
			manualgittestbedlocked=[]
			self.lock.acquire()
			
			logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Lock Locking","I")
			
			logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Test Suite SW Capabilities: ","I")
			
			logger.log(1,testRecord[11],"I")

			
			logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Test Suite Test Case IDs: ","I")
			
			logger.log(1,testRecord[8],"I")
			#List of Nodes which have all SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithAllSWCap=[]
			nodeWithAllHWCap=[]
			nodeWithAllCap=[]
			#List of Nodes which have few SW Capabilities mentioned in testRecord['sw_cap']
			nodeWithFewSWCap=[]
			nodeWithFewHWCap = []
			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			
			logger.log(1,"All Nodes: ","I")
			
			logger.log(1,allNodes,"I")
			
			foundAll=False
			foundFew=False
			nodeOffline = False
			nodeOnline = False
			unlockedSecDevices = 0
			seclockedcount = 0
			matchedSecDeviceCounter = 0
			expectedDevicecount = 0
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			nodeWithPri=[]
			nodeWithSec=[]
			OnlineSecDevices=0
			nodeavail = "false"
			lockeddev = 0
			devavail = False
			inusehardwarecheck=False
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(testRecord[28])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
                        nodestobechecked = []
			nodewithlocked = []
			lockResultsec=True
			lockResult=True
			logger.log(1,"Prionodes="+str(prionodes),"I")
			if prionodes!= None:
					x = len(prionodes)
			else:
					x = 0
			logger.log(1,"Length Prionodes x="+str(x),"I")
			if x != 0:
				logger.log(1,"Testbeds have been allocated to the scrum team :"+str(testRecord[28]),"I")
				for i in prionodes:
					node= self.devfarmconvertToDictionary(i)
					
					swCap=node.get('softwares').split(',')
					
					logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] SW Capabilities: "+str(swCap),"I")
					hwCap = node.get('hardwares').split(',')
					logger.log(1,"External hwcap:"+str(hwCap),"I")
					#Logic to Handle SW Capabilities


					nodeavail = self.checknode(testRecord,swCap,hwCap,node)
					logger.log(1,"Node avail="+str(nodeavail),"I")
					if nodeavail == "true":
							if node['locked']!='True' and  node['manualgit']!='True' and node['scheduledgit']!='IN_PROGRESS' and node['scheduledgit']!='INITIATED': 
								parallelnodestatus = (node['parallelexec']).lower()
								if parallelnodestatus=='false':
									self.testRun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									testbed_in_progress=self.testRun.checkInprogress_on_testbed(node['friendlyname'])
									self.testRun.close()
									systemlocked='false'
									if  node['systemlock']=='true' or  testbed_in_progress:
										nodewithlocked.append(node)
								
									else:
										nodestobechecked.append(node)
										devavail = True
									
								else:
									nodestobechecked.append(node)
									devavail = True
							else:
								nodewithlocked.append(node)
					elif nodeavail!= "SW-HW cap not matching":
							lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))
							unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
							OnlineSecDevices= self.getSecondaryDevicecount(node)
							if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
								nodewithlocked.append(node)
							else:
								continue
				if devavail!= True:
						if commonnodes!= None:
							y = len(commonnodes)
						else:
							y = 0
						if y != 0:
							for j in commonnodes:
									node= self.devfarmconvertToDictionary(j)
									swCap=node.get('softwares').split(',')
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] SW Capabilities: "+str(swCap),"I")
									hwCap = node.get('hardwares').split(',')
									nodeavail = self.checknode(testRecord,swCap,hwCap,node)
									if nodeavail == "true":
										nodestobechecked.append(node)
										logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
										devavail = True
									elif nodeavail!= "SW-HW cap not matching":
										lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))
										unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
										OnlineSecDevices= self.getSecondaryDevicecount(node)
										if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
											nodewithlocked.append(node)
										else:
											pass
							if len(nodestobechecked)== 0: 

								logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
								if len(nodewithlocked) != 0:
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(self.convertToDictionary(testRecord))
									self.testQueue.close()
								else:

																		
										logger.log(1,"No node available required for execution.Send mail to admin","D")
										

						else:

								if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(self.convertToDictionary(testRecord))
										self.testQueue.close()
									else:

																		
										logger.log(1,"No node available required for execution.Send mail to admin","D")
							
														
								
				
				
			else:
				logger.log(1,"Commonnodes="+str(commonnodes),"D")
				logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
				if commonnodes!= None:
						y = len(commonnodes)
				else:
						y = 0
				logger.log(1,"Length of Commonnodes="+str(y),"I")
				if y != 0:
					for j in commonnodes:
							node= self.devfarmconvertToDictionary(j)
							swCap=node.get('softwares').split(',')
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] SW Capabilities: "+str(swCap),"I")
							hwCap = node.get('hardwares').split(',')
							logger.log(1,"External hwcap:"+str(hwCap),"I")
							nodeavail = self.checknode(testRecord,swCap,hwCap,node)
							logger.log(1,"Node avail="+str(nodeavail),"I")
							if nodeavail == "true":
								nodestobechecked.append(node)
								logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
								devavail = True
													
							if devavail != True and nodeavail!= "SW-HW cap not matching":
								lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))

								unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
								OnlineSecDevices= self.getSecondaryDevicecount(node)
								
								if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
									nodewithlocked.append(node)	
								else:
									pass
					if len(nodestobechecked)== 0: 

						logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
						if len(nodewithlocked) != 0:
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
						
				else:

						if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(self.convertToDictionary(testRecord))
										self.testQueue.close()
									else:

										logger.log(1,"No node available required for execution.Send mail to admin","D")
						
						
			
			if len(nodestobechecked)== 0:
				if len(nodewithlocked) == 0:
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y = 0
					logger.log(1,"Length of Commonnodes="+str(y),"I")


					if x==0 and y!=0:
						commonandprionodes=commonnodes
					elif x!=0 and y==0:
						commonandprionodes=prionodes
					elif x!=0 and y!=0:
						commonandprionodes=list(prionodes)
						for k in commonnodes:
							commonandprionodes.append(k)
						commonandprionodes=tuple(commonandprionodes)
					elif x==0 and y==0:
						commonandprionodes=()
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] no node is available","D")	

					logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]commonprionodes"+str(commonandprionodes),"D")


					if len(commonandprionodes)==0:
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node is  available for the user'+'\n\n',[])
					else:

						for m in commonandprionodes:
									node= self.devfarmconvertToDictionary(m)
									logger.log(1, "[MatchFinder_startProcess_Find_TestBed_Device] Is it Online: "+str(node.get('nodeonlinestatus')),"D")
									if node.get('nodeonlinestatus')=='online'and node.get('nodejenkinsonlinestatus')=='online':
											nodeOnline = True
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Node: "+str(node.get('friendlyname')),"D")
											swCap=node.get('softwares').split(',')
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] SW Capabilities: "+str(swCap),"I")
											hwCap = node.get('hardwares').split(',')
											logger.log(1,"External hwcap:"+str(hwCap),"I")
											lockflagHw = 'false'
											
											#Logic to Handle SW Capabilities
											result=self.findSWCap(testRecord[11].split(','), swCap)
											hwresult=self.findHWCap(testRecord[12].split(','), hwCap)
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Result of HwCap: "+str(hwresult),"I")
											noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
											noofunlocked = self.checkunlockeddevices(testRecord[3],testRecord[4], node['friendlyname'],testRecord)
											logger.log(1,"No of unlocked device:"+str(noofunlocked),"I")
											if int(testRecord[14]) >1:	
													noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
													if noofavailsecdev >= int(testRecord[14])-1: 
														nodeWithSec.append(node)
														secresult = True
													else:
														secresult = False
											else:
												secresult = True
											if secresult == True:
												nodeWithSec.append(node)
												if result==0 and hwresult!= 0:
													#Put Node in nodeWithFewSWCap
													
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
													nodeWithFewHWCap.append(node)
													nodeWithAllSWCap.append(node)
												elif result!=0 and hwresult== 0:
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
													nodeWithFewSWCap.append(node)
													nodeWithAllHWCap.append(node)
												elif result!=0 and hwresult!= 0:
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
													nodeWithFewSWCap.append(node)
													nodeWithFewHWCap.append(node)
												elif result == 0 and hwresult==0:
													#Put Node in nodeWithAllSWCap
													
													logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
													#nodeWithAllCap.append(node)
													nodeWithAllHWCap.append(node)
													nodeWithAllSWCap.append(node)	
													if noofunlocked >= 1:
														priavail= True
													else:
														priavail = False
													if priavail == True:
															nodeWithPri.append(node)								
															
															
													else:
														logger.log(1,"No primary devices available","I")
														
														
											else:
												logger.log(1,"Sufficient secondary dev not available","I")

									else:
													nodeOffline = False
													nodeOnline = nodeOnline | nodeOffline
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Node has gone offline","D")

                #############################################################################################################################################
                               
                                
					logger.log(1,"Nodes with sec:"+str(nodeWithSec),"I")
					logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
					logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
					logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
					if len(nodeWithSec)== 0:
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Required number of secondary devices not found in any Node; Send EMAIL notification to Device Farm Admin","D")
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has secondary devices required for execution of job:'+str(testRecord[10])+'. \nNumber of secondary devices required='+str(testRecord[14]-1)+'\n\n',[])
															
					else:
													
							if len(nodeWithAllSWCap)==0  and nodeOnline == True:
								
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])						
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
						
											
							elif len(nodeWithAllHWCap)==0 and nodeOnline == True:
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has hardware capability required for execution of job:'+str(testRecord[10])+"\n Required hardware capability:"+str(testRecord[12])+'\n\n',[])	
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
							
									pass
							elif len(nodeWithPri)== 0:
								productresult = self.checkproduct(testRecord)
								logger.log(1,"Primary device not available"+str(productresult),"I")
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node has devices required for execution of job:'+str(testRecord[10])+". Device required:\n Product:"+str(testRecord[3])+"\n OS Required:"+str(testRecord[4])+"\n"+str(productresult)+'\n\n',[])
						

			if len(nodestobechecked)!=0:
				
				logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Found Nodes with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")    
				lockflagHw = 'false'
				filteredNodes=[]
				matchdevices=[]
				foundAllHWCapNode=True
				foundFewHWCapNode=False
				#Get all Online Devices from Selected Nodes from above step
				nodeCounter=1

	#############################################################################################################################################
				#Create Locked Devices's List; so that if any match found from this list, Scheduler can keept Test Job in Queue
				lockedDevicesList=[] 
				seclockedDevicesList =[]
	#############################################################################################################################################

				count = 0
				for node in nodestobechecked:
					
					lockflagHw =self.inUseHardware_nothingSelected(node.get('friendlyname'),testRecord[12].split(","))
					
					if lockflagHw!= 'true':
						
						logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Found Node with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
						foundAllHWCapNode = True
						#Unlocked Devices Counter
						unlockedDevices=0
						
						inUseDevices=0
						inUseSecDevices = 0
						matchdevices=[]
						matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
						unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
						seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)

						
						logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] | Node "+str(nodeCounter),"I")
						nodeCounter=nodeCounter+1
						
						logger.log(1,node,"I")
						
						onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))
						
						foundAllHWCapDevice=False
						countOfDevices=len(onlineDevices.get('devices'))
						#Maintain Device Info for Scheduling purpose 
						deviceList=[]
						secdeviceList = []
						lockedDevices=[]
						seclockedDevices = []
						lockedSecDevices =[]
						seclistjob = []
						
						onlineDeviceCounter=1
						
						for device in onlineDevices.get('devices'):
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Device "+str(onlineDeviceCounter),"D")
							onlineDeviceCounter=onlineDeviceCounter+1
							
							logger.log(1,device,"I")
							
							if device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')) and (device.get('status')=='online'):
							#Get Product & OS Information for all selected Online Devices from above step &
							#Select only those Devices, which have matching Product & OS info mentioned in testRecord['product'] & testRecord['os']
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Matching Product & OS: ","D")
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Device Property : Test Suite Property","I")
								
								logger.log(1,device.get('name')+" : "+str(testRecord[3]),"I")
								
								logger.log(1,str(device.get('version')).split("-")[1]+" : "+str(testRecord[4]),"I")
								#if device.get('name')==testRecord[3] and device.get('version')==testRecord[4].split(" ")[1]:Uncomment It ********************************************************************************************************************************************


								result=self.checkfordevice(testRecord,device)
								if result==True:
									
									logger.log(1,  "[MatchFinder_startProcess_Find_TestBed_Device] Device Product, OS Matched","D")
									product = str(device.get('name'))
									os_version = str(device.get('version')).split("-")[1]
									
									#Get Devices which has all HW Capabilities mentioned in testRecord['hw_cap']
									#If there is no Device found in any Node, then send EMAIL to Device Farm Admin; Else Continue next Step
									
									if device.get('secondary')=='false': 
											
											deviceList.append(device)
											foundAllHWCapNode=True
											foundAllHWCapDevice=True
											unlockedDevices=unlockedDevices+1
										
									
								else:
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Device Product & OS not matched","D")
							elif (device.get('locked')=='true' or device.get('flash_status')=='true') :
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Device is Locked; So put Device in Locked Devices List","D")	
								if device.get('secondary')=='false': 
									inUseDevices=inUseDevices+1
									
											

								#Match Product & OS Version Before putting to List; Don't Put any Locked Device (Want only matching Locked Devices) 
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Matching Product & OS of Locked Device: ","I")
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Device Property : Test Suite Property","I")
								
								logger.log(1,device.get('name')+" : "+str(testRecord[3]),"I")
								
								logger.log(1,str(device.get('version')).split("-")[1]+" : "+str(testRecord[4]),"I")
								#if device.get('name')==testRecord[3] and device.get('version')==testRecord[4].split(" ")[1]:Uncomment It ********************************************************************************************************************************************
								if ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')) and device.get('secondary')=='false':
									result=self.checkfordevice(testRecord,device)
									if result==True:
										
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Locked Device's Product, OS Matched for Primary Device","D")
										product = str(device.get('name'))
										os_version = str(device.get('version')).split("-")[1]
										lockedDevices.append(device)

								
		

							print "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
		#############################################################################################################################################
						totalSupportDeviceCount = int(testRecord[14])
						logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
						if totalSupportDeviceCount <= 1:
							expectedDevicecount = 0
						else:
							expectedDevicecount = totalSupportDeviceCount - 1

						logger.log(1,"Unlocked secondary devices:"+str(unlockedSecDevices),"D")

						if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Unlocked Devices: "+str(unlockedDevices),"D")
							logger.log(1,"[Find_TestBed_Device] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")
										
							logger.log(1,"[Find_TestBed_Device] Required Support Devices for Test Execution: "+str(expectedDevicecount),"I")
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] locked Secondary Device count: "+ str(seclockedcount),"I")
										
							secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
							#Check testRecord['support_device_count'] info & verify whether Node has sufficient device count for execution
							if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
								systemlocked='false'
								parrallelnodestatus=node.get('parallelexec').lower()
								if parrallelnodestatus=='false' and node.get('systemlock')=='true':
									systemlocked='true'
								if node.get('locked')!='True' and  node.get('manualgit')!='True' and systemlocked=='false'  and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED':
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Add Node to filteredNodes; & Continue Processing of Node","D")
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] In Use Devices for Node: "+str(inUseDevices),"I")
									filteredNodes.append({'node':node, 'totalDevices':countOfDevices, 'applicableDevices':unlockedDevices,'friendlyname':node.get('friendlyname'),'applicableSecDevices':unlockedSecDevices, 'devices':deviceList,'support_devices':secdeviceList, 'inUseDevices':inUseDevices,'inUseSecDevices':seclockedcount,})
								elif  node.get('locked')=='True' or node.get('manualgit')=='True' or systemlocked=='true' or  node.get('scheduledgit')=='IN_PROGRESS' or node.get('scheduledgit')=='INITIATED' :
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Node has ongoing git","D")
									manualgittestbedlocked.append(node.get('friendlyname'))
							else:
								#Reject Node
								pass  
						else:
							#Reject Node
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] No Devices Found from this Node which has All HW Capabilities","D")

		#############################################################################################################################################

						#Add Node & Locked Devices Details to List
						if len(lockedDevices)>0:
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Found Matching Locked Devices; So putting into Locked Devices's List","D")
							lockedDevicesList.append({'node': node, 'devices': lockedDevices})

						print "||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||"

					else:
						logger.log(1,"HW in use for node. Check next node","I")
						count= count +1
						continue
					
	#############################################################################################################################################
				if count == len(nodestobechecked):
						logger.log(1,"All external HW in use. Put job in Queue","I")
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()	
						inusehardwarecheck=True
						#If Node found, which has all HW Capabilities


					#If Node found, which has all HW Capabilities 
				if foundAllHWCapNode==True and inusehardwarecheck==False:
						#Process Node further
						#If no Node has sufficient Unlocked Devices for execution, then put Test Job in Queue
						if len(filteredNodes)==0 and len(manualgittestbedlocked)==0:
							#Put Test Job in Queue
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] No Node has sufficient Unlocked Devices for execution; put Test Job in Auto Queue","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
							pass
						elif len(filteredNodes)==0 and len(manualgittestbedlocked)>0:
							#put test job in queue as no nodes are available and Git is True
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] put test job in queue as no nodes are available and ManualGit is True","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Git_Pull'],'Dear admin,\n\n \ Git is on , job has been put into queue for test bed-'+'\n\n',[])
						else:
							filterredNodeCounter=1 
							#Process Node further
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Filterred Node: ","D")
							foundParallel=False

							testJobScheduled=False

							for node in filteredNodes:
								parallelnodestatus = (node.get('node').get('parallelexec')).lower()
								print "Parallel execution status=",parallelnodestatus
								
								logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Fileterred Node "+str(filterredNodeCounter),"I")
								filterredNodeCounter=filterredNodeCounter+1
								
								logger.log(1,node,"I")
								logger.log(1,"Product="+str(product),"I")
								logger.log(1,"OS="+str(os_version),"I")
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								QUERY='SELECT priority FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" AND test_bed_name="'+node.get('friendlyname')+'" ORDER BY priority;'
								logger.log(1,"Query="+str(QUERY),"I")
								NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
								lenQueue = len(NewQueueRecord)
								
								
							
								if NewQueueRecord!= ():
									minimum= min(NewQueueRecord)
									logger.log(1,"Minimum priority="+str(minimum),"I")
									logger.log(1,"Current priority="+str(testRecord[29]),"I")
									if int(testRecord[29]) >= int(minimum[0]):
											self.testQueue.insert(self.convertToDictionary(testRecord))
											break
										
								self.testQueue.close()	
								#############################################################################################################################################
								if parallelnodestatus =='true':
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Node is Parallel Execution Capable; So Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")
									#Create Jenkins Job for this Test Job & Trigger it on Test Bed
									

									#Create testCase.xml file for Test Job Execution
									setUp=JobPreSetup.SetUp()
									
									logger.log(1,"testRecord Test IDs1: "+str(testRecord[8]),"I")
									dictRecord=self.convertToDictionary(testRecord)
									
									logger.log(1,"Before Test IDs1: "+str(dictRecord.get('selected_tc_ids')),"I")
									preSetUP=setUp.doPreSetUp(dictRecord)
									if preSetUP[0]==True:
										
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] TestCases.xml file created","D")
										#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
										job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'),node.get('support_devices'), preSetUP[1])
										#If Test Job Started; then only put its corresponding Test Record in Running Jobs List
										#jobStatus=job.startProcess()
										#if jobStatus[0]:
										if True:
											
											


											#Lock the Devices
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Locking Devices before Starting Test Job","I")

											if len(node.get('devices'))!= 0:
											
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Locking Device: "+ str(node.get('devices')[0].get('serialno')),"I")
												
												lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')

										
												
												logger.log(1,lockResult,"I")
												if lockResult==True:
													
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Successfully Locked Device","D")


												flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
													
												if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
													
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Successfully Set flash status as true","D")
											logger.log(1,"Sec dev list:"+str(secdeviceList),"I")
											if len(node.get('support_devices'))!= 0:
												i = 0
												
												while i < expectedDevicecount:
													seclistjob.append(node.get('support_devices')[i].get('serialno'))
													logger.log(1,"Sec job list:"+str(seclistjob),"I")
													logger.log(1,"[MatchFinder_startProcess_TestBedSelected] Locking Device: "+str(node.get('support_devices')[i].get('serialno')),"D")
													
													lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
													
													logger.log(1,lockResultsec,"I")
													if lockResultsec==True:
														
														logger.log(1,"[MatchFinder_startProcess_TestBedSelected] Successfully Locked Secondary Device","D")	
													i = i+1



											#Add Test Bed & Device Data to Test Record (For Auto Mode)
											
											if lockResultsec != False and lockResult != False:




												jobStatus=job.startProcess()
												if jobStatus[0]:
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Putting Test Bed & Device Details: ","I")
											
													logger.log(1,node.get('node').get('location'),"I")
											
													logger.log(1,node.get('node').get('friendlyname'),"I")
											
													logger.log(1,node.get('devices')[0].get('serialno'),"I")
													dictRecord['location']=node.get('node').get('location')
													dictRecord['test_bed_name']=node.get('node').get('friendlyname')
													dictRecord['devices']=node.get('devices')[0].get('serialno')
													dictRecord['support_devices']=",".join(seclistjob)

											
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] DictRecord Devices 1: "+str(dictRecord),"I")
													if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
												
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Test Job put into Running List","D")
													testJobScheduled=True

													break
												else:
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
											
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Devices after failure in Starting Test Job","I")
													for device in node.get('devices'):
												
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"I")
												
														unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
														flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))
													
														logger.log(1,unLockResult,"I")
			
													for device in node.get('support_devices'):
												
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"I")
												
														unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
												
														logger.log(1,unLockResult,"I")
											else:
												logger.log(1,"Error in locking device. Job put into queue","I")
												#job.removefromjenkins(str(jobStatus[1]),node.get('node').get('friendlyname'))	
												logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins...........","I")
												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												self.testQueue.insert(self.convertToDictionary(testRecord))
												self.testQueue.close()

												logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins./build no."+str(testRecord[2]),"I")

												self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Auto Job is inserted into queue for build no. '+str(testRecord[2])+'\n\n',[])
												logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins,email sent for./build no."+str(testRecord[2]),"I")
												#self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'], 'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put the job with script  :'+str(testRecord[10])+' in queue'+'\n\n',[])
												testJobScheduled=True	
												break


										else:
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Devices after failure in Starting Test Job","I")
											for device in node.get('devices'):
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"I")
												
												unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
												flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=device.get('serialno'))
													
												logger.log(1,unLockResult,"I")
			
											for device in node.get('support_devices'):
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"I")
												
												unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
												
												logger.log(1,unLockResult,"I")
		#############################################################################################################################################
								else:
									
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Node is not Parallel Execution Capable","D")
									#Check whether there is any already ongoing execution on Test Bed
									#If no Ongoing execution then Schedule test Job & trigger it on Test Bed
									#Else put Test Job in Queue
									if node.get('inUseDevices')==0:
										
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")
										#Create Jenkins Job for this Test Job & Trigger it on Test Bed
										
										setUp=JobPreSetup.SetUp()
										
										logger.log(1,"testRecord Test IDs1: "+str(testRecord[8]),"I")
										
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] DictRecord Before: "+str(testRecord),"I")
										dictRecord=self.convertToDictionary(testRecord)
										
										logger.log(1,"Before Test IDs2: "+str(dictRecord.get('selected_tc_ids')),"I")
										
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] DictRecord Before: "+str(dictRecord),"I")
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] TestCases.xml file created","D")
											#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node.get('node'), node.get('devices'), node.get('support_devices'), preSetUP[1])
											#If Test Job Started; then only put its corresponding Test Record in Running Jobs List
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:

												

												#Lock the Devices
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Locking Devices before Starting Test Job","I")

												if len(node.get('devices'))!= 0:
												
													
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Locking Device: "+str(node.get('devices')[0].get('serialno')),"D")
													
													lockResult = self.lock_device(nodeip=node.get('devices')[0].get('node'), serialno=node.get('devices')[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
													
													logger.log(1,lockResult,"I")
													if lockResult==True:
														
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Successfully Locked Device","D")

													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Setting flash status as true","I")
												
													flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=node.get('devices')[0].get('serialno'))
													logger.log(1,flashresult,"I")
													
													if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
														
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Successfully Set flash status as true","D")
												logger.log(1,"Sec dev list:"+str(node.get('support_devices')),"I")
												if len(node.get('support_devices'))!= 0:
													i =0
												
													while i < expectedDevicecount:
														seclistjob.append(node.get('support_devices')[i].get('serialno'))
					
														logger.log(1,"[MatchFinder_startProcess_TestBed_AND_DeviceSelected] Locking Device: "+str(node.get('support_devices')[i].get('serialno')),"D")
														
														lockResultsec = self.lock_device(nodeip=node.get('support_devices')[i].get('node'), serialno=node.get('support_devices')[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResultsec,"I")
														if lockResultsec==True:
															
															logger.log(1,"[MatchFinder_startProcess_TestBed_AND_DeviceSelected] Successfully Locked Secondary Device","D")	
														i=i+1



												#Add Test Bed & Device Data to Test Record (For Auto Mode)


												if lockResultsec != False and lockResult != False:



													jobStatus=job.startProcess()
													
													if jobStatus[0]:
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Putting Test Bed & Device Details: ","I")
												
														logger.log(1,node.get('node').get('location'),"I")
												
														logger.log(1,node.get('node').get('friendlyname'),"I")
												
														logger.log(1,node.get('devices')[0].get('serialno'),"I")
														dictRecord['location']=node.get('node').get('location')
														dictRecord['test_bed_name']=node.get('node').get('friendlyname')
														dictRecord['devices']=node.get('devices')[0].get('serialno')
														dictRecord['support_devices']=",".join(seclistjob)

												
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] DictRecord Devices 2: "+str(dictRecord),"I")

														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
													
															logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Test Job put into Running List","D")
														testJobScheduled=True

														break
													else:
														logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
														logger.log(1, "[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Devices after failure in Starting Test Job","I")
														for device in node.get('devices'):
													
															logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"D")
													
															unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
															flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_false', serialno=device.get('serialno'))
													
															logger.log(1,unLockResult,"I")
														for device in node.get('support_devices'):
													
															logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"D")
													
															unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
													
															logger.log(1,unLockResult,"I")
												else:
													
													logger.log(1,"Error in locking device. Job put into queue","I")
													#job.removefromjenkins(str(jobStatus[1]),node.get('node').get('friendlyname'))	
													logger.log(1,"Error in locking device...","I")
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(self.convertToDictionary(testRecord))
													self.testQueue.close()
													self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Auto Job is inserted into queue for build no. '+str(testRecord[2])+'\n\n',[])
													logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins,email sent for./build no."+str(testRecord[2]),"I")
													testJobScheduled=True
													#self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'], 'Dear admin,\n\n CLM was not able to lock the device at devicefarm side,put the job with script  :'+str(testRecord[10])+' in queue'+'\n\n',[])	
													break


											else:
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
												
												logger.log(1, "[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Devices after failure in Starting Test Job","I")
												for device in node.get('devices'):
													
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"D")
													
													unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
													flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_false', serialno=device.get('serialno'))
													
													logger.log(1,unLockResult,"I")
												for device in node.get('support_devices'):
													
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] UnLocking Device: "+str(device.get('serialno')),"D")
													
													unLockResult = self.unlock_device(nodeip=device.get('node'), serialno=device.get('serialno'), operation='unlock_device')
													
													logger.log(1,unLockResult,"I")
		#############################################################################################################################################	
									else:
										#Put Test Job in Queue
										
										matchdevices.append(node.get('devices')) 
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] matchdevioces"+str(matchdevices),"D")	
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So put Test Job in Auto Queue","I")
										logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] testjobscheduled"+str(testJobScheduled),"I")
										
										pass
							#If Test Job is not scheduled for some reason; the look for Locked Devices List.
							# So that if any match found from Locked Devices's List Scheduler can put Job in Queue
							if testJobScheduled==False:
								print "[startProcess]: Looking for Locked Devices 1"
								if len(lockedDevicesList)>0:
									devicetype = "Primary"
									lockedDevices=self.lookForLockedDevices(lockedDevicesList, testRecord,devicetype)
									print "[startProcess]: Put Test Job in Queue, as Test Job is not scheduled for some reason"
									
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(self.convertToDictionary(testRecord))
									self.testQueue.close()
								elif (seclockedcount!=0):
									devicetype = "Secondary"
									
									logger.log(1,"[startProcess]: Put Test Job in Queue, as Test Job is not scheduled since necessary unlocked secondary devices are not available","I")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(self.convertToDictionary(testRecord))
									self.testQueue.close()

								elif len(matchdevices)>0:

									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So put Test Job in Auto Queue","D")							
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(self.convertToDictionary(testRecord))
									self.testQueue.close()
									

						
								else:
									
									if lockflagHw!= 'true':
										#Send EMAIL Notification to Device Farm Admin
										self.email.sendMailNotification(Config['send_from'],Config['send_to']+","+Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n No Node found with matching HW capabilities for Locked as well as Unlocked Devices.Expected Hardware capabilities :'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
										print "[startProcess]: No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1"
										logger.log(1,"[startProcess]: No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1","I")						
							pass
		#############################################################################################################################################	
				elif inusehardwarecheck==False and foundAllHWCapNode!=True:
					
					logger.log(1, "[MatchFinder_startProcess_Find_TestBed_Device] Looking for Locked Devices 2","D")
					if len(lockedDevicesList)>0:
						devicetype = "Primary"
						lockedDevices=self.lookForLockedDevices(lockedDevicesList, testRecord, devicetype)
						if lockedDevices==True:
							
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] Put Test Job in Queue, as Match found from Locked Devices","D")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
		
						else:
							#Send EMAIL Notification to Device Farm Admin
							
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nNo Node found with matching HW Capabilities for Locked as well as Unlocked Devices.Expected hardware capabilities:'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 3","I")
					elif (unlockedSecDevices < expectedDevicecount and seclockedcount!=0):
							devicetype = "Secondary"
							
							logger.log(1,"[MatchFinder_startProcess_NothingSelected] Put Test Job in Queue, as Match found from Locked Devices","I")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
					
					elif (unlockedSecDevices < expectedDevicecount and seclockedcount==0):
							devicetype = "Secondary"
							
							logger.log(1,"[MatchFinder_startProcess_NothingSelected] No matching support devices found. Send email","I")
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_sufficient_supportdevice'],'Dear admin,\n\n No Node found with sufficient number of support devices in any node.Expected number of support devices:'+str(expectedDevicecount)+'Expected hardware capabilities:'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
									


					else:
						
						if lockflagHw != 'true':
							#Send EMAIL Notification to Device Farm Admin
							
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\n No Node found with matching HW Capabilities for Locked as well as Unlocked Devices.Expected hardware capabilities:'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
							logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] No Node found with matching HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 2","I")
							
					pass

			

		except Exception,e:
			print str(e)
			logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]Exception"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Lock Releasing","I")


	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of unlocked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked		
    	# os	string			OS version to be checked			
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# unlockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################
	
	def checkunlockeddevices(self, product,os,nodename,testRecord):
		logger.log(1,"Inside unlocked devices","I")
		unlockedcount = 0
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices=  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		
		for device in devices['devices']:
			
			result=self.checkfordevice(testRecord,device)
			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os and device.get('secondary')=='false' and result==True:
					if str(device.get('locked').lower()) != 'true':
						unlockedcount=unlockedcount+1
					else:
						pass
		return unlockedcount

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find no of locked decices of required product and version for a particular node in Manual Mode	#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# product	string		Product to be checked		
    	# os	string			OS version to be checked			
    	# nodename	string		Nodename to be checked						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# lockedcount	decimal		Number of unlocked devices															#
    	#################################################################################################################
	
	def checklockeddevices(self, product,os,nodename):
		
		lockedcount = 0
		self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
		devices =  self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_online_devices_from_node_name',nodename=nodename)
		for device in devices['devices']:
			if str(device.get('name'))== product and str(device.get('version').split("-")[1])== os:
					if str(device.get('locked').lower()) == 'true':
						lockedcount=lockedcount+1
					else:
						pass
		return lockedcount
					
	################################################################################################################
	# SYNOPSIS:													#
    	# Find status of node availability#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	dictionary	Record to be checked		
    	# node	    dictionary  Node to be checked	
	# swcap		list		List of software capabilities to be checked
	# hwcap		list 		List of hardware capabilities to be checked		
    	# 						#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# 	# checknode	String	Node status 															#
    	#################################################################################################################
	
	def checknode(self, record,swcap,hwcap,node={}):
		checknode = None
		logger.log(1,"Inside checknode","I")
		noofunlocked = self.checkunlockeddevices(record[3],record[4], node['friendlyname'],record)
		logger.log(1,"No of unlocked device:"+str(noofunlocked),"I")
		result=self.findSWCap(record[11].split(','), swcap)
		hwresult=self.findHWCap(record[12].split(','), hwcap)
		if result == 0 and hwresult==0:
			if noofunlocked >= 1:
				if int(record[14]) >1:	
					noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
					if noofavailsecdev >= int(record[14])-1: 
						checknode = "true"
					else:
						logger.log(1,"Required secondary devices not available","I")
						checknode = "Sec_unavail"
				else:
					checknode = "true"
			else:
				checknode = "Pri_unavail"
		else:
			
			checknode = "SW-HW cap not matching"
		logger.log(1,"Checknode return value:"+str(checknode),"I")
		return checknode	
	
	
	#########################################################################################################
	# SYNOPSIS:												#
    	# Check if locked devices are available in the testbed selected	#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter		Type		Note									#
    	# self			Object		Pointer to current object						#
    	# testRecord		Dictionary	Test Record	
	# lockedDevicesList	List		List of locked devices							#
	# devicetype		String		Type of device-primary or secondary							#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# True		Positive return
	# False		Negative return													#
    	#########################################################################################################



	def lookForLockedDevices_TestBedSelected(self, lockedDevicesList, testRecord,deviceType):
		try:

			self.lock.acquire()
			
			logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] HW Capabilities of Test Record: "+str(testRecord.get('hw_cap')),"I")
			#Maintain Device Info for Scheduling purpose 
			deviceList=[]
			secdeviceList=[]
			unlockedDevices=0
			unlockedSecDevices=0
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			for device in lockedDevicesList:
				
				logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] Locked Device: ","D")
				
				logger.log(1,device,"I")
				if deviceType== 'Primary':
						
						logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] All HW Capabilities of Locked Device Matched","D")
						deviceList.append(device)
						foundAllHWCapNode=True
						foundAllHWCapDevice=True
						unlockedDevices=unlockedDevices+1
					
			

			if foundAllHWCapDevice==True:
				
				logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] Unlocked Devices: "+str(unlockedDevices),"D")
				
				logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] Required Support Devices for Test Execution: "+str(testRecord.get('support_device_count')+1),"I")
				if deviceType == 'Primary':
					if unlockedDevices>=1:
						
						logger.log(1,"[MatchFinder_lookForLockedDevices_TestBedSelected] Node has sufficient Device Count for Execution","D")
						return True
					else:
						return False
				
				
			else:
				return False						


		except Exception, e:
			
			logger.log(1,str(e),"E")
			return False


#######################################################################################################################################################
	#########################################################################################################
	# SYNOPSIS:												#
    	# Remove Topmost record from TBL_TEST_DETAILS table & start finding match for it			#
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_Find_Device(self, testRecord):
		try:
			####################
			#####File system lock
			#####################	
			
			logger.log(1,"MatchFinder startProcess startProcess_Find_Device TestRun DB connection opened","I")
			self.lock.acquire()
			logger.log(1,"[MatchFinder_startProcess_Find_Device]: Lock Locking","I")
			
			logger.log(1,"[MatchFinder_startProcess_Find_Device]: Test Suite SW Capabilities: ","I")
			
			logger.log(1,testRecord[11],"I")

			#Number of Devices Requiredlocation
			totalSupportDeviceCount=int(testRecord[14])
			
			logger.log(1,"[MatchFinder_startProcess_Find_Device] Total Device Count: "+str(totalSupportDeviceCount),"I")

			#Get Node Details from Device Farm Server
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			
			flag=False
			nodeWithFewHWCap =[]
			nodeWithAllCap = []
			nodeWithAllSWCap=[]
			nodeWithAllHWCap=[]
			nodeWithFewSWCap = []
			nodeWithPri=[]
			nodeWithSec=[]
			OnlineSecDevices=0
			foundAllHWCapNode=False
			foundAllHWCapDevice=False
			devavail = False
			foundNode = False
			matchedSecDeviceCounter = 0
			unlockedSecDevices = 0
			seclockedcount = 0
			expectedDevicecount = 0
			product = "NA"
			os_version = "NA"
			self.devicefarmdb = DB_Interface.devicefarm()
			prionodes= self.devicefarmdb.getprionodes(testRecord[28])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			nodestobechecked =[]
			nodewithlocked = []
			nodeavail = "false"
			lockeddev = 0
			lockResultsec=True
			lockResult=True
			logger.log(1,"Prionodes="+str(prionodes),"I")
			if prionodes!= None:
					x = len(prionodes)
			else:
					x = 0
			logger.log(1,"Length Prionodes x="+str(x),"I")
			if x != 0:
				logger.log(1,"Testbeds have been allocated to the scrum team :"+str(testRecord[28]),"D")
				for i in prionodes:
					node= self.devfarmconvertToDictionary(i)
					swCap=node.get('softwares').split(',')
					hwCap = node.get('hardwares').split(',')
					logger.log(1,"Node="+str(node),"I")
					logger.log(1,"Node type="+str(type(node)),"I")
					if node.get('friendlyname')== testRecord[17] and node.get('location')== testRecord[16]:
						foundNode = True
						nodeavail = self.checknode(testRecord,swCap,hwCap,node)
						logger.log(1,"Node avail="+str(nodeavail),"I")
					if nodeavail== "true" and foundNode == True:
						nodestobechecked.append(node)
						devavail = True
					elif nodeavail!= "SW-HW cap not matching":
							if node.get('friendlyname')== testRecord[17] and node.get('location')== testRecord[16]:
								
								lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))
								unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
								OnlineSecDevices= self.getSecondaryDevicecount(node)
								
								if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
									nodewithlocked.append(node)	
								
								else:
									continue
				if devavail!= True and foundNode == False:
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y = 0
					if y != 0:
						for j in commonnodes:
								node= self.devfarmconvertToDictionary(j)
								swCap=node.get('softwares').split(',')
								hwCap = node.get('hardwares').split(',')
								if node.get('friendlyname')== testRecord[17] and node.get('location')== testRecord[16]:
									foundNode = True
									nodeavail = self.checknode(testRecord,swCap,hwCap,node)
								if nodeavail== "true" and foundNode == True:
									nodestobechecked.append(node)
									logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
									devavail = True
								elif nodeavail!= "SW-HW cap not matching":
									if node.get('friendlyname')== testRecord[17] and node.get('location')== testRecord[16]:
										
										lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))

										unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
										
										OnlineSecDevices= self.getSecondaryDevicecount(node)
									if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
										nodewithlocked.append(node)
									else:
										pass
								
						if len(nodestobechecked)==0:	
							if foundNode == False:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node is not available for execution for the scrum team:'+str(testRecord[28])+' hence job:'+str(testRecord[10])+' will not be triggered'+'\n\n',[])
							if len(nodewithlocked) != 0:
								self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								self.testQueue.insert(self.convertToDictionary(testRecord))
								self.testQueue.close()
							else:
								logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
								
					else:

								if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(self.convertToDictionary(testRecord))
										self.testQueue.close()
									else:

										logger.log(1,"No node available required for execution.Send mail to admin","D")
							
							
							
							
					
				else:
					if len(nodewithlocked) != 0:
						logger.log(1,"Locked devices. Put job in queue","D")
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()
					else:
						logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","D")
						
			else:
				logger.log(1,"Commonnodes="+str(commonnodes),"D")
				logger.log(1,"Testbeds have not been allocated to the scrum team/user","I")
				if commonnodes!= None:
					y = len(commonnodes)
				else:
					y = 0
				logger.log(1,"Length of Commonnodes="+str(y),"I")
				if y != 0:
					for j in commonnodes:
							node= self.devfarmconvertToDictionary(j)
							swCap=node.get('softwares').split(',')
							hwCap = node.get('hardwares').split(',')
							if node.get('friendlyname')== testRecord[17] and node.get('location')== testRecord[16]:
								nodeavail = self.checknode(testRecord,swCap,hwCap,node)
								foundNode = True
							logger.log(1,"Node avail="+str(nodeavail),"I")
							if nodeavail== "true":
								nodestobechecked.append(node)
								logger.log(1,"Node to be checked ="+str(nodestobechecked),"I")
								devavail = True
													
							elif nodeavail!= "SW-HW cap not matching" :
								lockeddev = self.checklockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'))
								unlockeddev = self.checkunlockeddevices(testRecord[3],testRecord[4], node.get('friendlyname'),testRecord)
								OnlineSecDevices= self.getSecondaryDevicecount(node)
								if (lockeddev >= 1 and OnlineSecDevices >= int(testRecord[14])-1) or (unlockeddev>=1 and OnlineSecDevices >= int(testRecord[14])-1):
									nodewithlocked.append(node)
								else:
									pass
					if len(nodestobechecked)== 0: 
						if foundNode == False:
							logger.log(1,"No node has available locked or unlocked devices required for execution.Send mail to admin","I")
							self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node is not available for execution for the scrum team:'+str(testRecord[28])+' hence job:'+str(testRecord[10])+' will not be triggered'+'\n\n',[])
							return
						logger.log(1,"Nodes with locked ="+str(nodewithlocked),"I")
						if len(nodewithlocked) != 0:
							self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
							self.testQueue.insert(self.convertToDictionary(testRecord))
							self.testQueue.close()
						else:
							logger.log(1,"Requested node"+str(testRecord[17])+ " has no available locked or unlocked devices required for execution.Send mail to admin","I")
							
				else:
						if len(nodestobechecked)== 0: 

									logger.log(1,"Nodes with locked ="+str(nodewithlocked),"D")
									if len(nodewithlocked) != 0:
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(self.convertToDictionary(testRecord))
										self.testQueue.close()
									else:

										logger.log(1,"No node available required for execution.Send mail to admin","D")
					
					


#######################################################################################################################################################
			#Create Locked Devices's List; so that if any match found from this list, Scheduler can keept Test Job in Queue
			
#######################################################################################################################################################
			if len(nodestobechecked)== 0:
				if len(nodewithlocked) == 0:
					if commonnodes!= None:
						y = len(commonnodes)
					else:
						y = 0
				
					if x==0 and y!=0:
						commonandprionodes=commonnodes
					elif x!=0 and y==0:
						commonandprionodes=prionodes
					elif x!=0 and y!=0:
						commonandprionodes=list(prionodes)
						for k in commonnodes:
							commonandprionodes.append(k)
						commonandprionodes=tuple(commonandprionodes)
					elif x==0 and y==0:
						commonandprionodes=()
						logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] no node is available","D")	

					logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected]commonprionodes"+str(commonandprionodes),"D")


					if len(commonandprionodes)==0:
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node is  available for the user'+'\n\n',[])	
					else:

							
						for m in commonandprionodes:
							node= self.devfarmconvertToDictionary(m)




					
							lockflagHw = 'false'
						
						matchedDeviceCounter=0
						matchedSecDeviceCounter = 0
						
						dictRecord=self.convertToDictionary(testRecord)
						
						logger.log(1,"Scrum team for node:"+node.get('scrumteam'),"I")
						if node.get('location')==testRecord[16] and node.get('friendlyname')==testRecord[17] and node.get('nodejenkinsonlinestatus')=='online' and node.get('nodeonlinestatus')=='online' and (node.get('scrumteam')== "ALL" or node.get('scrumteam')== testRecord[28]):
								
								logger.log(1,"[MatchFinder_startProcess_Find_Device] Location Matched: "+str(testRecord[16]),"D")
								if node.get('friendlyname')==testRecord[17] and node.get('location')== testRecord[16]:
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] Test Bed Name Matched: "+str(testRecord[17]),"D")
									parallelnodestatus = node.get('parallelexec').lower()
									logger.log(1,"Parallel execution status="+str(parallelnodestatus),"I")
									swCap=node.get('softwares').split(',')
									hwCap = node.get('hardwares').split(',')
									result=self.findSWCap(testRecord[11].split(','), swCap)
									hwresult=self.findHWCap(testRecord[12].split(','), hwCap)
									logger.log(1,"[MatchFinder_startProcess_Find_Device]: Result of HwCap: "+str(hwresult),"I")
									noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
									noofunlocked = self.checkunlockeddevices(testRecord[3],testRecord[4], node['friendlyname'],testRecord)
									logger.log(1,"No of unlocked device:"+str(noofunlocked),"I")
									if int(testRecord[14]) >1:	
											logger.log(1,"Secondary matching","D")
											noofavailsecdev= self.getunlockedSecondaryDevicecount(node)
											if noofavailsecdev >= int(testRecord[14])-1: 
												nodeWithSec.append(node)
												secresult = True
											else:
												secresult = False
												logger.log(1,"Secondary not matching","I")
									else:
										secresult = True
									if secresult == True:
										nodeWithSec.append(node)
										logger.log(1,"Sec node matching","I")
										if result==0 and hwresult!= 0:
											#Put Node in nodeWithFewSWCap
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW Capabilities Found in this Node","D")
											nodeWithFewHWCap.append(node)
											nodeWithAllSWCap.append(node)
										elif result!=0 and hwresult== 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithAllHWCap.append(node)
										elif result!=0 and hwresult!= 0:
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] Few Test Suite HW and SW Capabilities Found in this Node","D")
											nodeWithFewSWCap.append(node)
											nodeWithFewHWCap.append(node)
										elif result == 0 and hwresult==0:
											#Put Node in nodeWithAllSWCap
											
											logger.log(1,"[ManualMatchFinder_startProcess_NothingSelected] All Test Suite HW Capabilities Found in this Node","D")
											
											nodeWithAllHWCap.append(node)
											nodeWithAllSWCap.append(node)	
											if noofunlocked >= 1:
												priavail= True
											else:
												priavail = False
											if priavail == True:
													nodeWithPri.append(node)								
													
													
											else:
												logger.log(1,"No primary devices available","I")
												
												
									else:
										logger.log(1,"Sufficient secondary dev not available","I")
										
								
								
									logger.log(1,"Nodes with sec:"+str(nodeWithSec),"I")
									logger.log(1,"Nodes with pri:"+str(nodeWithPri),"I")
									logger.log(1,"Nodes with sw:"+str(nodeWithAllSWCap),"I")
									logger.log(1,"Nodes with hw:"+str(nodeWithAllHWCap),"I")
									if len(nodeWithSec)== 0:
											
											self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no secondary devices required for execution of job:'+str(testRecord[10])+'. \nNumber of secondary devices required='+str(testRecord[14]-1)+'\n\n',[])
																			
									else:
																	
											if len(nodeWithAllSWCap)==0 :
												
												self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])						
												
												logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Required SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")
										
															
											elif len(nodeWithAllHWCap)==0 :
													self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no hardware capability required for execution of job:'+str(testRecord[10])+"\n Required hardware capability:"+str(testRecord[12])+'\n\n',[])	
													logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device]: Not a single HW Capability found in any Node; Send EMAIL notification to Device Farm Admin","I")
											
													pass
											elif len(nodeWithPri)== 0:
												productresult = self.checkproduct(testRecord)
												logger.log(1,"Product result="+str(productresult),"I")
												self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+'  has no devices required for execution of job:'+str(testRecord[10])+". Device required:\n Product:"+str(testRecord[3])+"\n OS Required:"+str(testRecord[4])+"\n"+str(productresult)+'\n\n',[])
								else:
									logger.log(1,"Test bed not matching","I")
											
						else:
							logger.log(1,"Requested node:"+str(testRecord[17])+" is not available for execution","D")
							if node.get('location') == testRecord[16] and node.get('friendlyname')==testRecord[17] and (node.get('scrumteam') != "ALL" or node.get('scrumteam') != testRecord[28]):
								logger.log(1,"Requested node:"+str(testRecord[17])+" is not assigned for scrum team:"+str(testRecord[28])+" for execution of job:"+str(testRecord[10]),"D")
								self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' is not assigned for scrum team:'+str(testRecord[28])+' for execution of job:'+str(testRecord[10])+'\n\n',[])

							else:
								logger.log(1,"Test location not matching/ requested node not online","D")
											

			if len(nodestobechecked)!= 0:
                
				logger.log(1,"[MatchFinder_startProcess_Find_Device] Found Nodes with all HW and SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")    
				for node in nodestobechecked:
					lockflagHw =  self.inUseHardware_nothingSelected(node.get('friendlyname'),testRecord[12].split(","))
										
					if lockflagHw== 'true':
						logger.log(1,"Matching External HW in use for node. Put  Test job in Queue","D")
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()
						break

					logger.log(1,"Node with both HW and SW capability:"+str(nodeWithAllCap),"D")

					if lockflagHw != 'true' and node.get('friendlyname')==testRecord[17] and node.get('location')== testRecord[16]:
						
							
							lockedDevicesList=[] 
							seclockedDevicesList=[] 
							seclistjob = []
							matchedDeviceCounter=0
							matchedSecDeviceCounter = 0
							parallelnodestatus = node.get('parallelexec').lower()
							print "Parallel execution status=",parallelnodestatus
							swCap=node.get('softwares').split(',')
							hwCap = node.get('hardwares').split(',')
							dictRecord=self.convertToDictionary(testRecord)
							
							foundAllCapNode = True

						
							#Unlocked Devices Counter
							unlockedDevices=0
							unlockedSecDevices=0
							matchedSecDevCounter = 0
							
							logger.log(1,node,"I")
							
							
							onlineDevices=self.deviceFarm.get_all_online_devices_from_node_name(operation='get_all_devices_from_node_name', nodename=node.get('friendlyname'))

							
							logger.log(1,"[MatchFinder_startProcess_Find_Device] Online Devices for this Node: ","I")
							
							foundAllHWCapDevice=False
							
							countOfDevices=len(onlineDevices.get('devices'))
							#Maintain Device Info for Scheduling purpose 
							deviceList=[]
							secdeviceList=[]
							inUseDevices=0
							inUseSecDevices=0
							if countOfDevices==0:
								
								logger.log(1, "[MatchFinder_startProcess_Find_Device] Recieved Empty Device List from Device Farm","D")

							matchedSecDeviceCounter = self.getSecondaryDevicecount(node)
							unlockedSecDevices = self.getunlockedSecondaryDevicecount(node)
							seclockedcount = int(matchedSecDeviceCounter) - int(unlockedSecDevices)

							for device in onlineDevices.get('devices'):
								
								logger.log(1,device,"D")
								if device.get('status')=='online' and device.get('locked')=='false' and ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')):
									
									logger.log(1, "[MatchFinder_startProcess_Find_Device] Device is Online & Unlocked","D")
									#Get Product & OS Information for all selected Online Devices from above step &
									#Select only those Devices, which have matching Product &
									#OS info mentioned in record['product'] & record['os']
									
									logger.log(1, "[MatchFinder_startProcess_Find_Device] Matching Product & OS","I")
																		
									logger.log(1,device.get('name')+testRecord[3],"I")
									
									logger.log(1,str(device.get('version')).split("-")[1]+str(testRecord[4]),"I")
									
									result=self.checkfordevice(testRecord,device)
									if result==True:
										
										product = str(device.get('name'))
										os_version = str(device.get('version')).split("-")[1]
										logger.log(1,"[MatchFinder_startProcess_Find_Device] Device Product, OS Matched","D")
										
										#Get Devices which has all HW Capabilities mentioned in 									
										#If there is no Device found in any Node, then send EMAIL to Device
										#Farm Admin; Else Continue next Step
										
										if device.get('secondary')=='false': 
												
												deviceList.append(device)
												foundAllHWCapNode=True
												foundAllHWCapDevice=True
												unlockedDevices=unlockedDevices+1
											
										
								else:
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] Device is either Locked or Offline; So put Device in Locked Devices List","D")

							
									if device.get('secondary')=='false': 
										inUseDevices=inUseDevices+1
							
									
									#Match Product & OS Version Before putting to List; Don't Put any Locked Device (Want only matching Locked Devices)
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] Matching Product & OS of Locked Device: ","I")
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] Device Property : Test Suite Property","I")
									
									logger.log(1,device.get('name')+" : "+ str(testRecord[3]),"I")
									
									logger.log(1,str(device.get('version')).split("-")[1]+" : "+str(testRecord[4]),"I")
									if ('unauthorized' not in device.get('serialno')) and ('offline' not in device.get('serialno')) and device.get('secondary')=='false':
										
										result=self.checkfordevice(testRecord,device)
										if result==True:
											
											product = str(device.get('name'))
											os_version = str(device.get('version')).split("-")[1]
											logger.log(1,"[MatchFinder_startProcess_Find_Device] Locked Device's Product, OS Matched for Primary Device","I")
											lockedDevicesList.append(device)


										#######################################################################################################################################################
							totalSupportDeviceCount = int(testRecord[14])
							logger.log(1, "Total device count:"+str(totalSupportDeviceCount),"I")
							if totalSupportDeviceCount <= 1:
								expectedDevicecount = 0
							else:
								expectedDevicecount = totalSupportDeviceCount - 1

							logger.log(1,"Matched sec devices:"+str(matchedSecDeviceCounter),"I")


							if foundAllHWCapDevice==True and (matchedSecDeviceCounter>= expectedDevicecount):
								
								logger.log(1,"[MatchFinder_startProcess_Find_Device] Unlocked Devices: "+str(unlockedDevices),"D")

								logger.log(1,"[MatchFinder_startProcess_TestBedSelected] Unlocked Secondary Devices: "+ str(unlockedSecDevices),"I")
								
								logger.log(1,"[MatchFinder_startProcess_TestBedSelected] Required Support Devices for Test Execution: "+str(expectedDevicecount),"I")
								logger.log(1,"[MatchFinder_startProcess_TestBedSelected] locked Secondary Device count: "+ str(seclockedcount),"I")
								
								#Check testRecord['support_device_count'] info & verify whether Node has sufficient
								#device count for execution
								if (unlockedDevices >= 1) and (unlockedSecDevices >=int(expectedDevicecount)):
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] Node has sufficient Device Count for Execution","D")
									
									logger.log(1,"[MatchFinder_startProcess_Find_Device] In Use Primary Devices for Node: "+str(inUseDevices),"I")

									logger.log(1,"[MatchFinder_startProcess_Find_Device] In Use Secondary Devices for Node: "+str(seclockedcount),"I")
								
									
									testJobScheduled=False
									secdeviceList = self.lookforSecondarydevices(node, expectedDevicecount)
									
									logger.log(1,"Parallel execution status="+str(parallelnodestatus),"D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									QUERY='SELECT priority FROM TBL_TEST_QUEUE where product="'+product+'" AND os="' + os_version+'" ORDER BY priority;'
									NewQueueRecord=self.testQueue.execute(QUERY, "SELECT")
									lenQueue = len(NewQueueRecord)
									
							
									if NewQueueRecord!= ():
										minimum= min(NewQueueRecord)
										logger.log(1,"Minimum priority="+str(minimum),"I")
										logger.log(1,"Current priority="+str(testRecord[29]),"I")
										if int(testRecord[29]) >= int(minimum[0]):
											self.testQueue.insert(self.convertToDictionary(testRecord))
											break
										
									self.testQueue.close()

	#######################################################################################################################################################
									if parallelnodestatus =='true':
										
										logger.log(1, "[MatchFinder_startProcess_Find_Device] Node is Parallel Execution Capable; So Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")
										#Create Test Job & Trigger it
										
										logger.log(1, "[MatchFinder_startProcess_Find_Device] Trigger Test Job on Device","I")
									
										#Create testCase.xml file for Test Job Execution
										setUp=JobPreSetup.SetUp()
										dictRecord=self.convertToDictionary(testRecord)
										preSetUP=setUp.doPreSetUp(dictRecord)
										if preSetUP[0]==True:
											
											logger.log(1,"[MatchFinder_startProcess_Find_Device] TestCases.xml file created","D")
											#Pass thi TestCases.xml file name, Node & record to Jenkins Job Creation Module
											job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
											#If Test Job Started; then only put its corresponding Test Record into Running Test Jobs List
											#jobStatus=job.startProcess()
											#if jobStatus[0]:
											if True:
												
												

												#Lock the Devices
												
												logger.log(1,"[MatchFinder_startProcess_Find_Device] Locking Devices before Starting Test Job","I")
												
												if deviceList!= None:
														logger.log(1,"[MatchFinder_startProcess_Find_Device] Locking Device: "+str(deviceList[0].get('serialno')),"I")
											
														
														lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
														flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))
														if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
															
															logger.log(1,"[MatchFinder_startProcess_Find_Device] Successfully Set flash status as true","D")

												logger.log(1,"Sec dev list:"+str(secdeviceList),"I")
												if len(secdeviceList)!= 0:
													i= 0
													
													while i < expectedDevicecount:
														seclistjob.append(secdeviceList[i].get('serialno'))
														logger.log(1,"[MatchFinder_startProcess_Find_Device] Locking Device: "+str(secdeviceList[i].get('serialno')),"I")

														
														lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														i= i+1
														
											

														logger.log(1,lockResultsec,"I")

												#Add Test Bed & Device Data to Test Record (For Auto Mode)
												

												if  lockResultsec != False and lockResult != False:
													jobStatus=job.startProcess()
													if jobStatus[0]:

														logger.log(1, "[MatchFinder_startProcess_Find_Device] Putting Test Bed & Device Details: ","I")
												
														logger.log(1,deviceList[0].get('serialno'),"I")
														logger.log(1,seclistjob,"I")
														dictRecord['devices']=deviceList[0].get('serialno')
														dictRecord['support_devices']=",".join(seclistjob)


														if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
													
															logger.log(1, "[MatchFinder_startProcess_Find_Device] Test Job put into Running List","D")
														break
													else:

														logger.log(1,  "[MatchFinder_startProcess_Find_Device] There is error in creating & starting Test Job; So put the Test Record in Manual Jobs Queue & Unlock Devices which are locked for this Test Job","D")
														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														self.testQueue.insert(self.convertToDictionary(testRecord))
														self.testQueue.close()
												
														logger.log(1,  "[MatchFinder_startProcess_Find_Device] UnLocking Devices after failure in Starting Test Job","I")
												
														if deviceList!= None:
															logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Device: "+str(deviceList[0].get('serialno')),"D")
													
															unLockResult = self.unlock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), operation='unlock_device')
															logger.log(1,unLockResult,"I")
														flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))
												
														logger.log(1,unLockResult,"I")
												
														if seclistjob!= None:
																								
															j = 0
												
															while j < expectedDevicecount:
																	logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Secondary Device: "+str(seclistjob[j]),"I")
															
																	unLockResult = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
													
																	
																	j=j+1
														break																

												else:
													logger.log(1,"Error in locking device. Job put into queue","I")
													#job.removefromjenkins(str(jobStatus[1]),node.get('friendlyname'))	
													logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","I")
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(self.convertToDictionary(testRecord))
													self.testQueue.close()
													#self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Job is inserted into queue.Expected hardware dependencies'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS version:"+str(testRecord[4])+"\n\n",[])
													self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Auto Job is inserted into queue for build no. '+str(testRecord[2])+'\n\n',[])	

													break


											else:
												
												logger.log(1,  "[MatchFinder_startProcess_Find_Device] There is error in creating & starting Test Job; So put the Test Record in Manual Jobs Queue & Unlock Devices which are locked for this Test Job","D")
												self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
												self.testQueue.insert(self.convertToDictionary(testRecord))
												self.testQueue.close()
												
												logger.log(1,  "[MatchFinder_startProcess_Find_Device] UnLocking Devices after failure in Starting Test Job","I")
												
												if deviceList!= None:
													logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Device: "+str(deviceList[0].get('serialno')),"D")
													
													unLockResult = self.unlock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), operation='unlock_device')
													logger.log(1,unLockResult,"I")
												flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))
												
												logger.log(1,unLockResult,"I")
												
												if seclistjob!= None:
																								
													j = 0
												
													while j < expectedDevicecount:
															logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Secondary Device: "+str(seclistjob[j]),"I")
															
															unLockResult = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
													
															logger.log(1,unLockResult,"I")
															j=j+1
	#######################################################################################################################################################
									else:
										
										logger.log(1,"[MatchFinder_startProcess_Find_Device] Node is not Parallel Execution Capable","D")
										#Check whether there is any already ongoing execution on Test Bed
										#If no Ongoing execution then Schedule test Job 
										#& trigger it on Test Bed
										#Else put Test Job in Queue
										
										dictRecord=self.convertToDictionary(testRecord)
										if inUseDevices==0:
											
											logger.log(1,   "[MatchFinder_startProcess_Find_Device] There is no ongoing execution on Node; Create Jenkins Job for this Test Job & Trigger it on Test Bed","D")
											#Create Jenkins Job for this Test Job & 
											#Trigger it on Test Bed
											#Create Test Job & Trigger it
											
											logger.log(1,"[MatchFinder_startProcess_Find_Device] Trigger Test Job on Device","I")
											#Create testCase.xml file for Test Job Execution
											setUp=JobPreSetup.SetUp()
											
											preSetUP=setUp.doPreSetUp(dictRecord)
											if preSetUP[0]==True:
												
												logger.log(1,"[MatchFinder_startProcess_Find_Device] TestCases.xml","D")
												#Pass this TestCases.xml file name, Node & record to Jenkins Job Creation Module
												job=StartJob.JenkinsJob(dictRecord, node, deviceList,secdeviceList, preSetUP[1])
												#If Test Job Started; then only remove its corresponding Test Record from Queue
												#jobStatus=job.startProcess()
												#if jobStatus[0]:
												if True:
													
													

													#Lock the Devices
													
													logger.log(1, "[MatchFinder_startProcess_Find_Device] Locking Devices before Starting Test Job","I")
													if deviceList!= None:
														logger.log(1,"[MatchFinder_startProcess_Find_Device] Locking Device: "+str(deviceList[0].get('serialno')),"I")
														
														lockResult = self.lock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
														
														logger.log(1,lockResult,"I")
													
														
														logger.log(1,  "[MatchFinder_startProcess_Find_Device] Successfully Locked Device","I")


													flashresult=self.deviceFarm.set_flash_status_true(operation='set_flash_status_true', serialno=deviceList[0].get('serialno'))
										
													if flashresult.get('flash_status')=='true' and flashresult.get('result')=='ok':
														
														logger.log(1,"[MatchFinder_startProcess_Find_Device] Successfully Set flash status as true","D")

													logger.log(1,"Sec dev list:"+str(secdeviceList),"I")
													if len(secdeviceList)!= 0:
														seclistjob = []
														i = 0
														while i < expectedDevicecount:
															seclistjob.append(secdeviceList[i].get('serialno'))
													
															#lockResult=self.lockDevices(str(secdeviceList[i].get('serialno')))
															lockResultsec = self.lock_device(nodeip=secdeviceList[i].get('node'), serialno=secdeviceList[i].get('serialno'), user=dictRecord.get('user'), operation='lock_device', lockingTool='CLM')
															i= i+1

													#Add Test Bed & Device Data to Test Record (For Auto Mode)


													if lockResultsec != False and lockResult != False:
														
														jobStatus=job.startProcess()
														if jobStatus[0]:
															logger.log(1,   "[MatchFinder_startProcess_Find_TestBed_Device] Putting Test Bed & Device Details: ","I")
													
															logger.log(1,deviceList[0].get('serialno'),"I")
															logger.log(1,seclistjob,"I")
															dictRecord['devices']=deviceList[0].get('serialno')
															dictRecord['support_devices']=",".join(seclistjob)
															if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
														
																logger.log(1,   "[MatchFinder_startProcess_Find_Device] Test Job put into Running List","D")
															break
														else:
															logger.log(1,    "[MatchFinder_startProcess_Find_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
															self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
															self.testQueue.insert(dictRecord)
															self.testQueue.close()
													
															logger.log(1,    "[MatchFinder_startProcess_Find_Device] UnLocking Devices after failure in Starting Test Job","I")

															if deviceList!= None:
																logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Device: "+str(deviceList[0].get('serialno')),"I")
														
																unLockResult = self.unlock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), operation='unlock_device')
														
																logger.log(1,unLockResult,"I")
																flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))
															if seclistjob!= None:
															
																j = 0
																while j < expectedDevicecount:
																	logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Secondary Device: "+str(seclistjob[j]),"I")
															
																	unLockResult = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
															
																	logger.log(1,unLockResult,"I")
																	j=j+1
															break

													else:
														logger.log(1,"Error in locking device. Job put into queue","I")
														#job.removefromjenkins(str(jobStatus[1]),node.get('friendlyname'))	
														logger.log(1,"Error in locking device. Job put into queue and killed job from jenkins","I")



														self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
														self.testQueue.insert(dictRecord)
														self.testQueue.close()
														#self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Job is inserted into queue.Expected hardware dependencies'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS version:"+str(testRecord[4])+"\n\n",[])

														self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Unable_to_lock_device'],'Dear admin,\n\nCLM is not able to lock the device at devicefarm side.Auto Job is inserted into queue for build no. '+str(testRecord[2])+'\n\n',[])			

														break

												else:
													
													logger.log(1,    "[MatchFinder_startProcess_Find_Device] There is error in creating & starting Test Job; So put the Test Record in Queue & Unlock Devices which are locked for this Test Job","D")
													
													self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
													self.testQueue.insert(dictRecord)
													self.testQueue.close()
													
													logger.log(1,    "[MatchFinder_startProcess_Find_Device] UnLocking Devices after failure in Starting Test Job","I")

													if deviceList!= None:
														logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Device: "+str(deviceList[0].get('serialno')),"I")
														
														unLockResult = self.unlock_device(nodeip=deviceList[0].get('node'), serialno=deviceList[0].get('serialno'), operation='unlock_device')
														
														logger.log(1,unLockResult,"I")
														flashresult=self.deviceFarm.set_flash_status_false(operation='set_flash_status_false', serialno=deviceList[0].get('serialno'))
													if seclistjob!= None:
															
														j = 0
														while j < expectedDevicecount:
															logger.log(1,"[MatchFinder_startProcess_Find_Device] UnLocking Secondary Device: "+str(seclistjob[j]),"I")
															
															unLockResult = self.unlock_device(nodeip=secdeviceList[j].get('node'), serialno=seclistjob[j], operation='unlock_device')
															
															logger.log(1,unLockResult,"I")
															j=j+1

										else:
											#Put Test Job in Queue
											
											logger.log(1,"[MatchFinder_startProcess_Find_Device] Test bed found, but there is already execution ongoing & it is not parallel execution capable; So Put the Test Job in Queue","D")
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											self.testQueue.insert(dictRecord)
											self.testQueue.close()
											pass
	#######################################################################################################################################################
								else:
									#Put Test Job in Queue
									
									logger.log(1, "[MatchFinder_startProcess_Find_Device] Node has no sufficient Device Count for execution","D")
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(dictRecord)
									self.testQueue.close()	
	#######################################################################################################################################################
							else:
								
								logger.log(1,"[MatchFinder_startProcess_Find_Device] Looking for Locked Devices","D")
								if len(lockedDevicesList)>0:
									
										deviceType = "Primary"
									
										if self.lookForLockedDevices_TestBedSelected(lockedDevicesList, self.convertToDictionary(testRecord), deviceType)==True:
											
											logger.log(1,"[MatchFinder_startProcess_Find_Device] No Devices Found from this Node which has All HW Capabilities; so put the Test Job in Queue","D")
											#Put Test Job in Queue
											self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
											self.testQueue.insert(self.convertToDictionary(testRecord))
											self.testQueue.close()	
										else:
											#Send EMAIL Notification to Device Farm Admin



											

											
											self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nRequested testbed'+str(node.get('friendlyname'))+'not having matching primary devices for locked as well as unlocked devices for script:'+str(testRecord[10])+'.\nExpected hardware capabilities:'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
											logger.log(1,"[MatchFinder_startProcess_Find_Device] No Devices Found from this Node which has All HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 1","I")
								
								elif (seclockedcount!=0 and unlockedSecDevices< expectedDevicecount):
									
										deviceType = "Secondary"
									
										logger.log(1,"[MatchFinder_startProcess_Find_Device] No Devices Found from this Node which has All HW Capabilities; so put the Test Job in Queue","D")
										#Put Test Job in Queue
										self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
										self.testQueue.insert(self.convertToDictionary(testRecord))
										self.testQueue.close()
								elif (seclockedcount==0 and unlockedSecDevices< expectedDevicecount):
											#Send EMAIL Notification to Device Farm Admin
											
											self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nSufficient support devices not found in requested testbed.'+str(node.get('friendlyname'))+' for script:'+str(testRecord[10])+'\nExpected number of support devices:'+str(expectedDevicecount)+"\n\n",[])
											logger.log(1,"[MatchFinder_startProcess_Find_Device] Sufficient support devices not found in requested testbed.","I")

								else:
									#Send EMAIL Notification to Device Farm Admin
									
									self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['No_HW_Cap'],'Dear admin,\n\nRequested testbed'+str(node.get('friendlyname'))+' not having found with matching HW Capabilities for Locked as well as Unlocked Devices.Expected hardware capabilities:'+str(testRecord[12])+"\nExpected product:"+str(testRecord[3])+"\nExpected OS versions:"+str(testRecord[4])+"\n\n",[])
									logger.log(1,"[MatchFinder_startProcess_Find_TestBed_Device] No Devices Found from this Node which has All HW Capabilities for Locked as well as Unlocked Devices; Send EMAIL Notification to Device Farm Admin 2","I")
#######################################################################################################################################################
					else:
						
						logger.log(1,"[MatchFinder_startProcess_Find_Device] Test Bed Name not Matched: "+str(node.get('friendlyname')),"D")
#######################################################################################################################################################
			else:
					
				
				logger.log(1,"[MatchFinder_startProcess_Find_Device] Test Bed Location not having required capabilities/devices to execute the job. Test bed name: "+str(testRecord[16]),"D")

#######################################################################################################################################################
		except Exception, e:
			
			
			logger.log(1,str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[MatchFinder_startProcess_Find_Device]: Lock Releasing","I")


#####################################################################################################################################

	#########################################################################################################
	# SYNOPSIS:												#
    	# Remove Topmost record from TBL_TEST_DETAILS table & start finding test bed  for it.                   # 
        # For non mobile test bed  selected                                                                     #
	#########################################################################################################
    	# INPUT DATA:												#
    	# Parameter	Type		Note									#
    	# self		Object		Pointer to current object						#
	#########################################################################################################
    	# OUTPUT DATA:												#
    	# NA													#
    	#########################################################################################################
	def startProcess_System_selected(self, testRecord):
		try:
			####################
			#####File system lock
			#####################	
			
			logger.log(1,"MatchFinder startProcess_System_selected TestRun test record"+str(testRecord),"I")
			self.lock.acquire()
			logger.log(1,"[MatchFinder_startProcess_System_selected]: Lock Locking","I")
			
			logger.log(1,"[MatchFinder_startProcess_System_selected]: Test Suite SW Capabilities: ","I")
			
			logger.log(1,testRecord[11],"I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')
			foundAllHWCapNode=False
			flag=False
			nodeWithFewHWCap =[]
			nodeWithAllCap = []
			nodeWithFewSWCap = []


			self.devicefarmdb = DB_Interface.devicefarm()
			
			prionodes= self.devicefarmdb.getprionodes(testRecord[28])
			commonnodes= self.devicefarmdb.getcommonnodes()
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			nodestobechecked =[]
			nodewithlocked = []
			nodeavail = "false"
			lockeddev = 0
			logger.log(1,"Prionodes="+str(prionodes),"I")
			foundNode=False
			lockflag=False
			foundincommonNode=False
			nodematchingallswcap='false'
			if prionodes!= None:
					x = len(prionodes)
			else:
					x = 0
			logger.log(1,"Length Prionodes x="+str(x),"I")
			if x != 0:
				logger.log(1,"Testbeds have been allocated to the scrum team :"+str(testRecord[14]),"D")
				for i in prionodes:
					node= self.devfarmconvertToDictionary(i)
					swCap=node.get('softwares').split(',')
					if node.get('friendlyname')== testRecord[17] and node.get('location')==testRecord[16]:
						foundNode = True
						nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
						logger.log(1,"Node avail="+str(nodeavail),"I")
			
					


					if nodematchingallswcap== "true" and foundNode == True:
						nodeWithAllCap.append(node)
					elif nodematchingallswcap== "false" and foundNode == True:
						#send mail not matching sw
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])					
						pass
				
				
			if x==0 or foundNode==False:
				for i in commonnodes:
					node= self.devfarmconvertToDictionary(i)
					swCap=node.get('softwares').split(',')
					logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] x==0 "+str(node.get('friendlyname'))+str(testRecord[17]),"D")

					logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] x==0 "+str(node.get('location'))+str(testRecord[16]),"I")
					if node.get('friendlyname')== testRecord[17] and node.get('location')==testRecord[16]:
						foundincommonNode = True
						nodematchingallswcap = self.checksystem(testRecord,swCap,node)#chnage checknode
						logger.log(1,"Node avail="+str(nodeavail),"I")

					


					if nodematchingallswcap== "true" and foundincommonNode == True:
						nodeWithAllCap.append(node)
					elif nodematchingallswcap== "false" and foundincommonNode == True:
						logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])					
						pass
			if foundincommonNode==False and foundNode==False:
				logger.log(1,"[Manualmatchfinder_startProcess_System_not_selected] No node is found","D")
				self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' is not available for execution:'+'\n\n',[])
				pass

			if len(nodeWithAllCap)!=0:
				
				logger.log(1,"[MatchFinder_startProcess_System_selected] Found Nodes with all SW Capabilities; Process Test Job for Scheduling (Continue with next step)","D")
				for node in nodeWithAllCap:
					logger.log(1,"[MatchFinder_startProcess_System_selected] node"+str(node),"D")
					logger.log(1,"[MatchFinder_startProcess_System_selected] node"+str(node.get('systemlock')),"I")
					if node.get('systemlock')=='true' or node.get('locked')=='True' or  node.get('manualgit')=='True' or node.get('scheduledgit')=='IN_PROGRESS': 
						#put job in queue if test bed is already locked by other job
						self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
						self.testQueue.insert(self.convertToDictionary(testRecord))
						self.testQueue.close()
						lockflag='True'
						break
					else:
						logger.log(1,"Node with all SW capability:"+str(nodeWithAllCap),"D")
						if  lockflag!='True' and node.get('friendlyname')==testRecord[17] and len(nodeWithAllCap)!=0:
							parallelnodestatus = node.get('parallelexec').lower()
							if parallelnodestatus=='true':
								self.systemjobtrigger(testRecord,node)
								logger.log(1,"[MatchFinder_startProcess_System_selected] job triggered with parrel; exec true ","I")
								pass
								#directly trigger a job on test bed and locked the test bed 



							else:
								#parrallel exec is false check whther any job is running on the test bed
								self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
								self.testrun.close()
								if inprogressstatus:
									#job is running on the test bed so put job into queue with email notification
									self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
									self.testQueue.insert(self.convertToDictionary(testRecord))
									self.testQueue.close()
									logger.log(1,"[MatchFinder_startProcess_System_selected] job put into queue; exec false and job running on test bed: ","I")
								else:
									#no job is running trigger the job.
									self.systemjobtrigger(testRecord,node)
									logger.log(1,"[MatchFinder_startProcess_System_selected] job triggered with parrel; exec false and no job running on test bed: ","I")
									pass
					
					


					

				

		except Exception, e:
			
			
			logger.log(1,"MatchFinder_startProcess_System_selected"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[MatchFinder_startProcess_System_selected]: Lock Releasing","I")


######################################################################################################################################

	#################################################################################################################
	# SYNOPSIS:													#
    	# Find match for Test Record for which User has not provided Test Bed for execution of non mobile testing           #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record									#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# NA														#
    	#################################################################################################################
	def startProcess_System_not_selected(self, testRecord):
		try:

			logger.log(1,"MatchFinder startProcess_System_not_selected TestRun ","I")
			self.lock.acquire()
			logger.log(1,"[startProcess_System_not_selected]: Lock Locking","I")
			logger.log(1,"[startProcess_System_not_selected]: Test Suite SW Capabilities: "+str(testRecord[11]),"I")
			self.deviceFarm=DeviceFarmInfo.DeviceFarmWrapper()
			allNodes=self.deviceFarm.get_all_nodes(operation='get_all_nodes')			
			self.devicefarmdb = DB_Interface.devicefarm()
			
			prionodes= self.devicefarmdb.getprionodes(testRecord[28])
			commonnodes= self.devicefarmdb.getcommonnodes()
			
			logger.log(1,"Test beds assigned to scrum teams:"+str(prionodes),"I")
			logger.log(1,"Test beds not assigned to scrum teams:"+str(commonnodes),"I")
			self.devicefarmdb.close()
			logger.log(1,"Prionodes="+str(prionodes),"I")
			nodeWithAllCap_prio=[]
			nodeWithAllCap_locked=[]
			nodeWithAllCap=[]
			jobtriggered=False
			nodematchingallswcap='false'
			if prionodes!= None:
					x = len(prionodes)
			else:
					x = 0
			logger.log(1,"Length Prionodes x="+str(x),"I")
			if x != 0:
				logger.log(1,"Testbeds have been allocated to the scrum team :"+str(testRecord[14]),"D")#testRecord[14]?
				for i in prionodes:
					node= self.devfarmconvertToDictionary(i)
					swCap=node.get('softwares').split(',')
					nodematchingallswcap = self.checksystem(testRecord,swCap,node)
					if nodematchingallswcap== "true" :
						nodeWithAllCap_prio.append(node)
				
				if len(nodeWithAllCap_prio)==0:
				
					logger.log(1,"[Match_finder_startProcess_System_not_selected] Not a single SW Capability found in any Node from prioriy nodes;","D")
					self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])					
				else:
					
					for node in nodeWithAllCap_prio:
						if node.get('locked')!='True' and  node.get('manualgit')!='True'  and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED': 
							parallelnodestatus = node.get('parallelexec').lower()
							if parallelnodestatus=='true':
								#trigger the job and check whether test bed is locked or not
								if (str(node.get('systemlock')))!='true':
									self.systemjobtrigger(testRecord,node)
									jobtriggered = True
									break
								else:
									nodeWithAllCap_locked.append(str(node.get('friendlyname')))
					
							else:
								self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
								self.testrun.close()
								if inprogressstatus:
									nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							
								else:
									#trigger the job and check whether test bed is locked or not 
									if (str(node.get('systemlock')))!='true':
										self.systemjobtrigger(testRecord,node)
										jobtriggered= True
										break
									else:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))
						else:
							logger.log(1,"[Match_finder_startProcess_System_not_selected]: Node has active manual git ","I")
							
					
			if x==0 or jobtriggered==False:
				
				for i in commonnodes:
					node= self.devfarmconvertToDictionary(i)
					swCap=node.get('softwares').split(',')
					nodematchingallswcap = self.checksystem(testRecord,swCap,node)
					if nodematchingallswcap== "true" :
						nodeWithAllCap.append(node)
				
				if len(nodeWithAllCap) ==0 and len(nodeWithAllCap_prio)==0:

					if len(commonnodes)==0 and x==0:
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n No node is available for execution'+'\n\n',[])
					else:
						logger.log(1,"[Match_finder_startProcess_System_not_selected] Not a single SW Capability found in any Node; Send EMAIL notification to Device Farm Admin","D")
						self.email.sendMailNotification(Config['send_from'],Config['send_to'],Config['E-mail_Subject_Header']+self.subject['Matching_node_unavailable'],'Dear admin,\n\n Requested node:'+str(testRecord[17])+' has no software capability required for execution of job:'+str(testRecord[10])+"\n Required software capability:"+str(testRecord[11])+'\n\n',[])					
				elif len(nodeWithAllCap)!=0 and jobtriggered==False:
					for node in nodeWithAllCap:
						if node.get('locked')!='True' and  node.get('manualgit')!='True' and node.get('scheduledgit')!='IN_PROGRESS' and node.get('scheduledgit')!='INITIATED': 
							parallelnodestatus = node.get('parallelexec').lower()
							if parallelnodestatus=='true':
								#trigger the job and check whether test bed is locked or not
								if (str(node.get('systemlock')))!='true':
									self.systemjobtrigger(testRecord,node)
									jobtriggered = True
									break
								else:
									nodeWithAllCap_locked.append(str(node.get('friendlyname')))
					
							else:
								self.testrun=DB_Interface.Test_Run(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
								inprogressstatus=self.testrun.checkInprogress_on_testbed(str(node.get('friendlyname')))
								self.testrun.close()
								if inprogressstatus:
									nodeWithAllCap_locked.append(str(node.get('friendlyname')))
							
								else:
									#trigger the job and check whether test bed is locked or not 
									if (str(node.get('systemlock')))!='true':
										self.systemjobtrigger(testRecord,node)
										jobtriggered= True
										break
									else:
										nodeWithAllCap_locked.append(str(node.get('friendlyname')))
						else:
							logger.log(1,"[Match_finder_startProcess_System_not_selected]: Node has active manual git ","D")
		
				
			if len(nodeWithAllCap_locked)!=0 and jobtriggered==False:
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				self.testQueue.insert(self.convertToDictionary(testRecord))
				self.testQueue.close()
				logger.log(1,"[Match_finder_startProcess_System_not_selected]:Nodes are locked put job into queue ","I")		
			elif (len(nodeWithAllCap_prio)!=0 or len(nodeWithAllCap)!=0) and jobtriggered==False:
				self.testQueue=DB_Interface.Test_Queue(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['SCHEDULER_DB_NAME'])
				self.testQueue.insert(self.convertToDictionary(testRecord))
				self.testQueue.close()
				logger.log(1,"[Match_finder_startProcess_System_not_selected]:Nodes are locked due to git put job into queue ","I")






		except Exception, e:
		
			
			logger.log(1,"Match_finder_startProcess_System_not_selected"+str(e),"E")
		finally:
			
			self.lock.release()
			logger.log(1,"[Match_finder_startProcess_System_not_selected]: Lock Releasing","I")

#################################################################################################################
	# SYNOPSIS:													#
    	# Trigger job for execution of non mobile testing           #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details									#
	#################################################################################################################
    	# OUTPUT DATA:													#
	# True	Positive return
	# False	 Negative return
    	#################################################################################################################

	def systemjobtrigger(self,testRecord,node):
		try:
			logger.log(1,"[MatchFinder_systemjobtrigger] ","I")
			dictRecord=self.convertToDictionary(testRecord)
			print dictRecord,"deict record"
			nodename=str(testRecord[17])
			print nodename
			logger.log(1,"[MatchFinder_systemjobtrigger] nodename "+str(nodename),"I")
			logger.log(1,"[MatchFinder_systemjobtrigger] dictRecord "+str(dictRecord),"I")
			setUp=JobPreSetup.SetUp()
			
			preSetUP=setUp.doPreSetUp(dictRecord)
			logger.log(1,"[MatchFinder_systemjobtrigger] preSetUP "+str(preSetUP),"I")
			print preSetUP
			if preSetUP[0]==True:
				
				logger.log(1,"[MatchFinder_systemjobtrigger] TestCases.xml file created","D")
				
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start job dictrecord"+str(dictRecord),"I")
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start job node"+str(node),"I")
				logger.log(1,"[MatchFinder_systemjobtrigger] input top start preSetUP[1]"+str(preSetUP[1]),"I")
				job=StartSystemJob.systemjob(dictRecord, node, preSetUP[1])
				#If Test Job Started; then only remove its corresponding Test Record from Queue
				jobStatus=job.startProcess()
				logger.log(1,"[MatchFinder_systemjobtrigger] jobStatus"+str(jobStatus),"I")
				if jobStatus[0]:
					
					logger.log(1,"[systemjobtrigger] System Test Job has been successfully started","D")
					
					logger.log(1,jobStatus[1],"I")
					self.devicefarm=DB_Interface.devicefarm(Config['DATABSE_IP'], Config['DATABSE_USER'], Config['DATABASE_PASSWORD'], Config['DEVICE_FARM_DB_NAME'])
					self.devicefarm.updatesystemlock(str(node.get('friendlyname')),status="true")
					#lock the test bed
					self.devicefarm.close()
					logger.log(1,"[MatchFinder_systemjobtrigger] Test Job put into Running List lock test bed"+str(node.get('systemlock')),"I")
					dictRecord['location']=node.get('location')
					dictRecord['test_bed_name']=node.get('friendlyname')

					



					if self.insertIntoRunningJob(dictRecord, jobStatus[1]):
						
						logger.log(1,   "[MatchFinder_systemjobtrigger] Test Job put into Running List","D")
			return True


		except Exception, e:
			
			
			logger.log(1,"Match_finder_systemjobtrigger Exception"+str(e),"E")	
			return False

#################################################################################################################
	# SYNOPSIS:													#
    	# Check system capabilities for execution of non mobile testing  job         #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# testRecord	Dictionary	Test Record
	# node 		Dictionary	Node details	
	# swcap 	List		Software capabilities expected								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True	Positive return
	# False	 Negative return 														#
    	#################################################################################################################

	def checksystem(self, record,swcap,node={}):
		try:
			logger.log(1,"Inside checksystem","I")
			result=self.findSWCap(record[11].split(','), swcap)
			if result == 0:
				checknode = "true"
				logger.log(1,"Inside checksystem,sw cap matching for node"+str(node['friendlyname']),"I")
			else:
				checknode = "false"
				logger.log(1,"Inside checksystem,sw cap not matching for node"+str(node['friendlyname']),"I")
			return checknode

		except Exception, e:
			
			checknode = "false"
			logger.log(1,"Match_finder_checksystem Exception"+str(e),"E")	
			return checknode
#################################################################################################################
	# SYNOPSIS:													#
    	# Check device capabilities       #
	#	in Manual Mode												#
	#################################################################################################################
    	# INPUT DATA:													#
    	# Parameter	Type		Note										#
    	# self		Object		Pointer to current object							#
    	# record	Dictionary	Test Record
	# device 	Dictionary	Device details	
	# osFlag 	Boolean		status of device os-matching(true), not matching(false) 								#
	#################################################################################################################
    	# OUTPUT DATA:													#
    	# True 	Positive return
	# False	Negative return														#
    	#################################################################################################################	

	def checkfordevice(self,testRecord,device):
		try:
			result=False
			if testRecord[33]=='Any':
				logger.log(1,"matchfinder:check for device ,all are any","I")
				if  device.get('name')==testRecord[3] and str(device.get('version')).split("-")[1] == testRecord[4]:
					logger.log(1,"Manual_matchfinder:check for device ,all are any,matched","I")
					result=True
				else:
					result=False
		
			elif testRecord[33]!='Any' :
				logger.log(1,"matchfinder:check for device ,hardrev not  any","I")
				if device.get('name')==testRecord[3] and str(device.get('version')).split("-")[1] == testRecord[4] and device.get('revversion')==testRecord[33]:
					logger.log(1,"Manual_matchfinder:check for device ,hardrev not  any,matched","I")
					result=True
				else:
					result=False
		
		
			else:
					result=False
			logger.log(1,"matchfinder:check for device ,result"+str(result),"I")
			return result
		
		except Exception, e:
			print str(e)
			logger.log(1,"Exception:[matchfinder]:checkdevice"+str(e),"E")
			return None

#########################################################################################################
# SYNOPSIS:												#
# Starting point of execution for Module								#
#########################################################################################################
if __name__=='__main__':
	m=Match()
	m.checkTestTable()

